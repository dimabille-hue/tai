<?
$CMS['dbhost'] = "localhost";	# АДРЕС SQL СЕРВЕРА	
$CMS['dbname'] = "u2818473_agroinvest";	# НАЗВАНИЕ БАЗЫ ДАННЫХ	
$CMS['dbuser'] = "u2818473_agroinv";	# ЛОГИН SQL СЕРВЕРА						
$CMS['dbpass'] = "iI1hG7zU7zbT3yJ9";	# ПАРОЛЬ SQL СЕРВЕРА	
?>