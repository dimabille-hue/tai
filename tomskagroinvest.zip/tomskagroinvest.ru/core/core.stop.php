<?
mysql_close($DATA1);
?>
