<?
class opt {	
	function getOpts() 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM options");
		while ($record=mysql_fetch_array($sql))
		{
			if ($record['name']!="adminpass") $res[$record['name']]=$record['content'];
		}
		if ($res) return $res; else return 0;
	}
}
?>