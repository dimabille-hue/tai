<?
function filt($in) # Максимальная фильтрация для ввода
{
	return trim(strip_tags(htmlspecialchars(mysql_real_escape_string($in))));
}

function filtsmall($in) # Минимальная фильтрация для ввода
{
	return trim(mysql_real_escape_string($in));
}

function filtslash($in) # Фильтрация слешей для вывода
{
	return str_replace("\\","",$in);
}

function formatdate($datetime)
{
	$style = "d.m.y";
	if (mb_strlen($datetime, "UTF-8") != 19) return $datetime;
        $ex = explode(" ", $datetime);
        $ex_date = explode("-", $ex[0]);
        $ex_time = explode(":", $ex[1]);
        if ((count($ex_date)==3) && (count($ex_time)==3)) {
                $text_month = "";
                switch ($ex_date[1]) {
                    case 1: $text_month = "января"; break;
                    case 2: $text_month = "февраля"; break;
                    case 3: $text_month = "марта"; break;
                    case 4: $text_month = "апреля"; break;
                    case 5: $text_month = "мая"; break;
                    case 6: $text_month = "июня"; break;
                    case 7: $text_month = "июля"; break;
                    case 8: $text_month = "августа"; break;
                    case 9: $text_month = "сентября"; break;
                    case 10: $text_month = "октября"; break;
                    case 11: $text_month = "ноября"; break;
                    case 12: $text_month = "декабря"; break;
                }
            $style = str_replace("y", $ex_date[0], $style);
            $style = str_replace("m", $ex_date[1], $style);
            $style = str_replace("d", $ex_date[2], $style);
            $style = str_replace("f", $text_month, $style);
            $style = str_replace("h", $ex_time[0], $style);
            $style = str_replace("i", $ex_time[1], $style);
            $style = str_replace("s", $ex_time[2], $style);
            return $style;
        }
    return $datetime;
}

?>