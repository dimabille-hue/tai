<?
class forms {	
	function getForms($pageid) 
	{
		global $DATA1, $PAGED;
		$sql=mysql_query("SELECT * FROM forms WHERE page='$pageid' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record) return $record; else return 0;
	}
	
	function getFormsId($id) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM forms WHERE id='$id' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record) return $record; else return 0;
	}
	
	function formsStart($id,$method="POST",$action="")
	{
		$id=filt($id);
		echo '<form action="'.$action.'" method="'.$method.'" name="formname-'.$id.'">';
		$_SESSION['click']=1;
	}
	
	function formsStop()
	{
		echo '</form>';
	}
	function formsButton($class, $name="sendbutton", $value)
	{
		echo '<input type="submit" class="'.$class.'" id="'.$class.'" value="'.$value.'" name='.$name.'>';
	}
	function formsResult($ident) 
	{
		global $DATA1;
		$drop="";
		$ident=filt($ident);
		$sql=mysql_query("SELECT * FROM forms_data where form='$ident' order by srt desc, id", $DATA1);
		while ($record=mysql_fetch_array($sql))
		{
			if ($record)
			{
				if ($record['ident'] && $record['undel']==1)
				{
				$value=filt($_POST[$record['ident']]);
				$drop.="<b>".$record['name']."</b>: ".$value."<br>";
				}
				else
				{
				$value=filt($_POST['fname-'.$record['id']]);
				$drop.="<b>".$record['name']."</b>: ".$value."<br>";
				}
			}
		}
		return $drop;
	}
	function getFormsRows($ident) 
	{
		global $DATA1;

				$i=0;
				$ident=filt($ident);
				$sql=mysql_query("SELECT * FROM forms_data where form='$ident' order by srt desc, id", $DATA1);
				while ($record=mysql_fetch_array($sql))
				{
					if ($record)
					{
						$k=$record;
						$code="";
						if ($record['type']=='text') 
							{
								$v=filt($_POST["fname-".$record['id']]);
								$code='<input type="'.$record['type'].'" class="fname-'.$record['id'].'" id="fname-'.$record['id'].'" name="fname-'.$record['id'].'" value="'.$v.'" placeholder="'.$record['val'].'">';
							}
						elseif ($record['type']=='hidden') 
							{
								$v=filt($_POST["fname-".$record['id']]);
								$code='<input type="'.$record['type'].'" class="fname-'.$record['id'].'" id="fname-'.$record['id'].'" name="fname-'.$record['id'].'" value="'.$v.'" placeholder="'.$record['val'].'">';
							}
						elseif ($record['type']=='checkbox') 
							{
								$v=filt($_POST["fname-".$record['id']]);
								if ($v=='on') $code='<input type="'.$record['type'].'" class="fname-'.$record['id'].'" id="fname-'.$record['id'].'" name="fname-'.$record['id'].'" checked>';
								else $code='<input type="'.$record['type'].'" name="fname-'.$record['id'].'">';
							}
						elseif ($record['type']=='textarea')
							{
								$v=filt($_POST["fname-".$record['id']]);
								$code='<textarea class="fname-'.$record['id'].'" id="fname-'.$record['id'].'" name="fname-'.$record['id'].'" placeholder="'.$record['val'].'">'.$v.'</textarea>';
							}
						elseif ($record['type']=='select')
							{
								$v=filt($_POST["fname-".$record['id']]);
								$code='<select class="fname-'.$record['id'].'" id="fname-'.$record['id'].'" name="fname-'.$record['id'].'">';
								$opt=filt($record['val']);
								if($opt)
								{
									$arr=explode(":",$opt);
									if($arr)
									{
										foreach($arr as $element)
										{
											$code.='<option value="'.$element.'"';
											if ($v==$element) $code.=" selected ";
											$code.=">".$element."</option>";
										}
									}
								}
								$code.="</select>";
								
							}
						elseif ($record['type']=='date') 
							{
								$v=filt($_POST["fname-".$record['id']]);
								$code='<input type="text" class="servicedate" name="fname-'.$record['id'].'" value="'.$v.'">';
							}
						if ($record['ident'] && $record['undel']==1) continue;
						$k['code']=$code;
						$res[]=$k;
					}
				$i++;
				}
		if ($res) return $res; else return 0;
	}
}
?>