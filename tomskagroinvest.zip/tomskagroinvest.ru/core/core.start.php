<?
// ЗАПУСК СЕССИИ
session_start();
// ПОДКЛЮЧЕНИЕ НАСТРОЕК
include("core.config.php");

// ПОДКЛЮЧЕНИЕ БАЗЫ ДАННЫХ
error_reporting(0);
$DATA1 = mysql_connect($CMS['dbhost'], $CMS['dbuser'], $CMS['dbpass']); 
if (!$DATA1) error_reporting(0); else error_reporting(E_WARNING);
mysql_select_db($CMS['dbname'], $DATA1);
mysql_query('SET NAMES utf8');

// ПОДКЛЮЧЕНИЕ ФУНКЦИЙ ЯДРА
include("core.functions.php");

// ЗАГРУЗКА КОНФИГУРАЦИЙ
$sql=mysql_query("SELECT * FROM config");
while ($record=mysql_fetch_array($sql))
$CONFIG[$record['name']]=$record['content'];

// ПЕРЕДАЧА ПЕРЕМЕННЫХ GET
$query=filt($_GET['query']);
$url=explode("/", $query);
if (isset($url[0])) $PAGE=$url[0]; else $PAGE=$CONFIG['mainpage'];
if (isset($url[1])) $CAT=$url[1];
if (isset($url[2])) $ID=$url[2];
if (isset($url[3])) $LIST=$url[3];
if (isset($url[4])) $INFO=$url[4];

// ЗАГРУЗКА КЛАССОВ
require_once('class.main.php');
require_once('class.page.php');
require_once('class.opt.php');
require_once('class.block.php');
require_once('class.menu.php');
require_once('class.module.php');
require_once('class.lists.php');
require_once('class.notice.php');
require_once('class.catalog.php');
require_once('class.forms.php');

// СОЗДАНИЕ СТРАНИЦЫ
if (!$PAGED=page::getPage($PAGE)) $PAGED=page::getPageId($CONFIG['mainpage']);
// ЗАГРУЗКА КЛИЕНТСКИХ ОПЦИЙ
$OPTD=opt::getOpts();
?>