<?
class module {	
	function getModule() 
	{
		global $DATA1,$PAGED;
		$pageid=$PAGED['id'];
		$sql=mysql_query("SELECT page, power FROM lists WHERE page='$pageid' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record)
		{
		$res[]="lists";
		}
		$sql=mysql_query("SELECT page, power FROM forms WHERE page='$pageid' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record)
		{
		$res[]="forms";
		}
		$sql=mysql_query("SELECT content FROM parts_faq WHERE ident='page'");
		$record=mysql_fetch_array($sql);
		if ($record['content']==$pageid)
		{
			$sql2=mysql_query("SELECT content FROM parts_faq WHERE ident='power'");
			$record2=mysql_fetch_array($sql2);
			if ($record2['content']==0) $res[]="faq";
		}
		$sql=mysql_query("SELECT content FROM parts_reviews WHERE ident='page'");
		$record=mysql_fetch_array($sql);
		if ($record['content']==$pageid)
		{
			$sql2=mysql_query("SELECT content FROM parts_reviews WHERE ident='power'");
			$record2=mysql_fetch_array($sql2);
			if ($record2['content']==0) $res[]="reviews";
		}
		$sql=mysql_query("SELECT content FROM parts_maps WHERE ident='page'");
		$record=mysql_fetch_array($sql);
		if ($record['content']==$pageid)
		{
			$sql2=mysql_query("SELECT content FROM parts_maps WHERE ident='power'");
			$record2=mysql_fetch_array($sql2);
			if ($record2['content']==0) $res[]="maps";
		}
		
		
		if ($res) return $res; else return 0;
	}
}
?>