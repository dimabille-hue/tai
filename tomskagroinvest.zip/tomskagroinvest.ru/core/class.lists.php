<?
class lists {	
	function getList($pageid) 
	{
		global $DATA1, $PAGED;
		$sql=mysql_query("SELECT * FROM lists WHERE page='$pageid' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record) return $record; else return 0;
	}
	
	function getListId($id) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM lists WHERE id='$id' and power='0'");
		$record=mysql_fetch_array($sql);
		if ($record) return $record; else return 0;
	}
	
	function getListData($id, $limit=500) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM lists_data WHERE listid='$id' and hide='0' order by srt desc, timestamp desc, id desc LIMIT ".$limit);
		while ($record=mysql_fetch_array($sql))
		{
			
			$z=$record;
			$elid=$record['id'];
			$sql2=mysql_query("SELECT * FROM lists_dop_data WHERE elid='$elid'");
			while ($record2=mysql_fetch_array($sql2))
			{
				$z['dop'][$record2['block']]=$record2['content'];
			}
			$res[]=$z;
		}
		if ($res) return $res; else return 0;
	}
	
	function getElement($id)
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM lists_data WHERE id='$id' and hide='0' order by srt desc, timestamp, id desc desc");
		while ($record=mysql_fetch_array($sql))
		{
			$k=$record;
			$elid=$record['id'];
			$sql2=mysql_query("SELECT * FROM lists_dop_data WHERE elid='$elid'");
			while ($record2=mysql_fetch_array($sql2))
			{
				$k['dop'][$record2['block']]=$record2['content'];
			}
			$sql2=mysql_query("SELECT * FROM gallery_lists WHERE elid='$id'");
			while ($record2=mysql_fetch_array($sql2))
			{
				$k['gal'][]=$record2;
			}
		}
		if ($k) return $k; else return 0;
	}
	
	function getElementUrl($url)
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM lists_data WHERE url='$url' and hide='0' order by srt desc, timestamp");
		while ($record=mysql_fetch_array($sql))
		{
			$k=$record;
			$elid=$record['id'];
			$sql2=mysql_query("SELECT * FROM lists_dop_data WHERE elid='$elid'");
			while ($record2=mysql_fetch_array($sql2))
			{
				$k['dop'][$record2['block']]=$record2['content'];
			}
			$sql2=mysql_query("SELECT * FROM gallery_lists WHERE elid='$elid' order by srt desc, id desc");
			while ($record2=mysql_fetch_array($sql2))
			{
				$k['gal'][]=$record2;
			}
		}
		if ($k) return $k; else return 0;
	}
}
?>