<?
class catalog {	
	function getCat($url) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM catalog WHERE url='$url'");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$id=$record['id'];
		$sql=mysql_query("SELECT * FROM catalog_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		return $res;
	}
	
	function getCatById($id) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM catalog WHERE id='$id'");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$id=$record['id'];
		$sql=mysql_query("SELECT * FROM catalog_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		return $res;
	}
	
	function getItem($url) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM items WHERE url='$url'");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$id=$record['id'];
		$sql=mysql_query("SELECT * FROM items_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		$sql=mysql_query("SELECT * FROM gallery_items WHERE elid='$id' order by srt desc, id desc");
		while ($record=mysql_fetch_array($sql))
		{
			$res['gal'][]=$record;
		}
		return $res;
	}
	
	function getItemById($id) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM items WHERE id='$id'");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$id=$record['id'];
		$sql=mysql_query("SELECT * FROM items_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		$sql=mysql_query("SELECT * FROM gallery_items WHERE elid='$id' order by srt desc, id desc");
		while ($record=mysql_fetch_array($sql))
		{
			$res['gal'][]=$record;
		}
		return $res;
	}

	function getCats($parent) 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM catalog WHERE parent='$parent' order by srt desc, id");
		while ($record=mysql_fetch_array($sql))
		{
		$id=$record['id'];
		$arr[$j]=$record;
		$sql2=mysql_query("SELECT * FROM catalog_data WHERE pageid='$id'");
		while ($record2=mysql_fetch_array($sql2))
		{
			$arr[$j]['dop'][$record2['block']]=$record2['content'];
		}
		$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function getItems($parent) 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM items WHERE parent='$parent' order by srt desc, id");
		while ($record=mysql_fetch_array($sql))
		{
		$id=$record['id'];
		$arr[$j]=$record;
		$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function getItemsFull($parent) 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM items WHERE parent='$parent' order by srt desc, id");
		while ($record=mysql_fetch_array($sql))
		{
		$id=$record['id'];
		$arr[$j]=$record;
		$sql2=mysql_query("SELECT * FROM items_data WHERE pageid='$id'");
		while ($record2=mysql_fetch_array($sql2))
		{
			$arr[$j]['dop'][$record2['block']]=$record2['content'];
		}
		$sql2=mysql_query("SELECT * FROM gallery_items WHERE elid='$id' order by srt desc, id desc");
		while ($record2=mysql_fetch_array($sql2))
		{
			$arr[$j]['gal'][]=$record2;
		}
		$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	function search($key,$limit=0,$order="srt desc, id")
	{
		global $DATA1;
		$arr = array();
		$j=0;
		if ($limit!="0") $lim="LIMIT ".$limit; else $lim="";
		$key=filt($key);
		$cats=array();
		$c_result="";
		$sql=mysql_query("SELECT * FROM catalog WHERE (name LIKE '%".$key."%') and hide!=1");
		while ($record=mysql_fetch_array($sql))
		{
			if ($record) $cats[$record['id']]=1;
		}
		
		if (count($cats)>0)
		{
			for ($j=0;$j<=5;$j++)
			{
				foreach ($cats as $k => $val)
				{
					$cur=(int)$k;
					$sql=mysql_query("SELECT * FROM catalog WHERE parent='$cur' and hide!=1");
					while ($record=mysql_fetch_array($sql))
					{
						if ($record) $cats[$record['id']]=1;
					}
				}
			}
			
			foreach ($cats as $k => $val)
			{
				if ($c_result=="") $c_result.="'".$k."'";
				else $c_result.=",'".$k."'";
			}
		}
		$c="";
		if ($c_result!="") $c=" or (parent IN (".$c_result."))";
		$sql=mysql_query("SELECT * FROM items WHERE ((name LIKE '%".$key."%')".$c.") order by ".$order." ".$lim);
		while ($record=mysql_fetch_array($sql))
		{
			$id=$record['id'];
			$arr[$j]=$record;
			$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function searchFull($key,$limit=0,$order="srt desc, id") 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		if ($limit!="0") $lim="LIMIT ".$limit; else $lim="";
		$key=filt($key);
		$cats=array();
		$c_result="";
		$sql=mysql_query("SELECT * FROM catalog WHERE (name LIKE '%".$key."%') and hide!=1");
		while ($record=mysql_fetch_array($sql))
		{
			if ($record) $cats[$record['id']]=1;
		}
		
		if (count($cats)>0)
		{
			for ($j=0;$j<=5;$j++)
			{
				foreach ($cats as $k => $val)
				{
					$cur=(int)$k;
					$sql=mysql_query("SELECT * FROM catalog WHERE parent='$cur' and hide!=1");
					while ($record=mysql_fetch_array($sql))
					{
						if ($record) $cats[$record['id']]=1;
					}
				}
			}
			
			foreach ($cats as $k => $val)
			{
				if ($c_result=="") $c_result.="'".$k."'";
				else $c_result.=",'".$k."'";
			}
		}
		$c="";
		if ($c_result!="") $c=" or (parent IN (".$c_result."))";
		$sql=mysql_query("SELECT * FROM items WHERE ((name LIKE '%".$key."%')".$c.") order by ".$order." ".$lim);
		while ($record=mysql_fetch_array($sql))
		{
		$id=$record['id'];
		$arr[$j]=$record;
		$sql2=mysql_query("SELECT * FROM items_data WHERE pageid='$id'");
		while ($record2=mysql_fetch_array($sql2))
		{
			$arr[$j]['dop'][$record2['block']]=$record2['content'];
		}
		$sql2=mysql_query("SELECT * FROM gallery_items WHERE elid='$id' order by srt desc, id desc");
		while ($record2=mysql_fetch_array($sql2))
		{
			$arr[$j]['gal'][]=$record2;
		}
		$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function getCatList($id) 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM polez WHERE cat='$id'");
		while($record=mysql_fetch_array($sql))
		{
			$idl=(int)$record['stat'];
			$sql2=mysql_query("SELECT * FROM lists_data WHERE id='$idl' and hide='0'");
			$record2=mysql_fetch_array($sql2);
			$arr[$j]=$record2;
			$sql3=mysql_query("SELECT * FROM lists_dop_data WHERE elid='$idl'");
			while ($record3=mysql_fetch_array($sql3))
			{
				$arr[$j]['dop'][$record3['block']]=$record3['content'];
			}
			$sql4=mysql_query("SELECT * FROM gallery_lists WHERE elid='$idl'");
			while ($record4=mysql_fetch_array($sql4))
			{
				$arr[$j]['gal'][]=$record4;
			}
			$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function getItemAccom($id) 
	{
		global $DATA1;
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM sop WHERE item='$id'");
		while($record=mysql_fetch_array($sql))
		{
			$idi=(int)$record['stat'];
			$sql2=mysql_query("SELECT * FROM items WHERE id='$idi'");
			$record2=mysql_fetch_array($sql2);
			if ($record2) $arr[$j]=$record2; else return 0;
			$sql3=mysql_query("SELECT * FROM items_data WHERE pageid='$idi'");
			while ($record3=mysql_fetch_array($sql3))
			{
				$arr[$j]['dop'][$record3['block']]=$record3['content'];
			}
			$sql4=mysql_query("SELECT * FROM gallery_items WHERE elid='$idi' order by srt desc, id desc");
			while ($record4=mysql_fetch_array($sql4))
			{
				$arr[$j]['gal'][]=$record;
			}
			$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
	function getItemsMain($block,$content)
	{
		global $DATA1;	
		$arr = array();
		$j=0;
		$sql=mysql_query("SELECT * FROM items_data WHERE block='$block' and content='$content'");
		while($record=mysql_fetch_array($sql))
		{
			$idi=(int)$record['pageid'];
			$sql2=mysql_query("SELECT * FROM items WHERE id='$idi'");
			$record2=mysql_fetch_array($sql2);
			if ($record2) $arr[$j]=$record2; else return 0;
			$sql3=mysql_query("SELECT * FROM items_data WHERE pageid='$idi'");
			while ($record3=mysql_fetch_array($sql3))
			{
				$arr[$j]['dop'][$record3['block']]=$record3['content'];
			}
			$sql4=mysql_query("SELECT * FROM gallery_items WHERE elid='$idi' order by srt desc, id desc");
			while ($record4=mysql_fetch_array($sql4))
			{
				$arr[$j]['gal'][]=$record;
			}
			$j++;
		}
		if (!$j) return 0; else
		return $arr;
	}
	
}
?>