<?
class block {	
	function getBlock($ident) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT content FROM blocks_data WHERE block='$ident'");
		$record=mysql_fetch_array($sql);
		if ($record) return $record['content']; else return 0;
	}
}
?>