<?
class page {	
	function getPage($url) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM pages WHERE url='$url' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$id=$record['id'];
		$sql=mysql_query("SELECT * FROM pages_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		$sql=mysql_query("SELECT * FROM gallery_pages WHERE page='$id' order by srt desc, id desc");
		while ($record=mysql_fetch_array($sql))
		{
			$res['gal'][]=$record;
		}
		return $res;
	}

	function getPageId($id) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM pages WHERE id='$id' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record; else return 0;
		$sql=mysql_query("SELECT * FROM pages_data WHERE pageid='$id'");
		while ($record=mysql_fetch_array($sql))
		{
			$res['dop'][$record['block']]=$record['content'];
		}
		$sql=mysql_query("SELECT * FROM gallery_pages WHERE page='$id' order by srt desc, id desc");
		while ($record=mysql_fetch_array($sql))
		{
			$res['gal'][]=$record;
		}
		return $res;
	}
	
	function getPageName($id)
	{
		global $DATA1;
		$sql=mysql_query("SELECT name FROM pages WHERE id='$id' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record['name']; else return 0;
		return $res;
	}
	
	function getPageUrl($id)
	{
		global $DATA1;
		$sql=mysql_query("SELECT url FROM pages WHERE id='$id' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record['url']; else return 0;
		return $res;
	}
	
	function getPageUrlId($url)
	{
		global $DATA1;
		$sql=mysql_query("SELECT id FROM pages WHERE url='$url' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record['id']; else return 0;
		return $res;
	}
	
	function getPageIdentUrl($ident)
	{
		global $DATA1;
		$sql=mysql_query("SELECT url FROM pages WHERE ident='$ident' and hide=0");
		$record=mysql_fetch_array($sql);
		if ($record) $res=$record['url']; else return 0;
		return $res;
	}
	
	function getChld($id)
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM pages WHERE parent='$id' and hide=0 order by srt desc");
		while ($record=mysql_fetch_array($sql))
		{
		$res[]=$record;
		}
		if ($res) return $res; else return 0;
	}
}
?>