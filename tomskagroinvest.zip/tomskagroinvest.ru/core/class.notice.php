<?
class notice {	
	function send($name,$content,$timestamp,$part="",$partval="",$email=1) 
	{
		
		global $DATA1, $CONFIG, $OPTD;
		
		$statye=filt(date("Y"));
		$statme=filt(date("n"));
		$sqlw=mysql_query("SELECT * FROM stat WHERE y='$statye' and m='$statme'");
		$recordw=mysql_fetch_array($sqlw);
		$curstate=((int)$recordw['bid'])+1;
		mysql_query("UPDATE stat SET bid='$curstate' WHERE y='$statye' and m='$statme'");
						
		if ($_SERVER['REQUEST_METHOD']=="POST" && $_SESSION['click'])
		{
				$_SESSION['click']=0;
				mysql_query("INSERT INTO notice (name,content,timestamp,part,partval) VALUES ('$name','$content','$timestamp','$part','$partval')");
				if ($email!=1 && $OPTD['emailsend'])
				{
				require_once('core.mailer.php');
								$mailer = new PHPMailer();
								$mailer->From = '';
								$mailer->FromName = $OPTD['sitename'];
								$mailer->Subject = $name;
								$mailer->AddAddress($OPTD['emailsend']);
						if ($OPTD['emailsend2']) 	$mailer->AddAddress($OPTD['emailsend2']);
								$mailer->IsHTML(true);
								$mailer->ContentType = 'text/html';
								$mailer->CharSet = 'utf-8';
								$mailer->SetLanguage('ru');
						
								$mailer->Body = $content;
							
								$mailer->Send();

				}
		}
		else return 0;
	}
}
?>