<?
class main
{
	function create_document()
	{
		global $CMS,$DATA1,$PAGE,$CAT,$ID,$LIST,$INFO,$PAGED,$OPTD;
		include("core.before.php");
		include("./skin/before.php");
		echo "\n<!DOCTYPE HTML>\n<html lang=\"ru-RU\">\n";
	}
	
	function headers()
	{
		global $CMS,$DATA1,$PAGE,$CAT,$ID,$LIST,$INFO,$PAGED,$OPTD;
		echo "<head>\n";
		include("core.headers.php");
		echo "\n";
		include("./skin/headers.php");
		echo "\n</head>\n";
	}
	
	function body()
	{
		global $CMS,$DATA1,$PAGE,$CAT,$ID,$LIST,$INFO,$PAGED,$OPTD;
		echo "<body>\n";
		include("./skin/body.php");
	}
	
	function close_document()
	{
		global $OPTD;
		include("./skin/after.php");
		echo "\n</body>\n";
		echo "</html>";
	}
}
?>