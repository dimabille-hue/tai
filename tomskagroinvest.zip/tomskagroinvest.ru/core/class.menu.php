<?
class menu {	
	function getMenu($ident,$parent) 
	{
		global $DATA1;
		$sql=mysql_query("SELECT * FROM menus WHERE menu='$ident' and parent='$parent' and hide=0 ORDER BY srt desc, id");
		while ($record=mysql_fetch_array($sql))
		{	
			$k=$record;
			$k['page']=$record['page'];
			if ($record['target']==1) $k['target']="_blank"; else $k['target']="_self";
			if ($record['type']==1)
			{
				if ($record['link']) $k['href']=$record['link']; else $k['href']="#";
			}
			else
			{
				$pageid=$record['page'];
				$url=page::getPageUrl($pageid);
				if ($url) $k['href']=$url; else $k['href']="#";
			}
			$sid=$record['id'];
			$sql2=mysql_query("SELECT * FROM menus_data WHERE menuid='$sid'");
			while ($record2=mysql_fetch_array($sql2))
			{
				$k['dop'][$record2['block']]=$record2['content'];
			}
			$res[]=$k;
		}
		
		if ($res) return $res; else return 0;
	}
}
?>