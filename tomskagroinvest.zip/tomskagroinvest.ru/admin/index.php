<?
session_start();
$rep="";
include('cfg.php');
$PAGE=trim(strip_tags(htmlspecialchars(mysql_real_escape_string($_GET['page']))));
$access=0;
$CONFIG=array();
	$sql=mysql_query("SELECT * FROM config");
	while ($record=mysql_fetch_array($sql))
	{
		$key=$record['name'];
		$CONFIG[$key]=$record['content'];
	}
if ($PAGE=="quit")
{
	$_SESSION['login']="";
	$_SESSION['pass']="";
}

if ($_SERVER['REQUEST_METHOD']=="POST" && $_POST['authlogin'] && $_POST['authpass'])
{
	$alogin=trim(strip_tags(htmlspecialchars(mysql_real_escape_string($_POST['authlogin']))));
	$apass=md5(trim(strip_tags(htmlspecialchars(mysql_real_escape_string($_POST['authpass'])))));
	$sql=mysql_query("SELECT * FROM options WHERE name='adminpass'");
	$record=mysql_fetch_array($sql);
	$sql2=mysql_query("SELECT * FROM options WHERE name='rootpass'");
	$record2=mysql_fetch_array($sql2);
	if (($record['content']==$apass && $alogin==$CONFIG['adminlogin']) || ($record2['content']==$apass && $alogin==$CONFIG['rootlogin']))
	{
		$_SESSION['login']=$alogin;
		$_SESSION['pass']=$apass;
	}
}
elseif($_SERVER['REQUEST_METHOD']=="POST") $rep="Доступ запрещён";
	
if ($_SESSION['login'] && $_SESSION['pass'])
{
	$alogin=trim(strip_tags(htmlspecialchars(mysql_real_escape_string($_SESSION['login']))));
	$apass=trim(strip_tags(htmlspecialchars(mysql_real_escape_string($_SESSION['pass']))));
	$sql=mysql_query("SELECT * FROM options WHERE name='adminpass'");
	$record=mysql_fetch_array($sql);
	$sql2=mysql_query("SELECT * FROM options WHERE name='rootpass'");
	$record2=mysql_fetch_array($sql2);
	if (($record['content']==$apass && $alogin==$CONFIG['adminlogin']) || ($record2['content']==$apass && $alogin==$CONFIG['rootlogin'])) $access=1; else $access=0;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=1200">
		<title>ALMERIA.engine - Центр управления</title>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
		<link href="css/animations.css" rel="stylesheet" type="text/css" />
		<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" />
		<link href="css/jquery-ui-timepicker-addon.min.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>
		<script type="text/javascript" src="js/datepicker-ru.js"></script>
		<script type="text/javascript" src="js/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="js/jquery.easing.min.js"></script>
		<link href="css/jquery.jcrop.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery.jcrop.min.js"></script>
		<script type="text/javascript" src="js/iloader.js"></script>
		<script type="text/javascript" src="js/flotr2.min.js"></script>
		<script src="ckeditor/ckeditor.js"></script>
        <script src="ckfinder/ckfinder.js"></script>
		
		<script type="text/javascript">
			$("document").ready(function () {
				
				
				

				$(".menu-general").click(function() {
					if ($(this).hasClass("menu-general-hover"))
					{
						$(this).removeClass("menu-general-hover");
						$(".menu").animate( { width: "4em" }, 400, 'easeOutBack' );
					}
					else
					{
						$(this).addClass("menu-general-hover");
						$(".menu").animate( { width: "16em" }, 400, 'easeOutBack' );
						$(".menu-tooltip").stop().hide(200);
					}
				});
				
				$(".menu-element-icon").hover(function(){
					if (!($(".menu-general").hasClass("menu-general-hover")))
					{
						if (!($(this).parent().hasClass("menu-active")))
						{
						//$(this).parent().find(".menu-tooltip").stop().show(200);
						}
					}
				},function(){
					if (!($(".menu-general").hasClass("menu-general-hover")))
					{
					$(this).parent().find(".menu-tooltip").stop().hide(200);
					}
				});
				
				$(".submenu-el-icon").hover(function(){
					$(this).parent().find(".submenu-tooltip").stop().show(100);
				},function(){
					$(this).parent().find(".submenu-tooltip").stop().hide(100);
				});
				
				
			});

			function in_array(needle, haystack, strict) {  
				    var found = false, key, strict = !!strict;  
				    for (key in haystack) {  
				        if ((strict && haystack[key] === needle) || (!strict && haystack[key] == needle)) {  
				            found = true;  
				            break;  
				        }  
				    }  
				    return found;  
				}  
				 
				function array_search( needle, haystack, strict ) {  
				    var strict = !!strict;  
				    for(var key in haystack){  
				        if( (strict && haystack[key] === needle) || (!strict && haystack[key] == needle) ){  
				            return key;  
				        }  
				    }  
				    return false;  
				}  
				 
				function Name2Url(w) {
					v=0;  
				   var tr='a b v g d e ["zh","j"] z i y k l m n o p r s t u f h c ch sh ["shh","shch"] ~ y ~ e yu ya ~ ["jo","e"]'.split(' ');
				   var ww=''; w=w.toLowerCase();
				   for(i=0; i<w.length; ++i) {
					 cc=w.charCodeAt(i); ch=(cc>=1072?tr[cc-1072]:w[i]);
					 if(ch.length<3) ww+=ch; else ww+=eval(ch)[v];
				   }
				   return(ww.replace(/[^a-zA-Z0-9\-]/g,'-').replace(/[-]{2,}/gim, '-').replace( /^\-+/g, '').replace( /\-+$/g, ''));
				}
				
				function implode( glue, pieces ) {
					return ( ( pieces instanceof Array ) ? pieces.join ( glue ) : pieces );
				}
				
				function explode( delimiter, string ) {
					var emptyArray = { 0: '' };

					if ( arguments.length != 2
						|| typeof arguments[0] == 'undefined'
						|| typeof arguments[1] == 'undefined' )
					{
						return null;
					}

					if ( delimiter === ''
						|| delimiter === false
						|| delimiter === null )
					{
						return false;
					}

					if ( typeof delimiter == 'function'
						|| typeof delimiter == 'object'
						|| typeof string == 'function'
						|| typeof string == 'object' )
					{
						return emptyArray;
					}

					if ( delimiter === true ) {
						delimiter = '1';
					}

					return string.toString().split ( delimiter.toString() );
				}

				function print_r(arr, level) {
					var print_red_text = "";
					if(!level) level = 0;
					var level_padding = "";
					for(var j=0; j<level+1; j++) level_padding += "    ";
					if(typeof(arr) == 'object') {
						for(var item in arr) {
							var value = arr[item];
							if(typeof(value) == 'object') {
								print_red_text += level_padding + "'" + item + "' :\n";
								print_red_text += print_r(value,level+1);
						} 
							else 
								print_red_text += level_padding + "'" + item + "' => \"" + value + "\"\n";
						}
					} 

					else  print_red_text = "===>"+arr+"<===("+typeof(arr)+")";
					return print_red_text;
				}
				
				
		</script>
	</head>
	<body>
	<?
	if ($access==1)
	{
	
	?>
	<div id="iloader2">
		<div id="iloader">
			<div id="iloader-preview"><img id="preview" alt="" width="400" height="400"></div>
			<div id="iloader-info">
				<b class="orange">Выберите область на изображении для создания превью</b>
				<div class="error"></div>
				<div class="h40"></div>
				 <form class="object_form" name="object_form">
					<div class="waitload none" style="margin: 20px; display: none;">
						<div class="mball"></div>
					</div>
					<button class="submit left m10" type="button" id="iloader-submit">Готово</button>
					<button class="submit left m10" type="button" id="iloader-close">Отмена</button>
					<div class="clear"></div>
					<div class="h10"></div>
					<input type="checkbox" name="ignore" id="ignore" > <span style="color: #ff8331;">Игнорировать область</span>
					<div class="clear"></div>
					<div class="h20"></div>
					<b class="orange">Качество изображения</b>
					<div class="h20"></div>
					<input type="range" min="0" max="100" step="1" value="75" id="quality" name="quality">
				 </form>
			</div>
			<div class="clear"></div>
		</div>
	</div>
		<div class="menu">
			<div class="menu-inside">
				<div class="menu-general"></div>
				<a href="index.php?page=pages">
				<div class="menu-element <? if ($PAGE=="pages") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon1"></div>
					<div class="menu-element-text">СТРАНИЦЫ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">СТРАНИЦЫ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
				<a href="index.php?page=menus">
				<div class="menu-element <? if ($PAGE=="menus") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon2"></div>
					<div class="menu-element-text">МЕНЮ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">МЕНЮ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
				<a href="index.php?page=blocks">
				<div class="menu-element <? if ($PAGE=="blocks") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon4"></div>
					<div class="menu-element-text">БЛОКИ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">БЛОКИ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
				<a href="index.php?page=parts">
				<div class="menu-element <? if ($PAGE=="parts") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon3"></div>
					<div class="menu-element-text">МОДУЛИ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">МОДУЛИ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
				<a href="index.php?page=catalog">
				<div class="menu-element <? if ($PAGE=="catalog") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon7"></div>
					<div class="menu-element-text">КАТАЛОГ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">КАТАЛОГ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
				<a href="index.php?page=notice">
				<div class="menu-element <? if ($PAGE=="notice") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon5"></div>
					<div class="menu-element-text">УВЕДОМЛЕНИЯ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">УВЕДОМЛЕНИЯ</div>
						<div class="clear"></div>
					</div>
					<?
						if ($PAGE!="notice")
						{
							$sql=mysql_query("SELECT COUNT(*)FROM notice WHERE shows='0'");
							$record=mysql_fetch_row($sql);
							if ($record[0]>0)
							echo '<div id="newnotice"></div>';
						}
					?>
				</div>
				</a>
				<a href="index.php?page=options">
				<div class="menu-element <? if ($PAGE=="options") echo " menu-active"?>">
					<div class="menu-element-icon menu-icon9"></div>
					<div class="menu-element-text">НАСТРОЙКИ</div>
					<div class="clear"></div>
					<div class="menu-tooltip">
						<div class="menu-tooltip-arrow"></div>
						<div class="menu-tooltip-text">НАСТРОЙКИ</div>
						<div class="clear"></div>
					</div>
				</div>
				</a>
			</div>
		</div>
		<div class="submenu">
			<a href="index.php"><div class="submenu-element1"><div class="submenu-el-icon submenu-element1-icon"></div><div class="submenu-tooltip"><div class="submenu-tooltip-arrow"></div><div class="clear"></div><div class="submenu-tooltip-text">ГЛАВНАЯ</div></div></div></a>
			<a href="index.php?page=quit"><div class="submenu-element2"><div class="submenu-el-icon submenu-element2-icon"></div><div class="submenu-tooltip"><div class="submenu-tooltip-arrow"></div><div class="clear"></div><div class="submenu-tooltip-text">ВЫХОД</div></div></div></a>
			<div class="clear"></div>
		</div>
		<div class="general">
			<?
			if ($PAGE=="pages") include('inc/pages.php');
			elseif ($PAGE=="blocks") include('inc/blocks.php');
			elseif ($PAGE=="menus") include('inc/menus.php');
			elseif ($PAGE=="options") include('inc/options.php');
			elseif ($PAGE=="parts") include('inc/parts.php');
			elseif ($PAGE=="notice") include('inc/notice.php');
			elseif ($PAGE=="catalog") include('inc/catalog.php');
			elseif ($PAGE=="items") include('inc/items.php');
			elseif ($PAGE=="search") include('inc/search.php');
			elseif ($PAGE=="construct") include('inc/construct.php');
			else include('inc/main.php');
			?>
			
 
		
			<div class="hem20"></div>
		</div>
		<?
		}
		else
		{
		
		
			?>
			<div id="authtop">ALMERIA.engine ver 2.1</div>
			<div class="authform">
			<form class="object_form" name="object_form" method="POST" action="index.php">
				<div class="afteri">логин:</div>
				<input type=text name="authlogin" style="width: 250px;" required /><br>
				<div class="afteri">пароль:</div>
				<input type=password name="authpass" style="width: 250px;" required /><br>
				
				<div style="width: 120px; height: 30px;" class="f08 left"><?=$rep?></div><button class="submit right" type="submit" id="page-submit">Войти</button>
				<div class="clear"></div>
			</form>
			</div>
			<div id="authbottom">Рекомендуем для работы с системой использовать браузеры: Chrome, Firefox, Opera. В других браузерах некоторые модули системы могут не отображаться.</div>
		<?
		}
		?>
	</body>
</html>
