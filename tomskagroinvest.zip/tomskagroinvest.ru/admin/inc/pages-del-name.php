<?
	include('../cfg.php');
	include('access.php');
	$arr = array();
	
	$parent=(int)$_POST['parent'];
	$sql=mysql_query("SELECT id, name, undel FROM pages WHERE id='$parent'");
	$record=mysql_fetch_array($sql);
	$arr['name']=$record['name'];
	$arr['undel']=$record['undel'];
	header('Content-Type: application/json');
	echo json_encode($arr);
?>