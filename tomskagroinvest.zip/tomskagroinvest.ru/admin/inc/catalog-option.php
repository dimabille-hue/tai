<?
	include('../cfg.php');
	include('access.php');
	$arr = array();
	$key=0;
	$sql=mysql_query("SELECT * FROM catalog_config2 WHERE ident='level'");
	$record=mysql_fetch_array($sql);
	$lvl=(int)$record['content'];
	function tray($parent,$level)
	{
		global $arr, $key, $lvl;
		$sql=mysql_query("SELECT id, name, parent FROM catalog WHERE parent='$parent' ORDER BY ID");
		while ($record=mysql_fetch_array($sql))
		{
			$arr[$key]['id']=$record['id'];
			$arr[$key]['parent']=$record['parent'];
			$arr[$key]['name']=$record['name'];
			$arr[$key]['level']=$level;
			$sql2=mysql_query("SELECT COUNT(*) FROM catalog WHERE parent='".$record['id']."' ORDER BY ID");
			$record2=mysql_fetch_row($sql2);
			if ($record2[0] && $level<$lvl)
			{
			$key++;
			tray($record['id'],$level+1);
			
			}
			else $key++;
		}
	}
	if ($lvl>1)
	tray(0,0);
	
	
	header('Content-Type: application/json');
	echo json_encode($arr);
?>