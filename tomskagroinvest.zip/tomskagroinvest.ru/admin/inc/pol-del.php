<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	if ($delid)
	{
		$sql=mysql_query("SELECT * FROM polez WHERE id='$delid'");
		$record=mysql_fetch_Array($sql);
		$cat=$record['cat'];
		$stat=$record['stat'];
	     mysql_query("DELETE FROM polez WHERE cat='$cat' and stat='$stat'");
	}
	
	
?>