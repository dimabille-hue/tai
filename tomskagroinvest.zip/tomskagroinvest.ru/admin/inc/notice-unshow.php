<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	
	     mysql_query("UPDATE notice SET shows='1' WHERE id='$delid'");
	
?>