<script type="text/javascript" src="inc/form.js"></script>
<?
$id=(int)$_GET['id'];
$sql=mysql_query("SELECT ident,undel FROM forms WHERE id='$id'");
$record=mysql_fetch_array($sql);
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">ФОРМА «<?=$record['ident']?>»</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=form&id=<?=$id?>">Форма «<?=$record['ident']?>»</a></div>
<div class="hem10"></div>
<input type="hidden" id="formid" value="<?=$id?>">
<div class="pages-left">
<div class="hem10"></div>
<button class="submit" type="button" id="but-opt" style="margin-right: 1em;">Настройки формы</button><?if ($record['undel']!=1) echo '<button class="submit" type="button" id="but-del">Удалить форму</button>';?>
<div class="clear"></div>
<div class="hem10"></div>
<h3>Поля формы</h3>
<div class="hem10"></div>
<div id="rows">
</div>
<div class="hem20"></div>
<button class="submit" type="button" id="but-addrow" style="margin-right: 1em;">Добавить поле</button>
</div>
<div class="pages-right">
<div id="pages-info" class="bigEntrance"></div>
<div id="options" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Настройки формы</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-options">
			<input type="hidden" name="formidopt" id="formidopt">
			<div class="hem10"></div>
			<div class="afteri">Состояние формы:</div>
			<select name="formpower" id="formpower"><option value="0">Включена</option><option value="1">Выключена</option></select>
			
			<div class="hem10"></div>
			<div class="afteri">На какой странице разместить форму:</div>
			<select name="formpage" id="formpage"></select>
			
			<div class="hem10"></div>
			<div class="afteri">Текст на кнопке</div>
			<input id="formbutton" type="text" name="formbutton" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Например «Отправить»</div>
	
			<div class="hem10"></div>
			<div class="afteri">Заголовок над формой</div>
			<input id="formname" type="text" name="formname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться над формой, оставьте пустым если он не требуется</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст над формой</div>
			<div id="ckeform1"></div>
				
			<div class="hem10"></div>
			<div class="afteri">Текст после отправки формы</div>
			<div id="ckeform2"></div>
			
			<div class="hem10"></div>
			<div class="afteri">Уведомлять вас по почте о новых сообщениях?</div>
			<select name="formnotice" id="formnotice"><option value="0">Да</option><option value="1">Нет</option></select>	
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="opt-submit">Применить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="delform" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление формы</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить форму?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<a href="index.php?page=parts&delform=<?=$id?>"><button class="submit" type="button" id="delformbut" del="">Удалить форму</button></a>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-add" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Добавление поля</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-add">
			<input type="hidden" name="formidadd" id="formidadd">
			<div class="hem10"></div>
			<div class="afteri">Название поля:</div>
			<input id="rowname" type="text" name="rowname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок поля</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст с пояснением:</div>
			<textarea id="rowcontent" name="rowcontent" placeholder="Введите текст в данное поле"></textarea>
			<div class="form_hint">Комментарии для пользователя</div>
			
			<div class="hem10"></div>
			<div class="afteri">Тип поля:</div>
			<select name="rowtype" id="rowtype">
				<?
					$types = explode(":", $CONFIG['forms_array']);
					$typesname = explode(":", $CONFIG['forms_array_name']);
					foreach ($types as $key => $value)
					{
						echo '<option value="'.$types[$key].'">'.$typesname[$key].'</option>';
					}
				?>
			</select>
			
			<div id="rowdop" class="none">
			<div class="hem10"></div>
			<div class="afteri">Содержание списка:</div>
			<input id="rowval" type="text" name="rowval" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Введите варианты через двоеточие, в конце строки ничего ставить не нужно, например так:<br><br>Красный:Чёрный:Белый:Синий<br></div>
			</div>
			<div class="hem20"></div>
			<button class="submit" type="button" id="pages-add-submit">Добавить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление поля</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить поле: <b><span id="delname"></span></b> ?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf2"></div>
			<button class="submit" type="button" id="page-submit-delrow" del="">Удалить поле</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-edit" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Редактирование поля</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-edit">
		<input type="hidden" name="roweditid" id="roweditid">
			<div class="hem10"></div>
			<div class="afteri">Название поля:</div>
			<input id="roweditname" type="text" name="roweditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок поля</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст с пояснением:</div>
			<textarea id="roweditcontent" name="roweditcontent" placeholder="Введите текст в данное поле"></textarea>
			<div class="form_hint">Комментарии для пользователя</div>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="roweditsrt" type="text" name="roweditsrt" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Чем больше индекс сортировки - тем выше будет поле в форме</div>
			
			<div class="hem10"></div>
			<div class="afteri">Тип поля:</div>
			<select name="rowedittype" id="rowedittype">
				<?
					$types = explode(":", $CONFIG['forms_array']);
					$typesname = explode(":", $CONFIG['forms_array_name']);
					foreach ($types as $key => $value)
					{
						echo '<option value="'.$types[$key].'">'.$typesname[$key].'</option>';
					}
				?>
			</select>
			
			<div id="roweditdop" class="none">
			<div class="hem10"></div>
			<div class="afteri">Содержание списка:</div>
			<input id="roweditval" type="text" name="roweditval" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Введите варианты через двоеточие, в конце строки ничего ставить не нужно, например так:<br><br>Красный:Чёрный:Белый:Синий<br></div>
			</div>
			<div class="hem20"></div>
			<button class="submit" type="button" id="pages-edit-submit">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>	
	</form>
</div>
</div>
<div class="clear"></div>