<h1 class="margin0" unselectable="on" onselectstart="return false;">ДОБАВИТЬ ЛЕНТУ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=addlist">Добавить ленту</a></div>
<div class="hem10"></div>
<div class="pages-left">
<form class="object_form" name="object_form1" id="list-part" method="POST" action="index.php?page=parts">
	<div class="hem10"></div>
	<div class="afteri">Название ленты:</div>
	<input id="listname" name="listname" type="text" placeholder="Введите текст в данное поле" required>
	<div class="form_hint">Название будет видно только в системе управления</div>
	<div class="hem20"></div>
	<button class="submit" type="submit">Добавить ленту</button>
</form>
</div>
<div class="clear"></div>