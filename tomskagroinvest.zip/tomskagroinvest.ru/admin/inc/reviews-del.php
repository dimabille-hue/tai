<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	
	     mysql_query("DELETE FROM parts_reviews_data WHERE id='$delid'");
	
?>