$("document").ready(function () {

	var sto;	
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#info").show(300);
		$("#info").html(info);
		sto=setTimeout(function(){
			$("#info").html("");
			$("#info").hide(0);
		}, 5000)
	}
	
	$(".submit").click(function(){
	$(".submit").hide(0);
	$("#wait").show(0);
	var data = $('#form-part').serialize();
		$.ajax({
				url: 'inc/maps-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".submit").show(0);
					$("#wait").hide(0);
					PagesInfo(data);
				}
				});
	});

});