<script type="text/javascript" src="inc/notice.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">УВЕДОМЛЕНИЯ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=notice">Уведомления</a></div>
<div class="hem20"></div>
<div class="pages-left">
	<button class="submit" type="button" id="updatenotice" style="margin-right: 1em;">Обновить список</button>
	<div class="clear"></div>
	<div class="hem10"></div>
	<h3>Текущие уведомления</h3>
	<div id="blocknotice">
	</div>
</div>
<div class="pages-right">
	<div id="pages-info" class="bigEntrance">
	</div>
	<div id="options" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Просмотр уведомления</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<div class="hem10"></div>
		<b><div id="noticename"></div></b>
		<div class="hem20"></div>
		<div id="noticecontent"></div>	
		<div class="hem20"></div>
		<b><div id="noticetimestamp" class="f08 gray"></div>	</b>
		<div class="hem10"></div>
		<b><div id="noticepart" class="f08 gray"></div>	</b>
		<div class="hem20"></div>
	</div>
	<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление уведомления</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить уведомление: <b><span id="delname"></span></b> ?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="page-submit-del" del="">Удалить уведомление</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
</div>
<div class="clear"></div>