$("document").ready(function () {

var sto, listid=$("#listid").val();

var pagelist=1;
var fil=0;

	$("#elname").change(function(){
		$("#elurl").val(Name2Url($("#elname").val()));
	});
	
	$("#eleditname").change(function(){
		$("#elediturl").val(Name2Url($("#eleditname").val()));
	});
	
function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	function PartDellist()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#dellist").show(0);
		$("#dellistbut").show(0);
	}
	
	function PagesUp(elemid)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/list-up.php',
				data: 'elemid='+elemid,
				success: function(data){
					ShowElems();
				}
				});
	}
	function PagesDown(elemid)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/list-down.php',
				data: 'elemid='+elemid,
				success: function(data){
					ShowElems();
				}
				});
	}
	function PageOptions(pageid)
	{
		$(".wait2").hide(0);
		$("#listpage").html('<option value="0">Выберите страницу</option>');
	$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option-free.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#listpage").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	$("#opt-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			
			var pagecontent;
			CKEDITOR.instances['listcontent'].updateElement();
			pagecontent = CKEDITOR.instances['listcontent'].getData();
			$("#listcontent").html(pagecontent);
			
		
			
				var data = $('#list-options').serialize();
				$.ajax({
				url: 'inc/list-options-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$(".wait2").hide(0);
					PagesInfo(data);
					$("#options").hide(0);
				
				}
				});
			
		});
		
	function PartOpt()
	{

		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#dellist").hide(0);
		$("#opt-submit").show(0);
		$("#ckeform1").html("");
				$("#options").show(0);
		$.ajax({
		  url: 'inc/list-options.php',
		  type: 'POST',
		  data: 'listid='+listid,
		  dataType: 'json',
		  cache: false,
		  success: function(jsondata){
				$("#listname").val(jsondata[0]['name']);
				$("#listidopt").val(listid);
				$("#listpower").val(jsondata[0]['power']);
				PageOptions(jsondata[0]['page']);
				if (jsondata[0].content==null) { jsondata[0].content=''; }
				$("#ckeform1").html('<textarea name="listcontent" id="listcontent" rows="10" cols="80">'+jsondata[0].content+'</textarea>');
				var editor;
				editor = CKEDITOR.replace('listcontent',{
					removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
					
				});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				
			}
		  });
		
	}
	
	function ShowElems()
	{
		$("#rows").html("");
		$.ajax({
				  url: 'inc/list-col.php',
				  type: 'POST',
				  data: 'listid='+listid+'&fil='+fil,
				  cache: false,
				  success: function(data){
					var pagecol=Math.ceil(data/10);
					if (pagecol>0)
					{
						if (pagelist>pagecol) { pagelist=pagecol; }
						if (pagelist<=0) { pagelist=1; }
						var inj2="";
						var inj3="";
						var inj4="";
						if(fil==0) { inj2="selected"; }
						else if(fil==1) { inj3="selected"; }
						else if(fil==2) { inj4="selected"; }
						$("#filt1").html("");
						$("#pager1").html("");
						$("#pager2").html("");
						$("#rows").html('<div class="f08">Страница: <select class="pager" id="pager1"></select><div class="zagol-filt">Фильтр: <select class="filt" id="filt1"><option value="0" '+inj2+'>Все</option><option value="1" '+inj3+'>За месяц</option><option value="2" '+inj4+'>За сегодня</option></select></div></div><div class="hem10"></div><div id="showelements"><div id="wait"><div class="hem30"></div><div class="ball"></div><div class="ball1"></div></div></div><div class="hem10"></div><div class="f08">Страница: <select class="pager" id="pager2"></select></div>')
						for (var i=1;i<=pagecol;i++)
						{
							var inj1="";
							if (i==pagelist) { inj1="selected"; }
							$("#pager1").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
							$("#pager2").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
						}
						$.ajax({
							  dataType: 'json',
							  url: 'inc/list-load.php',
							  type: 'POST',
							  data : 'listid='+listid+'&pagelist='+pagelist+'&fil='+fil,
							  cache: false,
							  success: function(jsondata){
								$("#showelements").html("");
								$.each(jsondata,function(indx, element){
									var inj7="";
									if (element.hide==1) { inj7=' line-name-hide'; } 
									$("#showelements").append('<div class="line" elemid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot"></div><div class="line-name2"><div class="line-name-text'+inj7+'">' + element.name + ' <span class="f08 gray">' + element.timestamp + '</span></div></div><div class="line-del" title="Удалить элемент"></div><div class="line-edit" title="Редактировать элемент"></div><div class="line-down" title="Опустить вниз"></div><div class="line-up" title="Поднять вверх"></div></div></div>');
				
									
								});
							  }});
					}
					else
					{
					$("#rows").html('<div class="f08">Не нашлось ни одного элемента</div>');
					}
		}
		});
	}
	
	ShowElems();
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/list-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				ShowElems();
				PagesInfo("Элемент успешно удалён");
				$("#pages-del").hide(0);
				}
				});
			}
		});
	
	function PartDel(elemid)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#dellist").hide(0);
		$(".wait2").hide(0);
		$("#page-submit-del").show(0);
		$.ajax({
				type: 'POST',
				url: 'inc/list-del-name.php',
				data: 'delid='+elemid,
				dataType: 'json',
				success: function(data){
						$("#pages-del").show(0);
						$("#page-submit-del").attr("del",elemid);
						$("#delname").html(data.name);
				}
				});
	}
	
	$("#page-submit-add").click(
		function ()
		{
		
		$(this).hide(0);
		$(".wait2").show(0);
		var pagename, pageurl, pageparent;
			pagename=$("#elname").val();
			pageurl=$("#elurl").val();
			$("#elurl2").val($("#elurl").val());
			if ((pagename!=""))
			{
				var data = $('#form-page-add').serialize();
				$.ajax({
				url: 'inc/list-add.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$("#page-submit-add").show(0);
				PagesInfo("Элемент с таким url уже существует в этой ленте");
				}
				else
				{
				$(".wait2").hide(0);
				pagelist=1;
				ShowElems();
				PagesInfo("Элемент успешно добавлен");
				$("#pages-add").hide(0);
				}
				}
				});
			}
			else
			{
				PagesInfo("Элемент не добавлен, возможно вы заполнили не все поля");
				$("#pages-add").hide(0);
				$(".wait2").hide(0);
			}	
		
		});
		
	function PartAdd(elemid)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#dellist").hide(0);
		$(".wait2").hide(0);
		$("#page-submit-add").show(0);
		$("#elname").val("");
		$("#elurl").val("");
		$("#elurl2").val("");
		
		$("#pages-add").show(0);
	}
	
	$(".page-save").click(function(){
	
	$(".page-save").hide(0);
	$(".wait2").show(0);
	
	var pagename, pageurl, pagecontent;
	
	pageurl=$("#elediturl").val();
	
	CKEDITOR.instances['eleditdescript'].updateElement();
		pagecontent = CKEDITOR.instances['eleditdescript'].getData();
		$("#eleditdescript").html(pagecontent);
		
	CKEDITOR.instances['eleditcontent'].updateElement();
		pagecontent = CKEDITOR.instances['eleditcontent'].getData();
		$("#eleditcontent").html(pagecontent);
		
	$("#elediturl2").val($("#elediturl").val());
	
	$("[need]").map(function(indx, element){
			
			var iname = $(this).attr('need');
			CKEDITOR.instances[iname].updateElement();
			var j = CKEDITOR.instances[iname].getData();
			$("#"+iname).html(j);
		});
		
		
	var data = $('#form-page-edit').serialize();
		if (pagename!="")
		{
			$.ajax({
				url: 'inc/list-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$(".page-save").show(0);
				PagesInfo("Элемент с таким url уже существует");
				}
				else
				{
				$(".wait2").hide(0);
				ShowElems();
				PagesInfo("Элемент успешно обновлён");
				$("#pages-edit").hide(0);
				}
				}
				});
		}
		else
		{
				PagesInfo("Элемент не сохранён, возможно вы удалили «Заголовок элемента»");
				$("#pages-edit").hide(0);
				$(".wait2").hide(0);
		}
	
	});
	
	function PartEdit(elemid)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#dellist").hide(0);
		$(".page-save").show(0);
		$(".wait2").hide(0);
		$("#eleditid").val(elemid);
		$(".submit2").removeClass("op1");
		$(".submit2[bid=1]").addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block1").show(300);
		$("#ckeblock").html("");
		$("#ckeblock2").html("");
		$("#modules").html('<a href="index.php?page=parts&part=gallery&elid='+elemid+'"><div class="modulemin">Дополнительные изображения</div></a><div class="clear"></div><div class="hem10"></div><div class="f08 orange"><b>Внимание! Прежде чем переходить в модуль не забудьте сохранить элемент ленты</b></div>');
		
				
		$("#oldpageimg").hide(0);
		$("#imgold").hide(0);
				$("#elediturl").val("");
				$("#elediturl2").val("");
				$("#eleditname").val("");
				$("#elmetaname").val("");
				$("#elmetah1").val("");
				$("#elmetacontent").val("");
				$("#eleditsrt").val("0");
				$("#eledithide").prop("checked", false);
				$("#eleditnewurl").prop("checked", false);
				$("#eledittimestamp").val("");
				$("#metaloader").parent().find(".img-info").html("Добавьте изображение");
					$("#metaloader").prop('value', null);
					$("#metaloader").parent().find(".iloadval").val("");
					
					
				$("#loaderz").parent().find(".img-info").html("Добавьте изображение");
					$("#loaderz").prop('value', null);
					$("#loaderz").parent().find(".iloadval").val("");
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/list-edit.php',
		  data: 'elid='+elemid,
		  cache: false,
		  success: function(jsondata){
			
			$("#eleditname").val(jsondata[0].name);
			$("#elediturl").val(jsondata[0].url);
			$("#eleditsrt").val(jsondata[0].srt);
			if (jsondata[0].hide=="1") { $("#eledithide").prop("checked", true); }
			$("#eledittimestamp").val(jsondata[0].timestamp);
			$("#eledittimestamp").datetimepicker( $.datepicker.regional[ "ru" ] );
			if (!jsondata[0].descript) { $("#ckeblock").html('<textarea name="eleditdescript" id="eleditdescript" rows="10" cols="80"></textarea>'); } else
				{ $("#ckeblock").html('<textarea name="eleditdescript" id="eleditdescript" rows="10" cols="80">' + jsondata[0].descript + '</textarea>'); }
			
			if (!jsondata[0].content) { $("#ckeblock2").html('<textarea name="eleditcontent" id="eleditcontent" rows="10" cols="80"></textarea>'); } else
				{ $("#ckeblock2").html('<textarea name="eleditcontent" id="eleditcontent" rows="10" cols="80">' + jsondata[0].content + '</textarea>'); }
				
			var editor;
				editor = CKEDITOR.replace('eleditdescript',{
					removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
						});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				
			var editor2;
				editor2 = CKEDITOR.replace('eleditcontent',{
					removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
				});
				CKFinder.setupCKEditor(editor2, "ckfinder/");
				
				
			$("#elmetaname").val(jsondata[0].metaname);
			$("#elmetah1").val(jsondata[0].metah);
			$("#elmetacontent").val(jsondata[0].metacontent);
			
			if (jsondata[0].metaimg)
				{
					$("#oldpageimg").find(".imagsold").val(jsondata[0].metaimg);
					$("#oldpageimg").find(".oldimg").css({'background':'url(../img/upload/th/'+jsondata[0].metaimg+') center center no-repeat', 'background-size':'cover'});
					$("#oldpageimg").show(0);
				}
				
			if (jsondata[0].img)
				{
					$("#imgold").find(".imagsold").val(jsondata[0].img);
					$("#imgold").find(".oldimg").css({'background':'url(../img/upload/th/'+jsondata[0].img+') center center no-repeat', 'background-size':'cover'});
					$("#imgold").show(0);
				}
				
			$.ajax({
						  dataType: 'json',
						  type: 'POST',
						  url: 'inc/list-dop.php',
						  data: 'elid='+elemid,
						  cache: false,
						  success: function(injsondata){
							$.each(injsondata,function(indx, inelement){
								if (inelement.type==1 || inelement.type==2)
								{
									$("#dop-"+inelement.ident).val(inelement.content);
								}
								if (inelement.type==3)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==4)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==5)
								{
									$("#dop-"+inelement.ident).html("");
									//$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var ar = inelement.val.split(":");
									$.each(ar,function(indx, option){
										if (option==inelement.content)
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'" selected>'+option+'</option>');
										}
										else
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'">'+option+'</option>');
										}
									});
								}
								if (inelement.type==6)
								{
									if (inelement.content)
									{
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
										$("#oldimg-"+inelement.ident).find(".imagsold").val(inelement.content);
										$("#oldimg-"+inelement.ident).find(".oldimg").css({'background':'url(../img/upload/th/'+inelement.content+') center center no-repeat', 'background-size':'cover'});
										$("#oldimg-"+inelement.ident).show(0);
									}
									else
									{
										$("#oldimg-"+inelement.ident).hide(0);
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
									}
								}
							});
						  }
				});	
				
			$("#pages-edit").show(0);
		  }});
		
	}
	
	$("#but-del").click(function(){
		PartDellist();
	});
	
	$("#but-opt").click(function(){
		PartOpt();
	});
	
	$("#but-add").click(function(){
		PartAdd();
	});
	
	$(".pages-left").on("change","#pager1",function(){
		  pagelist=$(this).val();
		ShowElems();
	});
	
	$(".pages-left").on("change","#pager2",function(){
		  pagelist=$(this).val();
		ShowElems();
	});
	$(".pages-left").on("change","#filt1",function(){
		fil=$(this).val();
		ShowElems();
	});
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('elemid'));
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PartEdit($(this).parent().parent().attr('elemid'));
	});
	$(".pages-left").on("click",".line-up",function(){
		  PagesUp($(this).parent().parent().attr('elemid'));
	});
	$(".pages-left").on("click",".line-down",function(){
		  PagesDown($(this).parent().parent().attr('elemid'));
	});
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
	
	$(".imgdel").click(function(){
		$(this).parent().hide(0);
		$(this).parent().find(".imagsold").val("");
	});
	
	$(".submit2").click(function(){
		$(".submit2").removeClass("op1");
		$(this).addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block"+($(this).attr("bid"))).show(300);
	});

});