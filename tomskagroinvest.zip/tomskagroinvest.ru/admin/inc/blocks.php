<script type="text/javascript" src="inc/blocks.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">БЛОКИ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=blocks">Блоки</a></div>
<div class="hem20"></div>
<div class="pages-left">
	<div id="blocks-tree" unselectable="on" onselectstart="return false;"></div>
</div>
<div class="pages-right">
	<div id="pages-info" class="bigEntrance">
	</div>
	<div id="blocks-edit" class="bigEntrance" style="display: none;">
		<div class="fl"><h3 class="m0">Редактирование блока</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form2" id="form-blocks-edit" enctype="multipart/form-data">
		<input id="blocks-edit-id" type="hidden" value="0" name="blockid">
		<div class="hem10"></div>
		<div class="afteri">Название блока: <b><span id="block-name"></span></b></div>
		<div class="hem10"></div>
			<div id="block-place">
			</div>
		<div class="hem20"></div>
			<button class="submit blocks-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	<input type=hidden id="conf1" value="<?=$CONFIG['max_upload_images_width']?>">
	<input type=hidden id="conf2" value="<?=$CONFIG['max_upload_images_height']?>">
	<input type=hidden id="conf3" value="<?=$CONFIG['max_upload_images_size']?>">
	<input type=hidden id="conf4" value="<?=$CONFIG['resize_images_big']?>">
</div>
<div class="clear"></div>