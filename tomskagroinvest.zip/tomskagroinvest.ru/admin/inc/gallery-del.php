<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	$delvar=filt($_POST['delvar']);
	if ($delvar=="page")
	{
	     mysql_query("DELETE FROM gallery_pages WHERE id='$delid'");
	}
	elseif($delvar=="list")
	{
	     mysql_query("DELETE FROM gallery_lists WHERE id='$delid'");
	}
	elseif($delvar=="item")
	{
	     mysql_query("DELETE FROM gallery_items WHERE id='$delid'");
	}
	
	
?>