<script type="text/javascript" src="inc/maps.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">КАРТА</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=maps">Карта</a></div>
<div class="hem10"></div>
<div class="pages-left">
<? 
$sql=mysql_query("SELECT * FROM parts_maps");
while ($record=mysql_fetch_array($sql))
{
	$ar[$record['ident']]=$record['content'];
}

function tray($parent,$level,$find)
	{
		$sql=mysql_query("SELECT id, name, parent FROM pages WHERE parent='$parent' ORDER BY ID");
		while ($record=mysql_fetch_array($sql))
		{
			$name="";
			for ($i=1;$i<=$level;$i++) $name.="&nbsp;&nbsp;&nbsp;";
			$name.=$record['name'];
			if ($record['id']==$find) echo '<option value="'.$record['id'].'" selected>'.$name.'</option>'; else
			echo '<option value="'.$record['id'].'">'.$name.'</option>';
			$sql2=mysql_query("SELECT COUNT(*) FROM pages WHERE parent='".$record['id']."' ORDER BY ID");
			$record2=mysql_fetch_row($sql2);
			if ($record2[0])
			{
			tray($record['id'],$level+1,$find);
			
			}
			else $key++;
		}
	}
?>
<form class="object_form" name="object_form1" id="form-part">
	<h3>Настройки модуля</h3>
	<div class="hem10"></div>
	<div class="afteri">Состояние модуля:</div>
	<select name="mappower" id="mappower"><option value="0">Включен</option><option value="1" <? if ($ar['power']==1) echo 'selected '; ?>>Выключен</option></select>
	
	<div class="hem10"></div>
	<div class="afteri">На какой странице разместить карту:</div>
	<select name="mappage" id="mappage"><option value="0">Выберите страницу</option><?tray(0,0,$ar['page']);?></select>
	
	<div class="hem10"></div>
	<div class="afteri">Заголовок на карте:</div>
	<input id="mapname" name="mapname" type="text" placeholder="Введите текст в данное поле" required value="<?=htmlspecialchars_decode($ar['name'])?>"/>
	<div class="form_hint">Заголовок будет отображаться на сайте</div>
	
	<div class="hem10"></div>
	<div class="afteri">Описание на карте:</div>
	<input id="mapdescr" name="mapdescr" type="text" placeholder="Введите текст в данное поле" required value="<?=$ar['descript']?>" />
	<div class="form_hint">Небольшое описание, например адрес или номер телефона</div>
	
	<div class="hem10"></div>
	<div class="afteri">Координата X:</div>
	<input id="cordx" name="cordx" type="text" placeholder="Введите текст в данное поле" required  value="<?=$ar['x']?>" />
	<div class="form_hint">Координата формата 12.1254, которую можно узнать на сервисе <a href="https://www.google.ru/maps">Google Maps</a></div>
	
	<div class="hem10"></div>
	<div class="afteri">Координата Y:</div>
	<input id="cordy" name="cordy" type="text" placeholder="Введите текст в данное поле"  value="<?=$ar['y']?>" required />
	<div class="form_hint">Координата формата 12.1254, которую можно узнать на сервисе <a href="https://www.google.ru/maps">Google Maps</a></div>
	
	<div class="hem20"></div>
	<button class="submit" type="button">Сохранить</button>
	<div class="wait2 none" id="wait">
		<div class="mball"></div>
	</div>
</form>
<div id="info" class="options bigEntrance">
</div>
</div>
<div class="clear"></div>