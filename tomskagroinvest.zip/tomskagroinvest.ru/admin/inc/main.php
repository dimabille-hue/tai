<script type="text/javascript" src="inc/main.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">ДОБРО ПОЖАЛОВАТЬ В ЦЕНТР УПРАВЛЕНИЯ</h1>
<div class="bread gray" unselectable="on" onselectstart="return false;" style="font-weight: bold;">ALMERIA.engine ver <?=$CONFIG['ver']?></div>
<div class="pages-left">
	
	<div class="h30"></div>
	<h3>Количество посетителей сайта</h3>
	<div class="h10"></div>
	<div id="info1"></div>
	<div class="h30"></div>
	<h3>Количество заявок с сайта</h3>
	<div class="h10"></div>
	<div id="info2"></div>
	<div class="h30"></div>
</div>
<div class="pages-right hidden">
	<div class="h30"></div>
	<h3>Советы по продвижению сайта</h3>
	<div class="h10"></div>
	<div id="advice">
		<div class="h20"></div>
		<div id="advice-text" class="f08">
			<div class="h20"></div><div class="ball"></div><div class="ball1"></div>
		</div>
		<div class="h20"></div>
		<input type="hidden" id="curadvice">
		<button class="submit right" type="button" id="newadvice" style="margin-right: 20px;">Следующий совет</button>
		<div class="clear"></div>
		<div class="h20"></div>
	</div>
	<div class="h30"></div>
	<h3>Доступные обновления для вашего сайта</h3>
	<div class="h10"></div>
	<div id="update">
		<div class="h20"></div>
		<div id="update-text" class="f08">
			Нет доступных обновлений
		</div>
		<div class="h20"></div>
	</div>
	<div class="h30"></div>
	<h3>Техническая поддержка</h3>
	<div class="h10"></div>
	<div id="help">
		<div class="h20"></div>
		<div id="help-text" class="f08">
			Вы можете задать любые вопросы по работе и обслуживанию вашего сайта по телефону
			<div><b><span style="font-size: 1.2em;">-</span> <span style="font-size: 2em;">-</span></b> или по почте <b><span style="font-size: 1.2em;">-</span></b></div>
			
		</div>
		<div class="h20"></div>
	</div>
</div>
<div class="clear"></div>
			
		
