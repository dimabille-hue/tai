<script type="text/javascript" src="inc/gallery.js"></script>
<?
$pageid=(int)$_GET['pageid'];
$elid=(int)$_GET['elid'];
$itemid=(int)$_GET['itemid'];
if ($pageid>0)
{
	echo '<input type=hidden id="var" value="page"><input type=hidden id="val" value="'.$pageid.'">';
	$sql=mysql_query("SELECT name FROM pages WHERE id='$pageid'");
	$record=mysql_fetch_array($sql);
	$varn="page";
	$wi=$CONFIG['gallery_width'];
	$he=$CONFIG['gallery_height'];
}
elseif ($elid>0)
{
	echo '<input type=hidden id="var" value="el"><input type=hidden id="val" value="'.$elid.'">';
	$sql=mysql_query("SELECT name FROM lists_data WHERE id='$elid'");
	$record=mysql_fetch_array($sql);
	$varn="list";
	$wi=$CONFIG['gallery_width'];
	$he=$CONFIG['gallery_height'];
}
elseif ($itemid>0)
{
	echo '<input type=hidden id="var" value="item"><input type=hidden id="val" value="'.$itemid.'">';
	$sql=mysql_query("SELECT name FROM items WHERE id='$itemid'");
	$record=mysql_fetch_array($sql);
	$varn="item";
	$wi=$CONFIG['gallery_item_width'];
	$he=$CONFIG['gallery_item_height'];
}
else
{
	$record=0;
}
?>
<input type=hidden id="blockw" value="<?=$wi?>"><input type=hidden id="blockh" value="<?=$he?>">
<h1 class="margin0" unselectable="on" onselectstart="return false;">ГАЛЕРЕИ</h1>
<div class="hem10"></div>
<div class="pages-left">
	<h3>Изображения галереи «<?=$record['name']?>»</h3><div class="hem10"></div>
	<button class="submit" type="button" id="add-btn" style="margin-right: 1em;">Добавить изображение</button>
	<div class="clear"></div>
	<div class="hem20"></div>
	<div id="imgs"><div class="ball"></div><div class="ball1"></div>
	</div>
</div>
<div class="pages-right">
	<div id="pages-info" class="bigEntrance">
	</div>
	<div id="pages-add" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Добавление изображения</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-add">
			<input type=hidden name="galvar" id="galvar">
			<input type=hidden name="galval" id="galval">
			<div class="hem10"></div>
			<div class="afteri">Изображение:</div>
			<div class="iload">
				<input type="file" id="metaloader" onchange="fileSelectHandler(this,<?=$CONFIG['max_upload_images_width']?>,<?=$CONFIG['max_upload_images_height']?>,<?=$CONFIG['max_upload_images_size']?>,<?=$wi?>,<?=$he?>,<?=$CONFIG['resize_images_big']?>,'<?=$varn?>gallery','oldpageimg')">
				<div class="img-info"></div>
				<input type="hidden" class="iloadval" name="metaimages">
			</div>
		
			<div class="hem10"></div>
			<div class="afteri">Подпись под изображением:</div>
			<input id="galname" type="text" name="galname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Подпись будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">Alt:</div>
			<input id="galalt" type="text" name="galalt" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Краткое описание (от 2 до 6 слов)</div>
			
			<div class="hem10"></div>
			<div class="afteri">Title:</div>
			<input id="galtitle" type="text" name="galtitle" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Более подробное описание, чем Alt</div>
			
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit-add">Добавить</button>
			<div class="wait2 none" id="waitadd">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	<div id="pages-edit" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Редактирование изображения</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-edit">
	<input type=hidden name="galeditvar" id="galeditvar">
	<input type=hidden name="galeditval" id="galeditval">
			<div class="hem10"></div>
			<div class="afteri">Подпись под изображением:</div>
			<input id="galeditname" type="text" name="galeditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Подпись будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">Alt:</div>
			<input id="galeditalt" type="text" name="galeditalt" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Краткое описание (от 2 до 6 слов)</div>
			
			<div class="hem10"></div>
			<div class="afteri">Title:</div>
			<input id="galedittitle" type="text" name="galedittitle" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Более подробное описание, чем Alt</div>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="galeditsrt" type="text" name="galeditsrt" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Чем больше индекс - тем выше изображение</div>
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit-edit">Сохранить</button>
			<div class="wait2 none" id="waitedit">
				<div class="mball"></div>
			</div>
		</form>
</div>
	<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление изображения</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить изображение?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="page-submit-del" del="" var="<?=$varn?>">Удалить изображение</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
</div>
</div>
<div class="clear"></div>
