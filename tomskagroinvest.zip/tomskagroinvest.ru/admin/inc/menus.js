$("document").ready(function () {

	var popen=new Array();
	var sto;
	
	
	function printopt(pageid,ident)
	{
		$.ajax({
				  dataType: 'json',
				  type: 'POST',
				  data: 'ident='+ident,
				  url: 'inc/menus-option.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#menusparent").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	function printopt2(pageid)
	{
		$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option2.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#menuspage").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	$(".page-save").click(function(){
		
		$(".page-save").hide(0);
		$(".wait2").show(0);
		
		var menusid, menusident;
		
		menusid=$("#menusid").val();
		menusident=$("#menusident").val();
		
		var data = $('#form-page-edit').serialize();
		if (menusid!="" && menusident!="" && menusident && menusid)
		{
				
			$.ajax({
				url: 'inc/menus-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
				
				$(".wait2").hide(0);
				MenusPrint();
				PagesInfo("Элемент меню успешно обновлён");
				$("#menus-edit").hide(0);
				}
				});
		}
		else
		{
				PagesInfo("Элемент не сохранён, произошла ошибка");
				$("#menus-edit").hide(0);
				$(".wait2").hide(0);
		}
		
	});
	
	function MenusEdit(parent,ident)
	{
		
		$("#menus-add").hide(0);
		$("#pages-info").hide(0);
		$("#menus-del").hide(0);
		$("#menus-edit").hide(0);
		$(".submit2").removeClass("op1");
		$(".submit2[bid=1]").addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block1").show(300);
		$(".page-save").show(0);
		$(".wait2").hide(0);
		
		$("#menusname").val("");
		$("#menuslink").val("");
		$("#menussrt").val("0");
		$("#menusparent").val("0");
		$("#menushide").prop("checked", false);
		$("#menusid").val(parent);
		$("#menusident").val(ident);
		$("body").scrollTop(0);
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/menus-edit.php',
		  data: 'menusid='+parent,
		  cache: false,
		  success: function(jsondata){
				$.each(jsondata,function(indx, element){
					$("#menusname").val(element.name);
					$("#menussrt").val(element.srt);
					$("#menustitle").val(element.title);
					if (element.hide=="1") { $("#menushide").prop("checked", true); }
					$("#menustarget [value='"+(element.target)+"']").attr("selected", "selected");
					$("#menuspage").html('<option value="0">Выберите страницу</option>');
					if (element.type==1)
					{
						$("#menustype [value='1']").attr("selected", "selected");
						$(".menustype2").show(0);
						$(".menustype1").hide(0);
						$("#menuslink").val(element.link);
						printopt2(0);
					}
					else
					{
						$("#menustype [value='0']").attr("selected", "selected");
						$(".menustype2").hide(0);
						$(".menustype1").show(0);
						printopt2(element.page);
					}
					$("#menusparent").html('<option value="0">Элемент верхнего уровня</option>');
					printopt(element.parent,ident);
					$.ajax({
						  dataType: 'json',
						  type: 'POST',
						  url: 'inc/menus-dop.php',
						  data: 'menusid='+parent+'&menusident='+ident,
						  cache: false,
						  success: function(injsondata){
						  $("#dop").html('');
						  
							$("#dop").html('');
							var kon=0;
							$.each(injsondata,function(indx, inelement){
								if (inelement.type==1)
								{
									$("#dop").append('<div class="hem10"></div><div class="afteri">'+inelement.name+':</div><input id="dop-'+inelement.ident+'" type="text" name="dop-'+inelement.ident+'" placeholder="Введите текст в данное поле" required value="'+inelement.content+'"><div class="form_hint">'+inelement.val+'</div>');
									kon++;
								}
								if (inelement.type==2)
								{
									$("#dop").append('<div class="hem10"></div><div class="afteri">'+inelement.name+':</div><select id="dop-'+inelement.ident+'" name="dop-'+inelement.ident+'"></select>');
									var ar = inelement.val.split(":");
									$.each(ar,function(indx, option){
										if (option==inelement.content)
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'" selected>'+option+'</option>');
										}
										else
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'">'+option+'</option>');
										}
									});
									kon++;
								}
								if (inelement.type==3)
								{
									$("#dop").append('<div class="hem10"></div><div id="dop-img-'+inelement.ident+'"></div>');
									var conf1, conf2, conf3, conf4;
									conf1=$("#conf1").val();
									conf2=$("#conf2").val();
									conf3=$("#conf3").val();
									conf4=$("#conf4").val();
									$("#dop-img-"+inelement.ident).html('<div class="afteri">'+inelement.name+':</div><div class="iload"><input type="file" id="dop-'+inelement.ident+'" onchange="fileSelectHandler(this,'+conf1+','+conf2+','+conf3+','+inelement.val+','+conf4+',\'menus\',\'dop-old-'+inelement.ident+'\')"><div class="img-info"></div><input type="hidden" class="iloadval" name="dop-'+inelement.ident+'"></div><div id="dop-old-'+inelement.ident+'" class="oldimghide"><div class="hem10"></div><div class="afteri">Текущее изображение:</div><div class="hem10"></div><div class="oldimg"></div><div class="imgdel f08 orange pointer">Удалить</div><input type="hidden" class="imagsold" name="dopold-'+inelement.ident+'"></div>');
									if (inelement.content!='')
									{
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
										$("#dop-old-"+inelement.ident).find(".imagsold").val(inelement.content);
										$("#dop-old-"+inelement.ident).find(".oldimg").css({'background':'url(../img/upload/th/'+inelement.content+') center center no-repeat', 'background-size':'cover'});
										$("#dop-old-"+inelement.ident).show(0);
									}
									else
									{
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
										$("#dop-old-"+inelement.ident).hide(0);
									}
								}
							});
							if (kon==0)
							{
							$("#dop").html('<div class="hem20"></div><div class="f08">У данного меню нет дополнительных параметров</div>');
							}
						  
						  }
						  });
					$("#menus-edit").show(0);
				});
		  }
		  });
		
	}
	
	$("#page-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			var pagename, ident;
			pagename=$("#page-name").val();
			ident=$("#menuident").val();
			if ((pagename!="") && (ident!=""))
			{
				var data = $('#form-page-add').serialize();
				$.ajax({
				url: 'inc/menus-add.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
				$(".wait2").hide(0);
				MenusPrint();
				PagesInfo("Элемент меню успешно добавлен");
				$("#menus-add").hide(0);
				}
				});
			}
			else
			{
				PagesInfo("Элемент не добавлен, возможно вы заполнили не все поля");
				$("#menus-add").hide(0);
				$(".wait2").hide(0);
			}
		});
		
	function MenusAdd(parent,ident)
	{
		$(".wait2").hide(0);
		$("#page-submit").show(0);
		$("#menus-add").hide(0);
		$("#pages-info").hide(0);
		$("#menus-edit").hide(0);
		$("#menus-del").hide(0);
		$("#menuident").val(ident);
		$("#page-name").val("");
		$("#menus-add").show(300);
		$("body").scrollTop(0);
		$("#page-parent").html('<option value="0">Элемент верхнего уровня</option>');
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  data: 'ident='+ident,
		  url: 'inc/menus-option.php',
		  cache: false,
		  success: function(jsondata){
			$.each(jsondata,function(indx, element){
			var inj1="", inj2="";
			if (parent==element.id) { inj2=" selected ";} 
			if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
			if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
			if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
				 $("#page-parent").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
			});
		 }
		});
	}
	
	function MenusDel(parent)
	{
		$("#pagedel-submit").show(0);
		$(".wait2").hide(0);
		$("#delinf").html("");
		$("#pagedel-submit").attr("del","");
		$("#menus-add").hide(0);
		$("#pages-info").hide(0);
		$("#menus-edit").hide(0);
		$("#menus-del").hide(0);
		$("body").scrollTop(0);
		$.ajax({
				type: 'POST',
				url: 'inc/menus-del-name.php',
				data: 'parent='+parent,
				dataType: 'json',
				success: function(data){
					
						$("#menus-del").show(0);
						$("#pagedel-submit").attr("del",parent);
						$("#delname").html(data.name);
					
				}
				});
	}
	
	$("#pagedel-submit").click(
		function ()
		{
			$("#pagedel-submit").hide(0);
			$(".wait2").show(0);
			var delid=$("#pagedel-submit").attr("del");
			popen[delid]=0;
			$("#pagedel-submit").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/menus-del.php',
				data: 'delid='+delid,
				success: function(data){
				
				$(".wait2").hide(0);
				MenusPrint();
				PagesInfo("Элемент меню успешно удален");
				$("#menus-del").hide(0);
				}
				});
			}
		});
	
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	function MenusUp(parent)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/menus-up.php',
				data: 'parent='+parent,
				success: function(data){
					MenusPrint();
				}
				});
	}	
	function MenusDown(parent)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/menus-down.php',
				data: 'parent='+parent,
				success: function(data){
					MenusPrint();
				}
				});
	}	
	function MenusPrint()
	{
		$("#menus-tree").html('<div class="hem30"></div><div class="ball"></div><div class="ball1"></div>');
		$.ajax({
			  dataType: 'json',
			  url: 'inc/menus-tree.php',
			  cache: false,
			  success: function(jsondata){
			  $("#menus-tree").html('');
			 
			  $.each(jsondata['mc'],function(indx, element){
				$("#menus-tree").append('<h4 class="m0x">'+element.name+'</h4><div class="hem10"></div>');
				if (jsondata['md'])
				{
				if (jsondata['md'][element.ident])
				{
				$.each(jsondata['md'][element.ident],function(indx, elements){
					var inj1="", inj2="", inj3="", inj4="";
					if (elements.hide=="1") { inj1=" line-name-hide"; } else { inj1=""; }
					if (popen[parseInt(elements.id)]==1)
					 {
						 if (elements.have=="plus")
						 {
						 elements.have="minus";
						 inj2="";
						 }
					 }
					 else
					 {
					 if (elements.level!="0") { inj2=" none"; } else { inj2=""; }
					 }
					if (elements.parent!=0)
					 {
						if (popen[parseInt(elements.parent)]==1)
						{
						inj2="";
						}
					 }
					 if (elements.level<(parseInt(element.level)-1))
				 {	
					inj4='<div class="line-add" title="Добавить элемент меню"></div>';
				 }
				 inj3='<div class="line-del" title="Удалить элемент меню"></div>';
				 if (elements.level==(parseInt(element.level)-1))
				 {
				 elements.have='dot';
				 }
				 if (elements.level<element.level)
				 {
				 $("#menus-tree").append('<div class="line' + inj2 + '" menuid="' + elements.id + '" ident="'+element.ident+'" parent="' + elements.parent + '"><div class="line-inside line-level' + elements.level + '"><div class="line-open line-' + elements.have + '"></div><div class="line-name"><div class="line-name-text' + inj1 + ' ">' + elements.name + '</div></div>' + inj3 + '<div class="line-edit" title="Редактировать элемент меню"></div><div class="line-down" title="Опустить вниз"></div><div class="line-up" title="Поднять вверх"></div>' + inj4 + '</div></div>');
				 }
				});
				
				$("#menus-tree").append('<div class="hem10"></div><button class="submit newpage" type="button" ident="'+element.ident+'">Новый элемент меню</button>');
				}
				else
				{
				$("#menus-tree").append('<button class="submit newpage" type="button" ident="'+element.ident+'">Новый элемент меню</button>');
				}
				}
				else
				{
				$("#menus-tree").append('<button class="submit newpage" type="button" ident="'+element.ident+'">Новый элемент меню</button>');
				}
				
				$("#menus-tree").append('<div class="hem20"></div>');
			  });
			  
		  }
		});
	}
	
	MenusPrint();
	
	$("#menus-tree").on("click",".line-plus",function(){
		  $(this).removeClass("line-plus");
		  $(this).addClass("line-minus");
		  $(".line[parent = " + $(this).parent().parent().attr('menuid') + "]").fadeIn(300);
		  var po=parseInt($(this).parent().parent().attr('menuid'));
		  popen[po]=1;
	});
	
	$("#menus-tree").on("click",".line-minus",function(){
		  var po=parseInt($(this).parent().parent().attr('menuid'));
		  pgminus(po);
	});
	
	$("#menus-tree").on("click",".line-add",function(){
		  MenusAdd($(this).parent().parent().attr('menuid'),$(this).parent().parent().attr('ident'));
	});
	
	$("#menus-tree").on("click",".line-edit",function(){
		  MenusEdit($(this).parent().parent().attr('menuid'),$(this).parent().parent().attr('ident'));
	});
	$("#menus-tree").on("click",".line-del",function(){
		  MenusDel($(this).parent().parent().attr('menuid'));
	});
	$("#menus-tree").on("click",".line-up",function(){
		  MenusUp($(this).parent().parent().attr('menuid'));
	});
	$("#menus-tree").on("click",".line-down",function(){
		  MenusDown($(this).parent().parent().attr('menuid'));
	});
	$("#menus-tree").on("click",".newpage",function(){
		  MenusAdd(0,$(this).attr("ident"));
	});
	
	function pgminus(id)
	{
		popen[id]=0;
		$(".line[menuid="+id+"]").find(".line-open").removeClass("line-minus");
		$(".line[menuid="+id+"]").find(".line-open").addClass("line-plus");
		$(".line[parent="+id+"]").each(function(indx){
		    pgminus($(this).attr("menuid"));
		});
		$(".line[parent="+id+"]").fadeOut(0);
	}
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
	
	$("#menustype").change(function(){
		  if ($(this).val()==1)
		  {
		  $(".menustype2").show(0);
		  $(".menustype1").hide(0);
		  }
		  else
		  {
		  $(".menustype2").hide(0);
		  $(".menustype1").show(0);
		  }
	});
	
	$("#menus-edit").on("click",".imgdel",function(){
		$(this).parent().hide(0);
		$(this).parent().find(".imagsold").val("");
	});
	
	$(".submit2").click(function(){
		$(".submit2").removeClass("op1");
		$(this).addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block"+($(this).attr("bid"))).show(300);
	});

});