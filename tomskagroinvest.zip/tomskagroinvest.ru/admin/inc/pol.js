$("document").ready(function () {
	var sto;
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	function Showimgs()
	{
		$("#imgs").html('<div class="ball"></div><div class="ball1"></div>');
		var blockw, blockh, galval, galvar, neww, newh;
		
		
		galval=$("#val").val();
		
		$.ajax({
				dataType: 'json',
				url: 'inc/pol-load.php',
				type: 'POST',
				data : 'galval='+galval,
				cache: false,
				success: function(jsondata){
							  
				$("#imgs").html("");
				var jcol=0;
				$.each(jsondata,function(indx, element){
					$("#imgs").append('<div class="galleryel" imgid="'+element.id+'" style="width: 200px; height: 200px;"><div class="galleryimg" style="background: url(\'../img/upload/th/'+element.img+'\') center center no-repeat; background-size: cover; width: 200px; height: 140px; color: #000;">'+element.name+'</div><div class="gallerybtn"><div class="line-del" title="Удалить статью"></div><div class="clear"></div></div></div>');
					jcol++;
				});
				if (jcol>0) { $("#imgs").append('<div class="clear"></div>'); } else { $("#imgs").html("У данной категории нет элементов"); }
				}
				
			});
	}
	
	$("#page-submit-add").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			
				var data = $('#form-add').serialize();
				$.ajax({
				url: 'inc/pol-add-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$(".wait2").hide(0);
					PagesInfo(data);
					$("#pages-add").hide(0);
					Showimgs();
				}
				});
			
		});
		
	Showimgs();
		
	function PartAdd()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#page-submit-add").show(0);
		$("#waitadd").hide(0);
		$("#galvar").val($("#var").val());
		$("#galval").val($("#val").val());
		$("#resitem option").remove();
		var listid=$("#listid").val();
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/pol-edit.php',
		  data: 'listid='+listid,
		  cache: false,
		  success: function(jsondata){
		  
				if (jsondata && jsondata!="")
				{
				$.each(jsondata,function(indx, element){
					$("#resitem").append('<option value="'+element.id+'">'+element.name+'</option>');
					
				});
				$("#pages-add").show(0);
				}
				else
				{
				PagesInfo("Подходящих статей не найдено");
				}
		  }
		  });
					
	}
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			var delvar=$("#page-submit-del").attr("var");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/pol-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				Showimgs();
				PagesInfo("Статья успешно удалена");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function PartDel(imgid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#page-submit-del").show(0);
		
		$("#page-submit-del").attr("del",imgid);
		$("#pages-del").show(0);
	}
	
	
	
	
	
	$("#add-btn").click(function(){
		PartAdd();
	});
	

	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('imgid'));
	});
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
});