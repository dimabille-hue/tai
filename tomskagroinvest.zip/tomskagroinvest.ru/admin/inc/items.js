$("document").ready(function () {

	var sto;
	var pagelist=1;
	function PagesInfo(info)
		{
			clearTimeout(sto);
			$("#pages-info").show(300);
			$("#pages-info").html(info);
			sto=setTimeout(function(){
				$("#pages-info").html("");
				$("#pages-info").hide(0);
			}, 5000)
		}
		
		$("#pagedel-submit").click(
		function ()
		{
			$("#pagedel-submit").hide(0);
			$(".wait2").show(0);
			var delid=$("#pagedel-submit").attr("del");
			$("#pagedel-submit").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/items-del.php',
				data: 'delid='+delid,
				success: function(data){
				
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Товар успешно удален");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
		function PagesDel(parent)
	{
		$("#pagedel-submit").show(0);
		$(".wait2").hide(0);
		$("#delinf").html("");
		$("#pagedel-submit").attr("del","");
		$("#pages-add").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-del").hide(0);
		$.ajax({
				type: 'POST',
				url: 'inc/items-del-name.php',
				data: 'parent='+parent,
				dataType: 'json',
				success: function(data){
					if (data.undel==1)
					{
						$("#pages-del").show(0);
						$("#pagedel-submit").hide(0);
						$("#delname").html(data.name);
						$("#delinf").html("Данный товар защищен от удаления.");
					}
					else
					{
						$("#pages-del").show(0);
						$("#pagedel-submit").attr("del",parent);
						$("#delname").html(data.name);
					}
				}
				});
	}	
	function PagesUp(parent)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/items-up.php',
				data: 'parent='+parent,
				success: function(data){
					PagesPrint();
				}
				});
	}	
	function PagesDown(parent)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/items-down.php',
				data: 'parent='+parent,
				success: function(data){
					PagesPrint();
				}
				});
	}		
	function PagesPrint()
	{
		
		
	
		$("#blockcatalog").html("");
		$.ajax({
				  url: 'inc/items-col.php',
				  type: 'POST',
				  data : 'catid='+$("#catid").val(),
				  cache: false,
				  success: function(data){
					var pagecol=Math.ceil(data/20);
					if (pagecol>0)
					{
						if (pagelist>pagecol) { pagelist=pagecol; }
						if (pagelist<=0) { pagelist=1; }
						$("#pager1").html("");
						$("#pager2").html("");
						$("#blockcatalog").html('<div class="f08">Страница: <select class="pager" id="pager1"></select></div><div class="hem10"></div><div id="showcatalog"><div id="wait"><div class="hem30"></div><div class="ball"></div><div class="ball1"></div></div></div><div class="hem10"></div><div class="f08">Страница: <select class="pager" id="pager2"></select></div>')
						for (var i=1;i<=pagecol;i++)
						{
							var inj1="";
							if (i==pagelist) { inj1="selected"; }
							$("#pager1").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
							$("#pager2").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
						}
							
							$.ajax({
							  dataType: 'json',
							  url: 'inc/items-load.php',
							  type: 'POST',
							  data : 'pagelist='+pagelist+'&catid='+$("#catid").val(),
							  cache: false,
							  success: function(jsondata){
								$("#showcatalog").html("");
								$.each(jsondata,function(indx, element){
									var inj8="";
									if (element.hide=="1") { inj8=" line-name-hide"; } else { inj8=""; }
									$("#showcatalog").append('<div class="line" pageid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot"></div><div class="line-name2"><div class="line-name-text' + inj8 + ' ">' + element.name + '</div></div><div class="line-del" title="Удалить товар"></div><div class="line-edit" title="Редактировать товар"></div><div class="line-down" title="Опустить вниз"></div><div class="line-up" title="Поднять вверх"></div></div></div>');
				
									
								});
							  }});
							
						
					}
					else
					{
						$("#blockcatalog").html('<div class="f08">Не нашлось ни одного товара в этой категории</div>');
					}
				 }
				});
		
	}
	
	$(".pages-left").on("change","#pager1",function(){
		  pagelist=$(this).val();
		PagesPrint();
	});
	
	$(".pages-left").on("change","#pager2",function(){
		  pagelist=$(this).val();
		PagesPrint();
	});
	
	PagesPrint();
		
	$("#page-name").change(function(){
			$("#page-url").val(Name2Url($("#page-name").val()));
		});
		
		$("#page-edit-name").change(function(){
			$("#page-edit-url").val(Name2Url($("#page-edit-name").val()));
		});
		
		
	$("#page-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			var pagename, pageurl, pageparent;
			pagename=$("#page-name").val();
			pageurl=$("#page-url").val();
			$("#page-url2").val($("#page-url").val());
			if ((pagename!="") && (pageurl!=""))
			{
				var data = $('#form-page-add').serialize();
				$.ajax({
				url: 'inc/items-add.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$("#page-submit").show(0);
				PagesInfo("Товар с таким url уже существует");
				}
				else
				{
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Товар успешно добавлен");
				$("#pages-add").hide(0);
				}
				}
				});
			}
			else
			{
				PagesInfo("Товар не добавлен, возможно вы заполнили не все поля");
				$("#pages-add").hide(0);
				$(".wait2").hide(0);
			}
		});	
		
	function PagesAdd(parent)
	{
		$(".wait2").hide(0);
		$("#page-submit").show(0);
		$("#pages-add").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-del").hide(0);
		$("#pages-add").show(300);
		$("#page-url").val("");
		$("#page-url2").val("");
		$("#page-name").val("");
	}	
	
	function printopt(pageid)
	{
		$.ajax({
				  dataType: 'json',
				  url: 'inc/catalog-option.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="4") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="5") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#page-edit-parent2").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	$(".page-save").click(function(){
		
		$(".page-save").hide(0);
		$(".wait2").show(0);
		var pagename, pagecontent, pageurl, pagenewurl, pagesrt, pagehide, pageparent;
		//for ( instance in CKEDITOR.instances )
		CKEDITOR.instances['pages-edit-content'].updateElement();
		pagecontent = CKEDITOR.instances['pages-edit-content'].getData();
		$("#pages-edit-content").html(pagecontent);
		pagename=$("#page-edit-name").val();
		pageurl=$("#page-edit-url").val();
		$("#page-edit-url2").val($("#page-edit-url").val());
		
		$("[need]").map(function(indx, element){
			
			var iname = $(this).attr('need');
			CKEDITOR.instances[iname].updateElement();
			var j = CKEDITOR.instances[iname].getData();
			$("#"+iname).html(j);
		});
		
		var data = $('#form-page-edit').serialize();
		if (pagename!="")
		{
				
			$.ajax({
				url: 'inc/items-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$(".page-save").show(0);
				PagesInfo("Товар с таким url уже существует");
				}
				else
				{
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Товар успешно обновлен");
				$("#pages-edit").hide(0);
				}
				}
				});
		}
		else
		{
				PagesInfo("Товар не сохранен, возможно вы удалили «Заголовок товара»");
				$("#pages-edit").hide(0);
				$(".wait2").hide(0);
		}
		
	});
	
	function PagesEdit(parent)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$(".submit2").removeClass("op1");
		$("#oldpageimg").hide(0);
		$(".submit2[bid=1]").addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block1").show(300);
		
		
		$(".page-save").show(0);
		$(".wait2").hide(0);
				$("#page-edit-url").val("");
				$("#page-edit-name").val("");
				$("#pages-edit-content").val("");
				$("#pages-edit-parent").val("0");
				$("#pages-edit-srt").val("0");
				$("#pages-edit-price").val("0");
				$("#pages-edit-art").val("");
				$("#metacontent").val("");
				$("#metaname").val("");
				$("#metah1").val("");
				$("#ckeblock").html("");
				$("#page-edit-hide").prop("checked", false);
				$("#page-edit-newurl").prop("checked", false);
				$("#page-edit-id").val(parent);
				
					$("#metaloader").parent().find(".img-info").html("Добавьте изображение");
					$("#metaloader").prop('value', null);
					$("#metaloader").parent().find(".iloadval").val("");
				
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/items-edit.php',
		  data: 'pageid='+parent,
		  cache: false,
		  success: function(jsondata){
			$.each(jsondata,function(indx, element){
				$("#page-edit-name").val(element.name);
				$("#page-edit-url").val(element.url);
				$("#pages-edit-srt").val(element.srt);
				$("#pages-edit-price").val(element.price);
				$("#pages-edit-art").val(element.art);
				$("#metacontent").val(element.metacontent);
				$("#metaname").val(element.metaname);
				$("#metah1").val(element.metah);
				if (element.hide=="1") { $("#page-edit-hide").prop("checked", true); }
				$("#page-edit-parent2").html("");
				printopt(element.parent);
				$("#page-edit-parent").val(element.parent);
				if (!element.content) { $("#ckeblock").html('<textarea name="pageseditcontent" id="pages-edit-content" rows="10" cols="80"></textarea>'); } else
				{ $("#ckeblock").html('<textarea name="pageseditcontent" id="pages-edit-content" rows="10" cols="80">' + element.content + '</textarea>'); }
				
				var editor;
				editor = CKEDITOR.replace('pages-edit-content',{
					removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Iframe,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
				});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				if (element.metaimg)
				{
					$("#oldpageimg").find(".imagsold").val(element.metaimg);
					$("#oldpageimg").find(".oldimg").css({'background':'url(../img/upload/th/'+element.metaimg+') center center no-repeat', 'background-size':'cover'});
					$("#oldpageimg").show(0);
				}
				
				$.ajax({
						  dataType: 'json',
						  type: 'POST',
						  url: 'inc/items-dop.php',
						  data: 'pageid='+parent,
						  cache: false,
						  success: function(injsondata){
							$.each(injsondata,function(indx, inelement){
								if (inelement.type==1 || inelement.type==2)
								{
									$("#dop-"+inelement.ident).val(inelement.content);
								}
								if (inelement.type==3)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Iframe,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==4)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==5)
								{
									$("#dop-"+inelement.ident).html("");
									//$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var ar = inelement.val.split(":");
									$.each(ar,function(indx, option){
										if (option==inelement.content)
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'" selected>'+option+'</option>');
										}
										else
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'">'+option+'</option>');
										}
									});
								}
								if (inelement.type==6)
								{
									if (inelement.content)
									{
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
										$("#oldimg-"+inelement.ident).find(".imagsold").val(inelement.content);
										$("#oldimg-"+inelement.ident).find(".oldimg").css({'background':'url(../img/upload/th/'+inelement.content+') center center no-repeat', 'background-size':'cover'});
										$("#oldimg-"+inelement.ident).show(0);
									}
									else
									{
										$("#oldimg-"+inelement.ident).hide(0);
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
									}
								}

									$("#filt-"+inelement.row+" option").each(function() {
										if(this.value==inelement.rowval) $("#filt-"+inelement.row+" [value='"+this.value+"']").attr("selected", "selected");
									});

								
							});
						  }
				});
				
				$("#modules").html("");
				$.ajax({
				  dataType: 'json',
				  type: 'POST',
				  url: 'inc/items-modules.php',
				  data: 'pageid='+parent,
				  cache: false,
				  success: function(jsondatad){
					var cl=0;
					$.each(jsondatad,function(indx, elementd){
						$("#modules").append('<a href="'+elementd.href+'"><div class="modulemin">'+elementd.name+'</div></a>');
						cl++;
					});
					$("#modules").append("<div class=clear></div>");
					if (cl==0)
					{
					$("#modules").html('<div class="f08">У данного товара нет прикреплённых модулей</div>');
					}
					else
					{
					$("#modules").append('<div class="hem10"></div><div class="f08 orange"><b>Внимание! Прежде чем переходить в модуль не забудьте сохранить товар</b></div>');
			
					}
				  }});
				
				$("#page-submit").show(0);
				$("#pages-add").hide(0);
				$("#pages-info").hide(0);
				$("#pages-del").hide(0);
				$("#pages-edit").show(300);
				
			});
		 }
		});
	}
	
	$(".imgdel").click(function(){
		$(this).parent().hide(0);
		$(this).parent().find(".imagsold").val("");
	});
	
	$("#but-add").click(function(){
		PagesAdd();
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PagesEdit($(this).parent().parent().attr('pageid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PagesDel($(this).parent().parent().attr('pageid'));
	});
	$(".pages-left").on("click",".line-up",function(){
		  PagesUp($(this).parent().parent().attr('pageid'));
	});
	$(".pages-left").on("click",".line-down",function(){
		  PagesDown($(this).parent().parent().attr('pageid'));
	});
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
	
	$(".submit2").click(function(){
		$(".submit2").removeClass("op1");
		$(this).addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block"+($(this).attr("bid"))).show(300);
	});
});