$("document").ready(function () {
var infoblockwidth, infoblockheight;
var stat1;
var advices = new Array();
var curadv=0;

function loadmain()
{
infoblockwidth=$(".pages-left").width();
infoblockheight=Math.ceil(infoblockwidth/2.5);
$("#info1").html('<div id="userstat" class="infoblock" style="width: '+infoblockwidth+'px; height: '+infoblockheight+'px"></div>');
$("#info2").html('<div id="bidstat" class="infoblock" style="width: '+infoblockwidth+'px; height: '+infoblockheight+'px"></div>');
loadUserStat("userstat","bidstat");
}

function loadadvices()
{
	$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/advices.php',
		  cache: false,
		  success: function(jsondata){
			var ik=0;
				$.each(jsondata,function(indx, element){
					advices[ik]=element.content;
					ik++;
				});
				if (ik>0)
				{
					$("#advice-text").html(advices[0]);
				}
			}
		  });
};

$("#newadvice").click(function(){
	curadv++;
	if (curadv==advices.length) 
	{
		curadv=0;
	}
	$("#advice-text").html(advices[curadv]);
});

loadadvices();
loadmain();

$(window).resize(function(){
	loadmain();
});

function loadUserStat(blockid,blockid2)
{
$("#"+blockid).html('<div class="h30"></div><div class="h30"></div><div class="ball"></div><div class="ball1"></div>');
$("#"+blockid2).html('<div class="h30"></div><div class="h30"></div><div class="ball"></div><div class="ball1"></div>');

if (stat1)
{
	drowstat(blockid,stat1);
	drowstat2(blockid2,stat1);
}
else
{
$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/stat-users.php',
		  cache: false,
		  success: function(jsondata){
				
						if (jsondata)
						{
							stat1=jsondata;
							drowstat(blockid,jsondata);
							drowstat2(blockid2,jsondata);
						}
				
			}
		  });
}

}

function drowstat(blockid,jsondata)
{
(function basic_bars(container, horizontal) {

  var
    horizontal = (horizontal ? true : false), // Show horizontal bars
    d1 = [],                                  // First data series
    d2 = [],                                   // First data series
    point;                                    // Data point variable declaration
	var k=0;
	var monthsz = new Array();
	$.each(jsondata,function(indx, element){
		point = [k, parseInt(element.users)];
		monthsz[k]=element.name;
		if ((k%2)==0) 
		{
		d1.push(point);
		}
		else
		{
		d2.push(point);
		}
		k++;
	});
	
	       
  // Draw the graph
  Flotr.draw(
    container,
    [d1, d2],
    {
	  colors: ['#FF8331','#00D303','#A32818','#1245C1','#C1339F'],
	  fontColor: '#EEEEEE',
      bars : {
        show : true,
        horizontal : horizontal,
        shadowSize : 0,
        barWidth : 0.7
      },
      mouse : {
        track : true,
        relative : true,
		trackFormatter: function (x) {
			

			return Math.ceil(x.y)+" чел.";
		 }
      },
      yaxis : {
        min : 0,
		color: '#FFFFFF',
        autoscaleMargin : 1
      },
	  xaxis : {
		noTicks: 10,
		color: '#FFFFFF',
		autoscale: true,
		 tickFormatter: function (x) {
			var cur = (parseInt(x))%12;

			return monthsz[cur];
		 }
	  },
	  grid : {
	  color: '#a092b6',
	  tickColor: '#a092b6'
	  }
    }
  );
})(document.getElementById(blockid));
}

function drowstat2(blockid,jsondata)
{
(function basic_bars(container, horizontal) {

  var
    horizontal = (horizontal ? true : false), // Show horizontal bars
    d1 = [],                                  // First data series
    d2 = [],                                   // First data series
    point;                                    // Data point variable declaration
	var k=0;
	var monthsz = new Array();
	$.each(jsondata,function(indx, element){
		point = [k, parseInt(element.bid)];
		monthsz[k]=element.name;
		if ((k%2)==0) 
		{
		d1.push(point);
		}
		else
		{
		d2.push(point);
		}
		k++;
	});
	
	       
  // Draw the graph
  Flotr.draw(
    container,
    [d1, d2],
    {
	  colors: ['#FF8331','#00D303','#A32818','#1245C1','#C1339F'],
	  fontColor: '#EEEEEE',
      bars : {
        show : true,
        horizontal : horizontal,
        shadowSize : 0,
        barWidth : 0.7
      },
      mouse : {
        track : true,
        relative : true,
		trackFormatter: function (x) {
			

			return Math.ceil(x.y)+" шт.";
		 }
      },
      yaxis : {
        min : 0,
		color: '#FFFFFF',
        autoscaleMargin : 1
      },
	  xaxis : {
		noTicks: 10,
		color: '#FFFFFF',
		autoscale: true,
		 tickFormatter: function (x) {
			var cur = (parseInt(x))%12;

			return monthsz[cur];
		 }
	  },
	  grid : {
	  color: '#a092b6',
	  tickColor: '#a092b6'
	  }
    }
  );
})(document.getElementById(blockid));
}
});