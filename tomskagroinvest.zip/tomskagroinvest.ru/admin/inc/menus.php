<script type="text/javascript" src="inc/menus.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">МЕНЮ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=menus">Меню</a></div>
<div class="hem20"></div>
<div class="pages-left">
	<div id="menus-tree" unselectable="on" onselectstart="return false;"></div>
</div>
<div class="pages-right">
	<div id="pages-info" class="bigEntrance">
	</div>
	<div id="menus-add" class="bigEntrance">
		<div class="fl"><h3 class="m0">Добавление элемента меню</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-page-add">
			<input type="hidden" name="menuident" id="menuident">
			<div class="hem10"></div>
			<div class="afteri">Текст на кнопке:</div>
			<input id="page-name" name="pagename" type="text" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Текст будет отображаться на сайте</div>
			<div class="hem10"></div>
			<div class="afteri">Вложенность элемента:</div>
			<select id="page-parent" name="pageparent">
			</select>
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit">Создать элемент</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	<div id="menus-del" class="bigEntrance">
		<div class="fl"><h3 class="m0">Удаление элмента меню</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form">
			<div class="hem20"></div>
			Вы действительно хотите удалить элемент: <b><span id="delname"></span></b> ?<br><br>
			<div class="hem20"></div>
			<button class="submit" type="button" id="pagedel-submit" del="">Удалить элемент</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	<div id="menus-edit" class="bigEntrance" style="display: none;">
		<div class="fl"><h3 class="m0">Редактирование элемента меню</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form2" id="form-page-edit" enctype="multipart/form-data">
		<input id="menusid" type="hidden" value="0" name="menusid">
		<input id="menusident" type="hidden" value="0" name="menusident">
		<div class="hem10"></div>
		<div>
			<button class="submit2 op1" type="button" bid="1">Параметры</button>
			<button class="submit2" type="button" bid="2">Дополнительно</button>
			<button class="submit2" type="button" bid="3">Мета</button>
			<div class="clear"></div>
		</div>
		<div id="pages-block1" class="pages-block">
		
		<div class="hem10"></div>
			<div class="afteri">Текст на кнопке:</div>
			<input id="menusname" type="text" name="menusname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Текст будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">Тип ссылки:</div>
			<select name="menustype" id="menustype"><option value=0>На страницу сайта</option><option value=1>Внешняя ссылка</option></select>
			
			<div class="menustype1 none">
			<div class="hem10"></div>
			<div class="afteri">Ссылка на страницу сайта:</div>
			<select name="menuspage" id="menuspage"></select>
			</div>
			
			<div class="menustype2 none">
			<div class="hem10"></div>
			<div class="afteri">Внешняя ссылка:</div>
			<input id="menuslink" type="text" name="menuslink" placeholder="Введите текст в данное поле" required>
			<div class="form_hint">Например http://test1.ru</div>
			</div>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="menussrt" name="menussrt" type="text" placeholder="0" required />
			<div class="form_hint">Чем больше число в данном поле - тем выше будет элемент при сортировке</div>
			
			<div class="hem10"></div>
			<div class="afteri">Как открыть ссылку?</div>
			<select name="menustarget" id="menustarget"><option value=0>В текущей вкладке</option><option value=1>В новой вкладке</option></select>
			
			<div class="hem10"></div>
			<div class="afteri">Скрыть элемент:</div>
			<input type="checkbox" id="menushide" name="menushide"><span class="object_att"> - Элемент будет виден только в системе управления</span>
			
			<div class="hem10"></div>
			<div class="afteri">Вложенность элемента:</div>
			<select id="menusparent" name="menusparent">
			</select>
			
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block2" class="pages-block  none">
		<div id="dop">
		<div class="hem20"></div>
			<div class="f08">У данного меню нет дополнительных параметров</div>
		</div>	
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block3" class="pages-block  none">
		
		<div class="hem10"></div>
		<div class="afteri">Title:</div>
			<input id="menustitle" type="text" name="menustitle" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Более подробное описание, чем Alt</div>
		
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		</form>
	</div>
	<input type=hidden id="conf1" value="<?=$CONFIG['max_upload_images_width']?>">
	<input type=hidden id="conf2" value="<?=$CONFIG['max_upload_images_height']?>">
	<input type=hidden id="conf3" value="<?=$CONFIG['max_upload_images_size']?>">
	<input type=hidden id="conf4" value="<?=$CONFIG['resize_images_big']?>">
</div>
<div class="clear"></div>