<script type="text/javascript" src="inc/catalog.js"></script>
<? 
$sql=mysql_query("SELECT * FROM catalog_config2");
while ($record=mysql_fetch_array($sql))
{
	$ar[$record['ident']]=$record['content'];
}
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">КАТАЛОГ ОБЪЕКТОВ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=catalog">Каталог</a></div>
<div class="hem20"></div>
<div class="pages-left">
	<a href="index.php?page=search"><button class="submit" type="button" style="margin-right: 1em;">Поиск товара</button></a>
	<div class="hem10"></div>
	<div id="catalog-tree" unselectable="on" onselectstart="return false;"></div>
</div>
<div class="pages-right">
	<input type="hidden" id="maxlevel" value="<?=$ar['level']?>"> 
	<div id="wait" class="none">
	<div class="hem30"></div><div class="ball"></div><div class="ball1"></div>
	</div>
	
	<div id="pages-info" class="bigEntrance">
	</div>
	
	<div id="pages-add" class="bigEntrance">
		<div class="fl"><h3 class="m0">Добавление категории</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-page-add">
			<div class="hem10"></div>
			<div class="afteri">Заголовок категории:</div>
			<input id="page-name" name="pagename" type="text" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="page-url" name="pageurl" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="page-url2" name="pageurl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
				
			<div class="hem10"></div>
			<div class="afteri">Вложенность категории:</div>
			<select id="page-parent" name="pageparent">
			</select>
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit">Создать категорию</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	
	<div id="pages-del" class="bigEntrance">
		<div class="fl"><h3 class="m0">Удаление категории</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form">
			<div class="hem20"></div>
			Вы действительно хотите удалить категорию: <b><span id="delname"></span></b> ?<br><br>
			Все её подкатегории будут удалены.
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="pagedel-submit" del="">Удалить категорию</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	
	<div id="pages-edit" class="bigEntrance" style="display: none;">
		<div class="fl"><h3 class="m0">Редактирование категории</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form2" id="form-page-edit" enctype="multipart/form-data">
		<input id="page-edit-id" type="hidden" value="0" name="pageid">
		<div class="hem10"></div>
		<div>
			<button class="submit2 op1" type="button" bid="1">Параметры</button>
			<button class="submit2" type="button" bid="2">Содержание</button>
			<button class="submit2" type="button" bid="3">Дополнительно</button>
			<button class="submit2" type="button" bid="4">Модули</button>
			<button class="submit2" type="button" bid="5">Мета</button>
			<div class="clear"></div>
		</div>
		<div id="pages-block1" class="pages-block">
		
			<div class="hem10"></div>
			<div class="afteri">Заголовок категории:</div>
			<input id="page-edit-name" type="text" name="pageeditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="page-edit-url" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="page-edit-url2" name="pageediturl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
				
			<div class="hem10"></div>
			<div class="afteri">Изменить URL:</div>
			<input type="checkbox" id="page-edit-newurl" name="pagenewurl"><span class="object_att"> - Внимание, при изменении URL все ссылки на данную категорию перестанут работать.</span>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="pages-edit-srt" name="pagesrt" type="text" placeholder="0" required />
			<div class="form_hint">Чем больше число в данном поле - тем выше будет категория при сортировке</div>
			
			<div class="hem10"></div>
			<div class="afteri">Скрыть категорию:</div>
			<input type="checkbox" id="page-edit-hide" name="pagehide"><span class="object_att"> - Категория будет видна только в системе управления</span>
			
			<div class="hem10"></div>
			<div class="afteri">Вложенность категории:</div>
			<select id="page-edit-parent" name="pageeditparent">
			</select>
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		<div id="pages-block2" class="pages-block none">
		
			<div class="hem15"></div>
			<div id="ckeblock">
				
			</div>
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		<div id="pages-block3" class="pages-block none">
			<?
			echo '<div class="hem10"></div><div class="afteri">Прикрепить ленту:</div>
				<select id="cat-list" name="catlist">
				<option value="0">Без ленты</option>';
			$sql2=mysql_query("SELECT * FROM lists WHERE hide!=1 ORDER by id");
			while($record2=mysql_fetch_array($sql2))
			{
				echo '<option value="'.$record2['id'].'">'.$record2['ident'].'</option>';
			}
			echo '</select>';
			$sql=mysql_query("SELECT * FROM catalog_config ORDER by id");
			$i=0;
			while ($record=mysql_fetch_array($sql))
			{
				$i++;
				echo '<div class="hem10"></div>';
				if ($record['type']==1)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<input id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'" type="text" placeholder="Введите текст в данное поле"  />
					<div class="form_hint">'.$record['val'].'</div>
					';
				}
				elseif ($record['type']==2)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<textarea id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'" placeholder="Введите текст в данное поле"></textarea>
					<div class="form_hint">'.$record['val'].'</div>
					';
				}
				elseif ($record['type']==3)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<div id="dop-'.$record['ident'].'" need="dop-edit-'.$record['ident'].'"></div>
					';
				}
				elseif ($record['type']==4)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<div id="dop-'.$record['ident'].'" need="dop-edit-'.$record['ident'].'"></div>
					';
				}
				elseif ($record['type']==5)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<select id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'">
					</select>
					';
				}
				elseif ($record['type']==6)
				{	
					echo '<div class="afteri">'.$record['name'].':</div>';
					echo '<div class="iload">
						<input type="file" id="dop-'.$record['ident'].'" onchange="fileSelectHandler(this,'.$CONFIG['max_upload_images_width'].','.$CONFIG['max_upload_images_height'].','.$CONFIG['max_upload_images_size'].','.$record['val'].','.$CONFIG['resize_images_big'].',\'pagesdop\',\'oldimg-'.$record['ident'].'\')">';
						
						echo '
						<div class="img-info"></div>
						<input type="hidden" class="iloadval" name="dop-'.$record['ident'].'">
					</div>';
					
					echo '
					<div id="oldimg-'.$record['ident'].'" class="oldimghide">
					<div class="hem10"></div>
					<div class="afteri">Текущее изображение:</div>
					<div class="hem10"></div>
					<div class="oldimg"></div>
					<div class="imgdel f08 orange pointer">Удалить</div>
					<input type="hidden" class="imagsold" name="dopold-'.$record['ident'].'">
					</div>';
				}
			}
			if (!$i) echo '<div class="hem20"></div>
			<div class="f08">У данной категории нет дополнительных параметров</div>';
			?>
			
			
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block4" class="pages-block none">
			<div class="hem10"></div>
			<p><b>Доступные модули данного товара:</b></p>
			<div class="hem10"></div>
			<div id="modules">
				<div class="f08">У данного товара нет прикреплённых модулей</div>
			</div>
			<div class="hem20"></div>
		</div>
		<div id="pages-block5" class="pages-block none">
			<div class="hem10"></div>
			<div class="afteri">Мета-заголовок категории:</div>
			<input id="metaname" name="metaname" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием страницы</div>
			<div class="hem10"></div>
			<div class="afteri">Заголовок h1:</div>
			<input id="metah1" name="metah1" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием страницы</div>
			<div class="hem10"></div>
			<div class="afteri">Мета-описание категории:</div>
			<textarea id="metacontent" name="metacontent" placeholder="Введите текст в данное поле"  /></textarea>
			<div class="form_hint">Мета-описания не должны быть короткими, в несколько слов.<br>Должны описывать конкретную страницу сайта, а не сайт в целом.<br><br>Мета-описания должны быть емкими и при этом содержательными. Старайтесь выразить основную суть категории в нескольких предложениях.</div>
			
			<div class="hem10"></div>
			<div class="afteri">Мета-изображение:</div>
			<div class="iload">
				<input type="file" id="metaloader" onchange="fileSelectHandler(this,<?=$CONFIG['max_upload_images_width']?>,<?=$CONFIG['max_upload_images_height']?>,<?=$CONFIG['max_upload_images_size']?>,<?=$CONFIG['meta_images_width']?>,<?=$CONFIG['meta_images_height']?>,<?=$CONFIG['resize_images_big']?>,'catmeta','oldpageimg')">
				<div class="img-info"></div>
				<input type="hidden" class="iloadval" name="metaimages">
			</div>
			<div id="oldpageimg">
			<div class="hem10"></div>
			<div class="afteri">Текущее изображение:</div>
			<div class="hem10"></div>
			<div class="oldimg"></div>
			<div class="imgdel f08 orange pointer">Удалить</div>
			<input type="hidden" class="imagsold" name="metaimagesold">
			</div>
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		</form>
	</div>
</div>
<div class="clear"></div>