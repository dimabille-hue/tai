<script type="text/javascript" src="inc/options.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">КОНСТРУКТОР</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=construct">Конструктор</a></div>
<div class="hem10"></div>
<form class="object_form" name="object_form1" id="form-options1">
	<h3>Основные блоки</h3>
	<div class="hem10"></div>
	<div class="afteri">Текст на логотипе:</div>
	<input id="sitename" name="sitename" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: Авто-гид</div>
	
	<div class="hem10"></div>
	<div class="afteri">Цветовая схема:</div>
	<select id="colorscheme" name="colorscheme">
		<option value="0">Схема 1</option>
		<option value="1">Схема 2</option>
		<option value="2">Схема 3</option>
		<option value="3">Схема 4</option>
		<option value="4">Схема 5</option>
		<option value="5">Схема 6</option>
	</select>
	
	<div class="hem10"></div>
	
	<img src="img/scheme.png" width="700" height="300">	
	
	<div class="hem20"></div>
	<div class="afteri">Выберите шрифт:</div>
	<select id="font" name="font">
		<option value="0">Exo 2</option>
		<option value="1">Circe</option>
		<option value="2">PT Sans</option>
	</select>
	
	<div class="hem10"></div>
	
	<img src="img/fonts.png" width="700" height="300">	
	

	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	
	
	<div class="hem20"></div>
	<h3>Меню</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант меню:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1 с прозрачным фоном</option>
		<option value="1">Вариант 2 со светлым фоном меню сбоку</option>
		<option value="2">Вариант 3 со светлым фоном меню снизу</option>
		<option value="3">Вариант 4 с тёмным фоном меню сбоку</option>
	</select>
	
	<div class="hem10"></div>
	<div class="afteri">Показывать телефон:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Да</option>
		<option value="1">Нет</option>
	</select>
	
	<div class="hem10"></div>
	<div class="afteri">Показывать соц. кнопки:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Да</option>
		<option value="1">Нет</option>
	</select>

	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	
	
	
	<div class="hem20"></div>
	<h3>Слайдер</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите высоту слайдера меню:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">750px</option>
		<option value="1">560px</option>
		<option value="2">400px</option>
	</select>
	
	
	<div class="hem10"></div>
	<div class="afteri">Выберите тип стрелок на слайдере:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Без стрелок</option>
		<option value="1">Вариант 1</option>
		<option value="2">Вариант 2</option>
	</select>
	
	<div class="hem10"></div>
	<div class="afteri">Тип точек на слайдере:</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Без точек</option>
		<option value="1">Круглые точки</option>
		<option value="2">Квадратные точки</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	
	<div class="hem20"></div>
	<h3>Преимущества</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант оформления</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1</option>
		<option value="1">Вариант 2</option>
		<option value="2">Вариант 3</option>
		<option value="3">Вариант 4</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	<div class="hem20"></div>
	<h3>Видео и информация</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант оформления</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1</option>
		<option value="1">Вариант 2</option>
		<option value="2">Вариант 3</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	<div class="hem20"></div>
	<h3>Отзывы клиентов</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант оформления</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1</option>
		<option value="1">Вариант 2</option>
		<option value="2">Вариант 3</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	
	<div class="hem20"></div>
	<h3>Контактная информация и футер</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант оформления</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1</option>
		<option value="1">Вариант 2</option>
		<option value="2">Вариант 3</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
	
	
	<div class="hem20"></div>
	<h3>Форма заявки</h3>
	<div class="hem10"></div>
	<div class="afteri">Выберите вариант оформления</div>
	<select id="menustyle" name="menustyle">
		<option value="0">Вариант 1</option>
		<option value="1">Вариант 2</option>
	</select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
		<div class="mball"></div>
	</div>
	<div class="hem20"></div>
	<hr style="opacity: 0.4"><div style="height:3px;"></div><hr style="opacity: 0.4">
	
</form>

<div id="opt-info1" class="options bigEntrance"></div>

	
	<div class="clear"></div>
</form>