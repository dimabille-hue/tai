<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	$sql=mysql_query("SELECT undel FROm pages WHERE id='$delid'");
	$record=mysql_fetch_array($sql);
	if ($record['undel']!=1)
	{
	     mysql_query("DELETE FROM pages WHERE id='$delid'");
	}
?>