$("document").ready(function () {

	var sto;	
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#info").show(300);
		$("#info").html(info);
		sto=setTimeout(function(){
			$("#info").html("");
			$("#info").hide(0);
		}, 5000)
	}
	
	function previ()
	{	
		$("#current").html("");
		$.ajax({
			url: 'inc/watermark-get.php',
			type: "POST",
			processData: false,
			contentType: false,
			cache: false,
			success: function(data){
				if (data=="0")
				{
					$("#current").html('<div class="f08">Водяной знак не загружен</div>');
				}
				else
				{
					$("#current").html('<div class="waterdemo" style="background: url(\'../img/upload/'+data+'\') center center no-repeat; background-size: 70%;"></div>');
				}
			}
		});
	}
	
	$(".submit").click(function(){
	$(".submit").hide(0);
	$("#wait").show(0);
	var data = $('#form-part').serialize();
		$.ajax({
				url: 'inc/watermark-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".submit").show(0);
					$("#wait").hide(0);
					previ();
					PagesInfo(data);
				}
				});
	});

	$("#newimg").change(function(){
		var fd = new FormData();
		fd.append("loadimg", $("#newimg")[0].files[0]);
		$.ajax({
			url: 'inc/watermark-load.php',
			type: "POST",
			data: fd,
			dataType: 'json',
			processData: false,
			contentType: false,
			cache: false,
			success: function(res){
			$("#newimg").parent().find(".img-info").html(res.result);
			$("#newimg").parent().find(".iloadval").val(res.name);
			}
		});
	});
	
	previ();
});
