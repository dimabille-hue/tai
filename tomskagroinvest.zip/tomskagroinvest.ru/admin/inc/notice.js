$("document").ready(function () {
	var sto;
	
	var pagelist=1;
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	function ShowNotice()
	{
		
	
		$("#blocknotice").html("");
		$.ajax({
				  url: 'inc/notice-col.php',
				  cache: false,
				  success: function(data){
					var pagecol=Math.ceil(data/20);
					if (pagecol>0)
					{
						if (pagelist>pagecol) { pagelist=pagecol; }
						if (pagelist<=0) { pagelist=1; }
						$("#pager1").html("");
						$("#pager2").html("");
						$("#blocknotice").html('<div class="f08">Страница: <select class="pager" id="pager1"></select></div><div class="hem10"></div><div id="shownotice"><div id="wait"><div class="hem30"></div><div class="ball"></div><div class="ball1"></div></div></div><div class="hem10"></div><div class="f08">Страница: <select class="pager" id="pager2"></select></div>')
						for (var i=1;i<=pagecol;i++)
						{
							var inj1="";
							if (i==pagelist) { inj1="selected"; }
							$("#pager1").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
							$("#pager2").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
						}
						
							$.ajax({
							  dataType: 'json',
							  url: 'inc/notice-load.php',
							  type: 'POST',
							  data : 'pagelist='+pagelist,
							  cache: false,
							  success: function(jsondata){
								$("#shownotice").html("");
								$.each(jsondata,function(indx, element){
									var inj8='';
									if (element.shows=="0") 
									{
										inj8='new';
									}
									$("#shownotice").append('<div class="line" noticeid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot'+inj8+'"></div><div class="line-name2"><div class="line-name-text">' + element.name + ' <span class="f07 gray">' + element.timestamp+ '</span></div></div><div class="line-del" title="Удалить уведомление"></div><div class="line-show" title="Посмотреть уведомление"></div></div></div>');
				
									
								});
							  }});
							
						
					}
					else
					{
						$("#blocknotice").html('<div class="f08">Не нашлось ни одного уведомления</div>');
					}
				 }
				});
		
	}
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/notice-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				ShowNotice();
				PagesInfo("Уведомление успешно удалено");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function PartDel(noticeid)
	{
		$("#pages-del").hide(0);
		$("#options").hide(0);
		$(".wait2").hide(0);
		$("#page-submit-del").show(0);
		$.ajax({
				type: 'POST',
				url: 'inc/notice-del-name.php',
				data: 'delid='+noticeid,
				dataType: 'json',
				success: function(data){
						$("#pages-del").show(0);
						$("#page-submit-del").attr("del",noticeid);
						$("#delname").html(data.name);
				}
				});
	}
	
	function unshow(noticeid)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/notice-unshow.php',
				data: 'delid='+noticeid,
				success: function(data){
					ShowNotice();
				}
				});
	}
	
	function PartOpt(noticeid)
	{
		$("#pages-del").hide(0);
		$("#options").hide(0);
		$(".wait2").hide(0);
		$("#noticename").html("");
		$("#noticecontent").html("");
		$("#noticepart").html("");
		$("#noticetimestamp").html("");
		$.ajax({
				type: 'POST',
				url: 'inc/notice-show.php',
				data: 'delid='+noticeid,
				dataType: 'json',
				success: function(data){
						$("#options").show(0);
						
					$("#noticename").html(data.name);
					$("#noticecontent").html(data.content);
					$("#noticetimestamp").html("Дата отправки: "+data.timestamp);
					$("#noticepart").html(data.part);
					unshow(noticeid);
				}
				});
		
	}
	
	$(".pages-left").on("change","#pager1",function(){
		  pagelist=$(this).val();
		ShowNotice();
	});
	
	$(".pages-left").on("change","#pager2",function(){
		  pagelist=$(this).val();
		ShowNotice();
	});
	
	$(".pages-left").on("click",".line-show",function(){
		  PartOpt($(this).parent().parent().attr('noticeid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('noticeid'));
	});
	
	$("#updatenotice").click(function(){
		ShowNotice();
	});
	
	ShowNotice();
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
	
	});