<?
include('access.php');
if ($_SERVER['REQUEST_METHOD']=="POST")
{
	if ($_POST['formname'] && $_POST['formname']!="")
	{
		$formname=filt($_POST['formname']);
		mysql_query("INSERT INTO forms (ident) VALUES ('$formname')");
	}
	
	if ($_POST['listname'] && $_POST['listname']!="")
	{
		$listname=filt($_POST['listname']);
		$listtype=(int)$_POST['listtype'];
		if ($listtype==1)
		{
		$imgsize=$CONFIG['listimgsize1'];
		mysql_query("INSERT INTO lists (ident, imgsize, showdescript, showtimestamp, showopt) VALUES ('$listname', '$imgsize', '1', '1', '1')");
		}
		else
		{
		$imgsize=$CONFIG['listimgsize0'];
		mysql_query("INSERT INTO lists (ident, imgsize, showopt) VALUES ('$listname','$imgsize', '1')");
		}
	}
}
if ($_GET['delform'])
{
	$delform=(int)$_GET['delform'];
	if ($delform>0)
	{
		mysql_query("DELETE FROM forms WHERE id='$delform'");
	}
}
if ($_GET['dellist'])
{
	$dellist=(int)$_GET['dellist'];
	$sql=mysql_query("SELECT * FROM lists WHERE id='$dellist'");
	$record=mysql_fetch_array($sql);
	if ($record['undel']!=1)
	{
	if ($dellist>0)
	{
		mysql_query("DELETE FROM lists WHERE id='$dellist'");
	}
	}
}

if ($_GET['part']=="social") include('social.php');
elseif ($_GET['part']=="maps") include('maps.php');
elseif ($_GET['part']=="watermark") include('watermark.php');
elseif ($_GET['part']=="faq") include('faq.php');
elseif ($_GET['part']=="reviews") include('reviews.php');
elseif ($_GET['part']=="addform") include('addform.php');
elseif ($_GET['part']=="addlist") include('addlist.php');
elseif ($_GET['part']=="addgallery") include('addgallery.php');
elseif ($_GET['part']=="form" && $_GET['id']) include('form.php');
elseif ($_GET['part']=="list" && $_GET['id']) include('list.php');
elseif ($_GET['part']=="gallery") include('gallery.php');
elseif ($_GET['part']=="catalog") include('catalog.php');
elseif ($_GET['part']=="filt") include('filt.php');
elseif ($_GET['part']=="sop") include('sop.php');
elseif ($_GET['part']=="polez") include('pol.php');
else
{
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">МОДУЛИ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a></div>
<div class="hem10"></div>
<h3>Общие модули</h3>
<div class="hem10"></div>
<?
$sql=mysql_query("SELECT * FROM parts_config WHERE type<=3 and val!=1 order by type, id");
while ($record=mysql_fetch_array($sql))
{
	echo '<a href="index.php?page=parts&part='.$record['ident'].'"><div class="module"><div class="module-icon'.$record['type'].'"></div><div class="module-name">'.$record['name'].'</div><div class="clear"></div></div></a>';
}
?>
<div class="clear"></div>
<? 
$sql=mysql_query("SELECT * FROM parts_config WHERE ident='list'");
$record=mysql_fetch_array($sql);
if ($record['val']!=1)
{
echo '<h3>'.$record['name'].'</h3><div class="hem10"></div>';

$sql2=mysql_query("SELECT * FROM lists order by id");
while ($record2=mysql_fetch_array($sql2))
{
		echo '<a href="index.php?page=parts&part=list&id='.$record2['id'].'"><div class="module"><div class="module-icon5"></div><div class="module-name">'.$record2['ident'].'</div><div class="clear"></div></div></a>';
}

$sql2=mysql_query("SELECT * FROM parts_config WHERE ident='addlist'");
$record2=mysql_fetch_array($sql2);
if ($record2['val']!=1)
{
	echo '<a href="index.php?page=parts&part='.$record2['ident'].'"><div class="module"><div class="module-icon'.$record2['type'].'"></div><div class="module-name">'.$record2['name'].'</div><div class="clear"></div></div></a>';
}
echo '<div class="clear"></div>';
}

$sql=mysql_query("SELECT * FROM parts_config WHERE ident='form'");
$record=mysql_fetch_array($sql);
if ($record['val']!=1)
{
echo '<h3>'.$record['name'].'</h3><div class="hem10"></div>';

$sql2=mysql_query("SELECT * FROM forms order by id");
while ($record2=mysql_fetch_array($sql2))
{
		echo '<a href="index.php?page=parts&part=form&id='.$record2['id'].'"><div class="module"><div class="module-icon5"></div><div class="module-name">'.substr($record2['ident'],0,30).'</div><div class="clear"></div></div></a>';
}

$sql2=mysql_query("SELECT * FROM parts_config WHERE ident='addform'");
$record2=mysql_fetch_array($sql2);
if ($record2['val']!=1)
{
	echo '<a href="index.php?page=parts&part='.$record2['ident'].'"><div class="module"><div class="module-icon'.$record2['type'].'"></div><div class="module-name">'.$record2['name'].'</div><div class="clear"></div></div></a>';
}
echo '<div class="clear"></div>';
}
}
?>

