<script type="text/javascript" src="inc/options.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">НАСТРОЙКИ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=options">Настройки</a></div>
<div class="hem10"></div>
<div class="pages-left">
<form class="object_form" name="object_form1" id="form-options1">
	<h3>Основные настройки</h3>
	<input type="hidden" name="part" value="1">
	<div class="hem10"></div>
	<div class="afteri">Название сайта:</div>
	<input id="sitename" name="sitename" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: Официальный сайт ГК «Технологии»</div>
	
	<div class="hem10"></div>
	<div class="afteri">Основное доменное имя сайта:</div>
	<input id="sitedomains" name="sitedomains" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: http://website.ru</div>	
	
	<div class="hem10"></div>
	<div class="afteri">Основной e-mail для отправки данных:</div>
	<input id="emailsend" name="emailsend" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: myemail@mail.ru</div>	
	
	<div class="hem10"></div>
	<div class="afteri">Дополнительный e-mail для отправки данных:</div>
	<input id="emailsend2" name="emailsend2" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: myemail@mail.ru</div>	
	
	<div class="hem10"></div>
	<div class="afteri">Контактные данные для связи:</div>
	<textarea id="admincontacts" name="admincontacts" type="text"  required></textarea>
	<div class="form_hint">Введите сюда ФИО контактного лица (владельца сайта), номер телефона и e-mail. Информация будет видна только разработчикам проекта.</div>
	<?
		if ($_SESSION['login']==$CONFIG['rootlogin'])
		{
	?>
	<div class="hem10"></div>
	<div class="afteri">Код перед закрывающимся тегом body:</div>
	<textarea id="adminafter" name="adminafter" type="text"  required></textarea>
	<div class="form_hint">Введите сюда данные для отображении их в разделе after.</div>
	
	<div class="hem10"></div>
	<div class="afteri">Код в начале сайта:</div>
	<textarea id="adminbefore" name="adminbefore" type="text"  required></textarea>
	<div class="form_hint">Введите сюда данные для отображении их в разделе before.</div>
	<? } ?>
	<div class="hem20"></div>
	<button class="submit" type="button" part="1">Сохранить</button>
	<div class="wait2 none" id="wait1">
				<div class="mball"></div>
			</div>
</form>

<div id="opt-info1" class="options bigEntrance"></div>
</div>
	
<div class="pages-right">
<form class="object_form" name="object_form2" id="form-options2">
<h3>Дополнительные настройки</h3>
<input type="hidden" name="part" value="2">
<div class="hem10"></div>
	<div class="afteri">Общий мета-заголовок сайта:</div>
	<input id="metatitle" name="metatitle" type="text" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Например: ГК «Технологии» продажа технологий, товаров для оптимизации предприятий</div>
		
		
	<div class="hem10"></div>
	<div class="afteri">Общее мета-описание сайта:</div>
	<textarea id="metadescript" name="metadescript" type="text" placeholder="Введите текст в данное поле" required ></textarea>
	<div class="form_hint">Будет установлено для всех страниц, где не заполнено поле "Мета-описание"</div>
	
	<div class="hem10"></div>
	<div class="afteri">Состояние сайта:</div>
	<select id="siteblock" name="siteblock"><option value=0>Работает</option><option value=1>Технические работы</option></select>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="2">Сохранить</button>
	<div class="wait2 none" id="wait2">
				<div class="mball"></div>
			</div>
</form>
<div id="opt-info2" class="options bigEntrance" style="margin-bottom:0;">
	</div>
	<div class="hem20"></div>
<form class="object_form" name="object_form3" id="form-options3">
<input type="hidden" name="part" value="3">
	<h3>Изменение пароля</h3>
	
	<div class="hem10"></div>
	<div class="afteri">Старый пароль администратора:</div>
	<input id="adminold" name="adminold" type="password" placeholder="Введите текст в данное поле" required />
	
	<div class="hem10"></div>
	<div class="afteri">Новый пароль администратора:</div>
	<input id="adminpass" name="adminpass" type="password" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Пароль не менее 8 латинских символов или цифр</div>
	
	<div class="hem10"></div>
	<div class="afteri">Повтор нового пароля:</div>
	<input id="adminpass2" name="adminpass2" type="password" placeholder="Введите текст в данное поле" required />
	<div class="form_hint">Пароль не менее 8 латинских символов или цифр</div>
	
	<div class="hem20"></div>
	<button class="submit" type="button" part="3">Изменить пароль</button>
	<div class="wait2 none" id="wait3">
				<div class="mball"></div>
			</div>
</form>
<div id="opt-info3" class="options bigEntrance">
	</div>
	</div>
	<div class="clear"></div>
</form>