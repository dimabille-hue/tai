<?
	include('../cfg.php');
	include('access.php');
	$arr = array();
	$key=0;
	$ident=filt($_POST['ident']);
	$sql=mysql_query("SELECT * FROM menus_config WHERE ident='$ident'");
	$record=mysql_fetch_array($sql);
	$max=$record['level'];
	
	function tray($parent,$level)
	{
		global $arr, $key, $ident, $max;
		$sql=mysql_query("SELECT id, name, parent FROM menus WHERE (parent='$parent' and menu='$ident') ORDER BY ID");
		while ($record=mysql_fetch_array($sql))
		{
			$arr[$key]['id']=$record['id'];
			$arr[$key]['parent']=$record['parent'];
			$arr[$key]['name']=$record['name'];
			$arr[$key]['level']=$level;
			$sql2=mysql_query("SELECT COUNT(*) FROM menus WHERE (parent='".$record['id']."' and menu='$ident') ORDER BY ID");
			$record2=mysql_fetch_row($sql2);
			if ($record2[0] && $level<($max-2))
			{
			$key++;
		    tray($record['id'],$level+1);
			
			}
			else $key++;
		}
	}
	if ($max>1) tray(0,0);
	
	
	header('Content-Type: application/json');
	echo json_encode($arr);
?>