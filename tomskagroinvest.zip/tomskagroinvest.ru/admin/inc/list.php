<script type="text/javascript" src="inc/list.js"></script>
<?
$id=(int)$_GET['id'];
$sql=mysql_query("SELECT * FROM lists WHERE id='$id'");
$record=mysql_fetch_array($sql);
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">ЛЕНТА «<?=$record['ident']?>»</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=list&id=<?=$id?>">Лента «<?=$record['ident']?>»</a></div>
<div class="hem10"></div>
<input type="hidden" id="listid" value="<?=$id?>">
<div class="pages-left">
<?
if ($record['info']) echo '<div class="hem10"></div><div class="f08">'.$record['info'].'</div><div class="hem10"></div>';
?>
<div class="hem10"></div>
<button class="submit" type="button" id="but-opt" style="margin-right: 1em;">Настройки ленты</button> <?if ($record['undel']!=1) echo '<button class="submit" type="button" id="but-del">Удалить ленту</button>';?>
<div class="clear"></div>
<div class="hem10"></div>
<h3>Элементы ленты</h3>
<div class="hem10"></div>
<div id="rows">
</div>
<div class="hem20"></div>
<button class="submit" type="button" id="but-add" style="margin-right: 1em;">Добавить элемент</button>
</div>
<div class="pages-right">
<div id="pages-info" class="bigEntrance"></div>
<div id="pages-edit" class="bigEntrance" style="display: none;">
		<div class="fl"><h3 class="m0">Редактирование элемента</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form2" id="form-page-edit" enctype="multipart/form-data">
		<input id="eleditid" type="hidden" value="0" name="eleditid">
		<div class="hem10"></div>
		<div>
			<button class="submit2 op1" type="button" bid="1">Параметры</button>
			<? if ($record['showcontent']==0 || $record['showdescript']==0) echo '<button class="submit2" type="button" bid="2">Содержание</button>';?>
			<? if ($record['undel']==1) echo '<button class="submit2" type="button" bid="3">Дополнительно</button>';?>
			<? if ($record['showcontent']==0) echo '<button class="submit2" type="button" bid="5">Модули</button>';?>
			<? if ($record['showmeta']==0) echo '<button class="submit2" type="button" bid="4">Мета</button>';?>
			<div class="clear"></div>
		</div>
		<div id="pages-block1" class="pages-block">
		<div class="hem10"></div>
		
			<div class="afteri">Заголовок элемента:</div>
			<input id="eleditname" type="text" name="eleditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<?
			if ($record['showurl']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="elediturl" name="elediturl" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="elediturl2" name="elediturl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
				
			<div class="hem10"></div>
			<div class="afteri">Изменить URL:</div>
			<input type="checkbox" id="eleditnewurl" name="eleditnewurl"><span class="object_att"> - Внимание, при изменении URL все ссылки на данный элемент перестанут работать.</span>
			</div>
			
			<? if ($record['showimg']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">Изображение элемента:</div>
			<div class="iload">
				<input type="file" id="loaderz" onchange="fileSelectHandler(this,<?
				if ($record['maximgsize'])
				echo $record['maximgsize']; else echo $CONFIG['max_upload_images_width'].",".$CONFIG['max_upload_images_height'];
				?>,<?=$CONFIG['max_upload_images_size']?>,<?=$record['imgsize']?>,<?=$CONFIG['resize_images_big']?>,'list','imgold')">
				<div class="img-info"></div>
				<input type="hidden" class="iloadval" name="imgz">
			</div>
			<div id="imgold">
			<div class="hem10"></div>
			<div class="afteri">Текущее изображение:</div>
			<div class="hem10"></div>
			<div class="oldimg"></div>
			<div class="imgdel f08 orange pointer">Удалить</div>
			<input type="hidden" class="imagsold" name="imgzold">
			</div>
			</div>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="eleditsrt" name="eleditsrt" type="text" placeholder="0" required />
			<div class="form_hint">Чем больше число в данном поле - тем выше будет элемент при сортировке</div>
			<?
			if ($record['showtimestamp']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">Дата и время создания:</div>
			<input id="eledittimestamp" type="text" name="eledittimestamp">
			</div>
			<div class="hem10"></div>
			<div class="afteri">Скрыть страницу:</div>
			<input type="checkbox" id="eledithide" name="eledithide"><span class="object_att"> - Элемент будет виден только в системе управления</span>
			
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block2" class="pages-block none">
			<?
			if ($record['showdescript']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">Краткое описание:</div>
			<div id="ckeblock">
			</div>
			</div>
			<?
			if ($record['showcontent']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">Подробное описание:</div>
			<div id="ckeblock2">
			</div>
			</div>
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block3" class="pages-block none">
		<?
			$sql2=mysql_query("SELECT * FROM lists_config WHERE listid='$id' ORDER by id");
			$i=0;
			while ($record2=mysql_fetch_array($sql2))
			{
				$i++;
				echo '<div class="hem10"></div>';
				if ($record2['type']==1)
				{
					echo '
					<div class="afteri">'.$record2['name'].':</div>
					<input id="dop-'.$record2['ident'].'" name="dop-'.$record2['ident'].'" type="text" placeholder="Введите текст в данное поле"  />
					<div class="form_hint">'.$record2['val'].'</div>
					';
				}
				elseif ($record2['type']==2)
				{
					echo '
					<div class="afteri">'.$record2['name'].':</div>
					<textarea id="dop-'.$record2['ident'].'" name="dop-'.$record2['ident'].'" placeholder="Введите текст в данное поле"></textarea>
					<div class="form_hint">'.$record2['val'].'</div>
					';
				}
				elseif ($record2['type']==3)
				{
					echo '
					<div class="afteri">'.$record2['name'].':</div>
					<div id="dop-'.$record2['ident'].'" need="dop-edit-'.$record2['ident'].'"></div>
					';
				}
				elseif ($record2['type']==4)
				{
					echo '
					<div class="afteri">'.$record2['name'].':</div>
					<div id="dop-'.$record2['ident'].'" need="dop-edit-'.$record2['ident'].'"></div>
					';
				}
				elseif ($record2['type']==5)
				{
					echo '
					<div class="afteri">'.$record2['name'].':</div>
					<select id="dop-'.$record2['ident'].'" name="dop-'.$record2['ident'].'">
					</select>
					';
				}
				elseif ($record2['type']==6)
				{	
					echo '<div class="afteri">'.$record2['name'].':</div>';
					echo '<div class="iload">
						<input type="file" id="dop-'.$record2['ident'].'" onchange="fileSelectHandler(this,'.$CONFIG['max_upload_images_width'].','.$CONFIG['max_upload_images_height'].','.$CONFIG['max_upload_images_size'].','.$record2['val'].','.$CONFIG['resize_images_big'].',\'listsdop\',\'oldimg-'.$record2['ident'].'\')">';
						
						echo '
						<div class="img-info"></div>
						<input type="hidden" class="iloadval" name="dop-'.$record2['ident'].'">
					</div>';
					
					echo '
					<div id="oldimg-'.$record2['ident'].'" class="oldimghide">
					<div class="hem10"></div>
					<div class="afteri">Текущее изображение:</div>
					<div class="hem10"></div>
					<div class="oldimg"></div>
					<div class="imgdel f08 orange pointer">Удалить</div>
					<input type="hidden" class="imagsold" name="dopold-'.$record2['ident'].'">
					</div>';
				}
			}
			if (!$i) echo '<div class="hem20"></div>
			<div class="f08">У данной страницы нет дополнительных параметров</div>';
			?>
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block4" class="pages-block none">
		<div class="hem10"></div>
			<div class="afteri">Мета-заголовок элемента:</div>
			<input id="elmetaname" name="elmetaname" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием элемента</div>
			<div class="hem10"></div>
			<div class="afteri">Заголовок h1:</div>
			<input id="elmetah1" name="elmetah1" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием элемента</div>
			<div class="hem10"></div>
			<div class="afteri">Мета-описание элемента:</div>
			<textarea id="elmetacontent" name="elmetacontent" placeholder="Введите текст в данное поле"  /></textarea>
			<div class="form_hint">Мета-описания не должны быть короткими, в несколько слов.<br>Должны описывать конкретную страницу сайта, а не сайт в целом.<br><br>Мета-описания должны быть емкими и при этом содержательными. Старайтесь выразить основную суть страницы в нескольких предложениях.</div>
			
			<div class="hem10"></div>
			<div class="afteri">Изображение элемента:</div>
			<div class="iload">
				<input type="file" id="metaloader" onchange="fileSelectHandler(this,<?
				echo $CONFIG['max_upload_images_width'].",".$CONFIG['max_upload_images_height'];
				?>,<?=$CONFIG['max_upload_images_size']?>,<?=$CONFIG['meta_images_width']?>,<?=$CONFIG['meta_images_height']?>,<?=$CONFIG['resize_images_big']?>,'listmeta','oldpageimg')">
				<div class="img-info"></div>
				<input type="hidden" class="iloadval" name="metaimages">
			</div>
			<div id="oldpageimg">
			<div class="hem10"></div>
			<div class="afteri">Текущее изображение:</div>
			<div class="hem10"></div>
			<div class="oldimg"></div>
			<div class="imgdel f08 orange pointer">Удалить</div>
			<input type="hidden" class="imagsold" name="metaimagesold">
			</div>
		<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block5" class="pages-block none">
		<div class="hem10"></div>
		<p><b>Доступные модули данного элемента:</b></p>
			<div class="hem10"></div>
			<div id="modules">
			</div>
			<div class="hem20"></div>
		</div>
		</form>
</div>
<div id="options" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Настройки ленты</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="list-options">
			<input type="hidden" name="listidopt" id="listidopt">
			<div class="hem10"></div>
			<div class="afteri">Состояние ленты:</div>
			<select name="listpower" id="listpower"><option value="0">Включена</option><option value="1">Выключена</option></select>
			<?
			if ($record['showpage']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">На какой странице разместить ленту:</div>
			<select name="listpage" id="listpage"></select>
			</div>
			<? if ($record['showopt']==0) echo '<div>'; else echo '<div class="none">'; ?>
			<div class="hem10"></div>
			<div class="afteri">Заголовок над лентой</div>
			<input id="listname" type="text" name="listname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться над формой, оставьте пустым если он не требуется</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст над лентой</div>
			<div id="ckeform1"></div>
			</div>
			<div class="hem20"></div>
			<button class="submit" type="button" id="opt-submit">Применить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление элемента</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить элемент: <b><span id="delname"></span></b> ?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="page-submit-del" del="">Удалить элемент</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-add" class="bigEntrance">
		<div class="fl"><h3 class="m0">Добавление элемента</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-page-add">
			<input type="hidden" id="ellistid" name="ellistid" value="<?=$id?>">
			<div class="hem10"></div>
			<div class="afteri">Заголовок элемента:</div>
			<input id="elname" name="elname" type="text" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<?
			if ($record['showurl']==0) echo '<div>'; else echo '<div class="none">';
			?>
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="elurl" name="elurl" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="elurl2" name="elurl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
			</div>
			<div class="hem30"></div>
			<button class="submit" type="button" id="page-submit-add">Создать элемент</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
<?if ($record['undel']!=1) { ?>
<div id="dellist" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление ленты</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить ленту?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<a href="index.php?page=parts&dellist=<?=$id?>"><button class="submit" type="button" id="dellistbut" del="">Удалить ленту</button></a>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
<? } ?>
</div>
<div class="clear"></div>
