<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	$sql=mysql_query("SELECT undel FROM catalog WHERE id='$delid'");
	$record=mysql_fetch_array($sql);
	if ($record['undel']!=1)
	{
	    mysql_query("DELETE FROM catalog WHERE id='$delid'");
		mysql_query("DELETE FROM polez WHERE cat='$delid'");
		mysql_query("DELETE FROM catalog_data WHERE pageid='$delid'");
	}
?>