<?
	include('../cfg.php');
	include('access.php');
	$arr = array();
	$key=0;
	function tray($parent,$level)
	{
		global $arr, $key;
		$sql=mysql_query("SELECT id, name, parent FROM pages WHERE parent='$parent' ORDER BY ID");
		while ($record=mysql_fetch_array($sql))
		{
			$arr[$key]['id']=$record['id'];
			$arr[$key]['parent']=$record['parent'];
			$arr[$key]['name']=$record['name'];
			$arr[$key]['level']=$level;
			$sql2=mysql_query("SELECT COUNT(*) FROM pages WHERE parent='".$record['id']."' ORDER BY ID");
			$record2=mysql_fetch_row($sql2);
			if ($record2[0])
			{
			$key++;
			tray($record['id'],$level+1);
			
			}
			else $key++;
		}
	}
	tray(0,0);
	
	
	header('Content-Type: application/json');
	echo json_encode($arr);
?>