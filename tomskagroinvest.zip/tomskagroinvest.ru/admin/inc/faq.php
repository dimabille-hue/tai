<script type="text/javascript" src="inc/faq.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">ВОПРОС-ОТВЕТ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=faq">Вопрос-ответ</a></div>
<div class="hem10"></div>
<div class="pages-left">
<div class="hem10"></div>
<button class="submit" type="button" id="but-opt" style="margin-right: 1em;">Настройки модуля</button> <button class="submit" type="button" id="but-add">Добавить вопрос</button>
<div class="clear"></div>
<div class="hem10"></div>
<h3>Текущие вопросы</h3>
<div id="blockfaq">
<div class="f08">Страница: <select class="pager" id="pager1"></select></div>
<div class="hem10"></div>
<div id="showfaq"></div>
<div class="hem10"></div>
<div class="f08">Страница: <select class="pager" id="pager2"></select></div>
</div>
</div>
<div class="pages-right">
<div id="pages-info" class="bigEntrance"></div>
<div id="options" class="options bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Настройки модуля</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-options">
			<div class="hem10"></div>
			<div class="afteri">Состояние модуля:</div>
			<select name="faqpower" id="faqpower"><option value="0">Включен</option><option value="1">Выключен</option></select>
			
			<div class="hem10"></div>
			<div class="afteri">На какой странице разместить модуль:</div>
			<select name="faqpage" id="faqpage"></select>
	
			<div class="hem10"></div>
			<div class="afteri">Добавление вопросов пользователями:</div>
			<select name="faqallowadd" id="faqallowadd"><option value="0">Разрешить</option><option value="1">Запретить</option></select>
				
			<div class="hem10"></div>
			<div class="afteri">Когда публиковать вопросы на сайте?</div>
			<select name="faqafteranswer" id="faqafteranswer"><option value="0">Сразу</option><option value="1">После проверки администратором</option></select>	
			
			<div class="hem10"></div>
			<div class="afteri">Уведомлять вас по почте о добавлении вопроса?</div>
			<select name="faqnotice" id="faqnotice"><option value="0">Да</option><option value="1">Нет</option></select>	
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit">Применить</button>
			<div class="wait2 none" id="waitopt">
				<div class="mball"></div>
			</div>
		</form>
</div>
<div id="pages-add" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Добавление вопроса</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-add">
			<div class="hem10"></div>
			<div class="afteri">Имя отправителя:</div>
			<input id="faqaddname" type="text" name="faqaddname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Введите имя человека, который задаёт вопрос</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст вопроса:</div>
			<textarea id="faqaddcontent" name="faqaddcontent" placeholder="Введите текст в данное поле" required></textarea>
			
			<div class="hem10"></div>
			<div class="afteri">Выберите дату и время отправки вопроса:</div>
			<input id="faqaddtimestamp" type="text" name="faqaddtimestamp">
			
			<div class="hem10"></div>
			<div class="afteri">Ответ администратора</div>
			<div id="ckeblock"></div>
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit-add">Добавить</button>
			<div class="wait2 none" id="waitadd">
				<div class="mball"></div>
			</div>
		</form>
</div>

<div id="pages-edit" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Редактирование вопроса</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-edit">
	<input type=hidden name="faqid" id="faqid">
			<div class="hem10"></div>
			<div class="afteri">Имя отправителя:</div>
			<input id="faqeditname" type="text" name="faqeditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Введите имя человека, который задаёт вопрос</div>
			
			<div class="hem10"></div>
			<div class="afteri">Текст вопроса:</div>
			<textarea id="faqeditcontent" name="faqeditcontent" placeholder="Введите текст в данное поле" required></textarea>
			
			<div class="hem10"></div>
			<div class="afteri">Выберите дату и время отправки вопроса:</div>
			<input id="faqedittimestamp" type="text" name="faqedittimestamp">
			
			<div class="hem10"></div>
			<div class="afteri">Ответ администратора</div>
			<div id="ckeblockedit"></div>
			
			<div class="hem10"></div>
			<div class="afteri">E-mail отправителя:</div>
			<input id="faqeditemail" type="text" name="faqeditemail" disabled />
			
			<div class="hem10"></div>
			<div class="afteri">Статус вопроса:</div>
			<select name="faqedithide" id="faqedithide"><option value="0">Показывать на сайте</option><option value="1">Не показывать на сайте</option></select>
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit-edit">Сохранить</button>
			<div class="wait2 none" id="waitedit">
				<div class="mball"></div>
			</div>
		</form>
</div>

<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление вопроса</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить вопрос пользователя: <b><span id="delname"></span></b> ?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="page-submit-del" del="">Удалить вопрос</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>

</div>
<div class="clear"></div>