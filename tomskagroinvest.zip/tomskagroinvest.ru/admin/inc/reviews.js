$("document").ready(function () {
	var sto;
	var pagelist=1;
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	var showhide=0;
	
	function Showreviews()
	{
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/reviews-options.php',
		  cache: false,
		  success: function(jsondata){
				showhide=jsondata[0]['afteranswer'];
			}
		  });
	
		$("#blockreviews").html("");
		$.ajax({
				  url: 'inc/reviews-col.php',
				  cache: false,
				  success: function(data){
					var pagecol=Math.ceil(data/20);
					if (pagecol>0)
					{
						if (pagelist>pagecol) { pagelist=pagecol; }
						if (pagelist<=0) { pagelist=1; }
						$("#pager1").html("");
						$("#pager2").html("");
						$("#blockreviews").html('<div class="f08">Страница: <select class="pager" id="pager1"></select></div><div class="hem10"></div><div id="showreviews"><div id="wait"><div class="hem30"></div><div class="ball"></div><div class="ball1"></div></div></div><div class="hem10"></div><div class="f08">Страница: <select class="pager" id="pager2"></select></div>')
						for (var i=1;i<=pagecol;i++)
						{
							var inj1="";
							if (i==pagelist) { inj1="selected"; }
							$("#pager1").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
							$("#pager2").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
						}
							
							$.ajax({
							  dataType: 'json',
							  url: 'inc/reviews-load.php',
							  type: 'POST',
							  data : 'pagelist='+pagelist,
							  cache: false,
							  success: function(jsondata){
							  
								$("#showreviews").html("");
								$.each(jsondata,function(indx, element){
									if (showhide==0)
									{
										var inj4='<div class="line-show" title="Отзыв виден на сайте"></div>';
									}
									else
									{
										if (element.hide==0)
										{
											var inj4='<div class="line-show" title="Отзыв виден на сайте"></div>';
										}
										else
										{
											var inj4='';
										}
									}
									$("#showreviews").append('<div class="line" reviewsid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot"></div><div class="line-name2"><div class="line-name-text">' + element.name + ' <span class="f07 gray">' + element.timestamp+ '</span></div></div><div class="line-del" title="Удалить отзыв"></div><div class="line-edit" title="Редактировать отзыв"></div>'+inj4+'</div></div>');
				
									
								});
							  }});
							
						
					}
					else
					{
						$("#blockreviews").html('<div class="f08">Не нашлось ни одного отзыва</div>');
					}
				 }
				});
		
	}
	
	$(".pages-left").on("change","#pager1",function(){
		  pagelist=$(this).val();
		Showreviews();
	});
	
	$(".pages-left").on("change","#pager2",function(){
		  pagelist=$(this).val();
		Showreviews();
	});
	
	Showreviews();
	
	$("#page-submit").click(
		function ()
		{
			$(this).hide(0);
			$("#waitopt").show(0);
			
				var data = $('#form-options').serialize();
				$.ajax({
				url: 'inc/reviews-options-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$("#waitopt").hide(0);
					PagesInfo(data);
					$("#options").hide(0);
					Showreviews();
				
				}
				});
			
		});
		
	$("#page-submit-add").click(
		function ()
		{
			$(this).hide(0);
			$("#waitadd").show(0);
			
		
				var data = $('#form-add').serialize();
				$.ajax({
				url: 'inc/reviews-add-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$("#waitadd").hide(0);
					PagesInfo(data);
					$("#pages-add").hide(0);
					Showreviews();

				}
				});
			
		});
		
	function PartAdd()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-add").show(0);
		$("#waitadd").hide(0);
		
		$("#reviewsaddname").val("");
		$("#reviewsaddcontent").val("");
		$("#reviewsaddtimestamp").val("");
		$("#reviewsaddtimestamp").datetimepicker( $.datepicker.regional[ "ru" ] );
		
		$("#pages-add").show(0);
	}
	
	$("#page-submit-edit").click(function(){
		$("#page-submit-edit").hide(0);
		$(".wait2").show(0);
		
		var data = $('#form-edit').serialize();
		$.ajax({
				url: 'inc/reviews-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".wait2").hide(0);
					Showreviews();
					PagesInfo(data);
					$("#pages-edit").hide(0);	
				}
				});
	});
	
	function PartEdit(reviewsid)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-edit").show(0);
		$("#waitedit").hide(0);
		
		$("#reviewseditname").val("");
		$("#reviewseditcontent").val("");
		$("#reviewsedittimestamp").val("");
		$("#reviewseditemail").val("");
		$("#reviewsid").val(reviewsid);
		$("#reviewsedithide").val(0);
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/reviews-edit.php',
		  data: 'reviewsid='+reviewsid,
		  cache: false,
		  success: function(jsondata){
		  
				$("#reviewseditname").val(jsondata[0].name);
				$("#reviewseditcontent").val(jsondata[0].content);
				$("#reviewsedittimestamp").val(jsondata[0].timestamp);
				$("#reviewsedittimestamp").datetimepicker( $.datepicker.regional[ "ru" ] );
				$("#reviewseditemail").val(jsondata[0].email);
				$("#reviewsedithide").val(jsondata[0].hide);
				$("#pages-edit").show(0);
		  }
		  });
		
	}
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/reviews-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				Showreviews();
				PagesInfo("Отзыв успешо удалён");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function PartDel(reviewsid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-del").show(0);
		$("#waitdel").hide(0);
		
		$.ajax({
				type: 'POST',
				url: 'inc/reviews-del-name.php',
				data: 'delid='+reviewsid,
				dataType: 'json',
				success: function(data){
						$("#pages-del").show(0);
						$("#page-submit-del").attr("del",reviewsid);
						$("#delname").html(data.name);
					
				}
				});
				
	}
	
	function PageOptions(pageid)
	{
		$(".wait2").hide(0);
		$("#reviewspage").html('<option value="0">Выберите страницу</option>');
	$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option-free.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#reviewspage").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	function PartOpt()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit").show(0);
		$("#waitopt").hide(0);
		
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/reviews-options.php',
		  cache: false,
		  success: function(jsondata){
				$("#reviewspower").val(jsondata[0]['power']);
				PageOptions(jsondata[0]['page']);
				$("#reviewsallowadd").val(jsondata[0]['allowadd']);
				$("#reviewsafteranswer").val(jsondata[0]['afteranswer']);
				$("#reviewsnotice").val(jsondata[0]['notice']);
				$("#options").show(0);
			}
		  });
		
	}
	
	$("#but-opt").click(function(){
		PartOpt();
	});
	
	$("#but-add").click(function(){
		PartAdd();
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PartEdit($(this).parent().parent().attr('reviewsid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('reviewsid'));
	});
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
});