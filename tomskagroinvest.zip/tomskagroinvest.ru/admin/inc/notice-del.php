<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	
	     mysql_query("DELETE FROM notice WHERE id='$delid'");
	
?>