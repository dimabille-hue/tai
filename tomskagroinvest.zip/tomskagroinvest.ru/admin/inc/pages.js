$("document").ready(function () {
	var popen=new Array();
	var sto;
	$("#page-name").change(function(){
		$("#page-url").val(Name2Url($("#page-name").val()));
	});
	
	$("#page-edit-name").change(function(){
		$("#page-edit-url").val(Name2Url($("#page-edit-name").val()));
	});
	
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	function PagesUp(elemid)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/pages-up.php',
				data: 'elemid='+elemid,
				success: function(data){
					PagesPrint();
				}
				});
	}
	function PagesDown(elemid)
	{
		$.ajax({
				type: 'POST',
				url: 'inc/pages-down.php',
				data: 'elemid='+elemid,
				success: function(data){
					PagesPrint();
				}
				});
	}
	function PagesAdd(parent)
	{
		$(".wait2").hide(0);
		$("#page-submit").show(0);
		$("#pages-add").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-del").hide(0);
		$("#pages-add").show(300);
		$("#page-url").val("");
		$("#page-url2").val("");
		$("#page-name").val("");
		$("body").scrollTop(0);
		$("#page-parent").html('<option value="0">Страница верхнего уровня</option>');
		$.ajax({
		  dataType: 'json',
		  url: 'inc/pages-option.php',
		  cache: false,
		  success: function(jsondata){
			$.each(jsondata,function(indx, element){
			var inj1="", inj2="";
			if (parent==element.id) { inj2=" selected ";} 
			if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
			if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
			if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
				 $("#page-parent").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
			});
		 }
		});
	}
	
	$("#page-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			var pagename, pageurl, pageparent;
			pagename=$("#page-name").val();
			pageurl=$("#page-url").val();
			$("#page-url2").val($("#page-url").val());
			if ((pagename!="") && (pageurl!=""))
			{
				var data = $('#form-page-add').serialize();
				$.ajax({
				url: 'inc/pages-add.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$("#page-submit").show(0);
				PagesInfo("Страница с таким url уже существует");
				}
				else
				{
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Страница успешно добавлена");
				$("#pages-add").hide(0);
				}
				}
				});
			}
			else
			{
				PagesInfo("Страница не добавлена, возможно вы заполнили не все поля");
				$("#pages-add").hide(0);
				$(".wait2").hide(0);
			}
		});
		
	
	$(".page-save").click(function(){
		
		$(".page-save").hide(0);
		$(".wait2").show(0);
		var pagename, pagecontent, pageurl, pagenewurl, pagesrt, pagehide, pageparent;
		//for ( instance in CKEDITOR.instances )
		CKEDITOR.instances['pages-edit-content'].updateElement();
		pagecontent = CKEDITOR.instances['pages-edit-content'].getData();
		$("#pages-edit-content").html(pagecontent);
		pagename=$("#page-edit-name").val();
		pageurl=$("#page-edit-url").val();
		$("#page-edit-url2").val($("#page-edit-url").val());
		
		$("[need]").map(function(indx, element){
			
			var iname = $(this).attr('need');
			CKEDITOR.instances[iname].updateElement();
			var j = CKEDITOR.instances[iname].getData();
			$("#"+iname).html(j);
		});
		
		var data = $('#form-page-edit').serialize();
		if (pagename!="")
		{
				
			$.ajax({
				url: 'inc/pages-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
				if (data=="nameexist")
				{
				$(".wait2").hide(0);
				$(".page-save").show(0);
				PagesInfo("Страница с таким url уже существует");
				}
				else
				{
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Страница успешно обновлена");
				$("#pages-edit").hide(0);
				}
				}
				});
		}
		else
		{
				PagesInfo("Страница не сохранена, возможно вы удалили «Заголовок страницы»");
				$("#pages-edit").hide(0);
				$(".wait2").hide(0);
		}
		
	});
		
	$("#pagedel-submit").click(
		function ()
		{
			$("#pagedel-submit").hide(0);
			$(".wait2").show(0);
			var delid=$("#pagedel-submit").attr("del");
			popen[delid]=0;
			$("#pagedel-submit").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/pages-del.php',
				data: 'delid='+delid,
				success: function(data){
				
				$(".wait2").hide(0);
				PagesPrint();
				PagesInfo("Страница успешно удалена");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function printopt(pageid,elid)
	{
		$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.id!=elid) {
						 $("#page-edit-parent").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>'); }
					});
				 }
				});
	}
	
	function PagesEdit(parent)
	{
		
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$(".submit2").removeClass("op1");
		$("#oldpageimg").hide(0);
		$(".submit2[bid=1]").addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block1").show(300);
		
		
		$(".page-save").show(0);
		$(".wait2").hide(0);
				$("#page-edit-url").val("");
				$("#page-edit-name").val("");
				$("#pages-edit-content").val("");
				$("#pages-edit-srt").val("0");
				$("#metacontent").val("");
				$("#metaname").val("");
				$("#metah1").val("");
				$("#ckeblock").html("");
				$("#page-edit-hide").prop("checked", false);
				$("#page-edit-newurl").prop("checked", false);
				$("#page-edit-id").val(parent);
				
					$("#metaloader").parent().find(".img-info").html("Добавьте изображение");
					$("#metaloader").prop('value', null);
					$("#metaloader").parent().find(".iloadval").val("");
		$("body").scrollTop(0);		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/pages-edit.php',
		  data: 'pageid='+parent,
		  cache: false,
		  success: function(jsondata){
			$.each(jsondata,function(indx, element){
				$("#page-edit-name").val(element.name);
				$("#page-edit-url").val(element.url);
				$("#pages-edit-srt").val(element.srt);
				$("#metacontent").val(element.metacontent);
				$("#metaname").val(element.metaname);
				$("#metah1").val(element.metah);
				if (element.hide=="1") { $("#page-edit-hide").prop("checked", true); }
				$("#page-edit-parent").html('<option value="0">Страница верхнего уровня</option>');
				printopt(element.parent,element.id);
				if (!element.content) { $("#ckeblock").html('<textarea name="pageseditcontent" id="pages-edit-content" rows="10" cols="80"></textarea>'); } else
				{ $("#ckeblock").html('<textarea name="pageseditcontent" id="pages-edit-content" rows="10" cols="80">' + element.content + '</textarea>'); }
				
				var editor;
				editor = CKEDITOR.replace('pages-edit-content',{
					removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
				});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				if (element.metaimg)
				{
					$("#oldpageimg").find(".imagsold").val(element.metaimg);
					$("#oldpageimg").find(".oldimg").css({'background':'url(../img/upload/th/'+element.metaimg+') center center no-repeat', 'background-size':'cover'});
					$("#oldpageimg").show(0);
				}
				
				$.ajax({
						  dataType: 'json',
						  type: 'POST',
						  url: 'inc/pages-dop.php',
						  data: 'pageid='+parent,
						  cache: false,
						  success: function(injsondata){
							$.each(injsondata,function(indx, inelement){
								if (inelement.type==1 || inelement.type==2)
								{
									$("#dop-"+inelement.ident).val(inelement.content);
								}
								if (inelement.type==3)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==4)
								{
									$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var dopeditor;
									dopeditor = CKEDITOR.replace('dop-edit-'+inelement.ident,{
										removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
									});
									CKFinder.setupCKEditor(dopeditor, "ckfinder/");
								}
								if (inelement.type==5)
								{
									$("#dop-"+inelement.ident).html("");
									//$("#dop-"+inelement.ident).html('<textarea name="dop-'+inelement.ident+'" id="dop-edit-'+inelement.ident+'" rows="10" cols="80">' + inelement.content + '</textarea>');
									var ar = inelement.val.split(":");
									$.each(ar,function(indx, option){
										if (option==inelement.content)
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'" selected>'+option+'</option>');
										}
										else
										{
										$("#dop-"+inelement.ident).append('<option value="'+option+'">'+option+'</option>');
										}
									});
								}
								if (inelement.type==6)
								{
									if (inelement.content)
									{
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
										$("#oldimg-"+inelement.ident).find(".imagsold").val(inelement.content);
										$("#oldimg-"+inelement.ident).find(".oldimg").css({'background':'url(../img/upload/th/'+inelement.content+') center center no-repeat', 'background-size':'cover'});
										$("#oldimg-"+inelement.ident).show(0);
									}
									else
									{
										$("#oldimg-"+inelement.ident).hide(0);
										$("#dop-"+inelement.ident).parent().find(".img-info").html("Добавьте изображение");
										$("#dop-"+inelement.ident).prop('value', null);
										$("#dop-"+inelement.ident).parent().find(".iloadval").val("");
									}
								}
							});
						  }
				});
				
				$("#modules").html("");
				$.ajax({
				  dataType: 'json',
				  type: 'POST',
				  url: 'inc/pages-modules.php',
				  data: 'pageid='+parent,
				  cache: false,
				  success: function(jsondatad){
					var cl=0;
					$.each(jsondatad,function(indx, elementd){
						$("#modules").append('<a href="'+elementd.href+'"><div class="modulemin">'+elementd.name+'</div></a>');
						cl++;
					});
					$("#modules").append("<div class=clear></div>");
					if (cl==0)
					{
					$("#modules").html('<div class="f08">У данной страницы нет прикреплённых модулей</div>');
					}
					else
					{
					$("#modules").append('<div class="hem10"></div><div class="f08 orange"><b>Внимание! Прежде чем переходить в модуль не забудьте сохранить страницу</b></div>');
			
					}
				  }});
				
				$("#page-submit").show(0);
				$("#pages-add").hide(0);
				$("#pages-info").hide(0);
				$("#pages-del").hide(0);
				$("#pages-edit").show(300);
				
			});
		 }
		});
	}
	
	function PagesDel(parent)
	{
		$("#pagedel-submit").show(0);
		$(".wait2").hide(0);
		$("#delinf").html("");
		$("#pagedel-submit").attr("del","");
		$("#pages-add").hide(0);
		$("#pages-info").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-del").hide(0);
		$("body").scrollTop(0);
		$.ajax({
				type: 'POST',
				url: 'inc/pages-del-name.php',
				data: 'parent='+parent,
				dataType: 'json',
				success: function(data){
					if (data.undel==1)
					{
						$("#pages-del").show(0);
						$("#pagedel-submit").hide(0);
						$("#delname").html(data.name);
						$("#delinf").html("Данная страница защищена от удаления.");
					}
					else
					{
						$("#pages-del").show(0);
						$("#pagedel-submit").attr("del",parent);
						$("#delname").html(data.name);
					}
				}
				});
	}

	function PagesPrint()
	{
		$("#pages-tree").html('<div class="hem30"></div><div class="ball"></div><div class="ball1"></div>');
		$.ajax({
		  dataType: 'json',
		  url: 'inc/pages-tree.php',
		  cache: false,
		  success: function(jsondata){
			$("#pages-tree").html('');
			$.each(jsondata,function(indx, element){
				 var inj1="", inj2="", inj3="", inj4="";
				 if (element.hide=="1") { inj1=" line-name-hide"; } else { inj1=""; }
				 if (popen[parseInt(element.id)]==1)
				 {
					 if (element.have=="plus")
					 {
					 element.have="minus";
					 inj2="";
					 }
				 }
				 else
				 {
				 if (element.level!="0") { inj2=" none"; } else { inj2=""; }
				 }
				 
				 if (element.parent!=0)
				 {
					if (popen[parseInt(element.parent)]==1)
					{
					inj2="";
					}
				 }
				 if (element.level<3)
				 {	
					inj4='<div class="line-add" title="Добавить подстраницу"></div>';
				 }
				 inj3='<div class="line-del" title="Удалить страницу"></div>';
				 if (element.level==3)
				 {
				 element.have='dot';
				 }
				 if (element.level<4)
				 {
				 $("#pages-tree").append('<div class="line' + inj2 + '" pageid="' + element.id + '" parent="' + element.parent + '"><div class="line-inside line-level' + element.level + '"><div class="line-open line-' + element.have + '"></div><div class="line-name"><div class="line-name-text' + inj1 + ' ">' + element.name + '</div></div>' + inj3 + '<div class="line-edit" title="Редактировать страницу"></div><div class="line-down" title="Опустить вниз"></div><div class="line-up" title="Поднять вверх"></div>' + inj4 + '<a href="../' + element.url + '" target="_blank"><div class="line-show" title="Открыть страницу на сайте"></div></a></div></div>');
				 }
			});
			$("#pages-tree").append('<div class="hem10"></div><button class="submit newpage" type="button">Новая страница</button>');
		 }
		});
			
	}
	
	PagesPrint();
	
	$("#pages-tree").on("click",".line-plus",function(){
		  $(this).removeClass("line-plus");
		  $(this).addClass("line-minus");
		  $(".line[parent = " + $(this).parent().parent().attr('pageid') + "]").fadeIn(300);
		  var po=parseInt($(this).parent().parent().attr('pageid'));
		  popen[po]=1;
	});
	
	function pgminus(id)
	{
		popen[id]=0;
		$(".line[pageid="+id+"]").find(".line-open").removeClass("line-minus");
		$(".line[pageid="+id+"]").find(".line-open").addClass("line-plus");
		$(".line[parent="+id+"]").each(function(indx){
		    pgminus($(this).attr("pageid"));
		});
		$(".line[parent="+id+"]").fadeOut(0);
	}
	
	$(".imgdel").click(function(){
		$(this).parent().hide(0);
		$(this).parent().find(".imagsold").val("");
	});
	
	$("#pages-tree").on("click",".line-minus",function(){
		  var po=parseInt($(this).parent().parent().attr('pageid'));
		  pgminus(po);
	});
	
	$("#pages-tree").on("click",".line-add",function(){
		  PagesAdd($(this).parent().parent().attr('pageid'));
	});
	
	$("#pages-tree").on("click",".newpage",function(){
		  PagesAdd(0);
	});
	
	$("#pages-tree").on("click",".line-edit",function(){
		  PagesEdit($(this).parent().parent().attr('pageid'));
	});
	
	$("#pages-tree").on("click",".line-del",function(){
		  PagesDel($(this).parent().parent().attr('pageid'));
	});
	
	$("#pages-tree").on("click",".line-up",function(){
		  PagesUp($(this).parent().parent().attr('pageid'));
	});
	$("#pages-tree").on("click",".line-down",function(){
		  PagesDown($(this).parent().parent().attr('pageid'));
	});
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
	
	$(".submit2").click(function(){
		$(".submit2").removeClass("op1");
		$(this).addClass("op1");
		$(".pages-block").hide(0);
		$("#pages-block"+($(this).attr("bid"))).show(300);
	});
	
});