<script type="text/javascript" src="inc/social.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">СОЦИАЛЬНЫЙ КНОПКИ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=social">Соц. кнопки</a></div>
<div class="hem10"></div>
<div class="pages-left">
<? 
$sql=mysql_query("SELECT * FROM parts_social WHERE ident='pages'");
$record=mysql_fetch_array($sql);
$sql=mysql_query("SELECT * FROM parts_social WHERE ident='list'");
$record2=mysql_fetch_array($sql);
?>
<form class="object_form" name="object_form1" id="form-part">
	<h3>Настройки модуля</h3>
	<p class="f08">Данный модуль может влиять на скороть загрузки страниц сайта, если вы хотите ускорить загрузку - советуем его отключить.</p>
	<div class="hem10"></div>
	<div class="afteri">Размещение на общих страницах:</div>
	<select name="partval"><option value="0">Включен</option><option value="1" <? if ($record['content']==1) echo 'selected '; ?>>Выключен</option></select>
	<div class="hem10"></div>
	<div class="afteri">Размещение в лентах:</div>
	<select name="partval2"><option value="0">Включен</option><option value="1" <? if ($record2['content']==1) echo 'selected '; ?>>Выключен</option></select>
	<div class="hem20"></div>
	<button class="submit" type="button">Сохранить</button>
	<div class="wait2 none" id="wait">
		<div class="mball"></div>
	</div>
</form>
<div id="info" class="options bigEntrance">
</div>
</div>
<div class="pages-right">
<h3>Как выглядит модуль соц. кнопок?</h3>
<div class="hem10"></div>
<? 
$sql=mysql_query("SELECT * FROM parts_social WHERE ident='code'");
$record=mysql_fetch_array($sql);
echo $record['content'];
?>
</div>
<div class="clear"></div>