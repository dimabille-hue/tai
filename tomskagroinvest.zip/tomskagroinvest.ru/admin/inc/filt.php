<script type="text/javascript" src="inc/filt.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">Фильтр</h1>
<div class="hem10"></div>
<?
			$ctid=(int)$_GET['catid'];
			$sqlc=mysql_query("SELECT * FROM catalog WHERE id='$ctid'");
			$recordc=mysql_fetch_array($sqlc);
	if ($_SERVER['REQUEST_METHOD']=="POST" && ((int)$_POST['colrow'])>=1 && $_POST['save-btn'])
	{
		$filt1=array();
		$filt2=array();
		$colrows=(int)$_POST['colrow'];

		$k2=0;
		for ($i=1; $i<=$colrows; $i++)
		{
			if ($_POST['filt1-'.$i]!="" && $_POST['filt1-'.$i])
			{
				$filt1[]=filt($_POST['filt1-'.$i]);
				$filt2=array();
					for($j=1; $j<=50; $j++)
						{
							if($_POST['filt2-'.$i.'-'.$j]!="" && $_POST['filt2-'.$i.'-'.$j])
								{
									$filt2[]=filt($_POST['filt2-'.$i.'-'.$j]);
								}
						}
						if($filt2)
						{
					$filt2ss[$i]=implode('~~~',$filt2);
						}
			}
		}
		
		$filt2s=implode('###',$filt2ss);
		
		$filt1s=implode('~~~',$filt1);
	
		//if($filt1s && $filt1s!="")
			//{
				mysql_query("UPDATE catalog SET filt1='$filt1s' WHERE id='$ctid'");
			//}
		//if($filt2s && $filt2s!="")
			//{
				mysql_query("UPDATE catalog SET filt2='$filt2s' WHERE id='$ctid'");
			//}
	}
	
?>
	<h3>Параметр фильтра категории «<?=$recordc['name']?>»</h3><div class="hem10"></div>
	<form class="object_form" action="" method="POST">
		<? 	$k=0;
			$sql=mysql_query("SELECT * FROM catalog WHERE id='$ctid'");
			$record=mysql_fetch_array($sql);

			$mydop=$record['filt1'];
			$mydoparr=explode('~~~',$mydop);
			$mydop2=$record['filt2'];
			$mydoparr2=explode('###',$mydop2);
			$colut=count($mydoparr);
			if (!$colut) $colut=1;
			$heit='25px';


		?>
	<input type="hidden" id="colrows" value="<?=$colut?>" name="colrow">
	<div id="colit">

	<?
		if ($colut && count($mydoparr)>0)
		{
			foreach ($mydoparr as $key => $md)
			{
				echo '
				<div><div style="float: left;">Название поля: </div><input name="filt1-'.($key+1).'" col="'.($key+1).'" type="text" value="'.$md.'" style="float: left; margin-left: 20px; width: 240px; margin-top: -5px;"><div  style="float: left; margin-left: 40px;">Значения поля: </div>';


				echo'<div id="colit'.($key+1).'" style= "float: left; margin-left:20px;">';
				$mydoparr3=explode('~~~',$mydoparr2[$key]);
				$k=1;
				foreach ($mydoparr3 as $key2 => $md2) 
				{	
					echo'<input name="filt2-'.($key+1).'-'.($key2+1).'" type="text" value="'.$md2.'" style="float: left; margin-left: 20px;  margin-bottom: 10px; width: 240px;"><div class="clear"></div>';
					$k++;
				}
				echo '</div>';
				echo '<div class="line-add" title="Добавить значение"  col="'.($key+1).'" style="float: left; margin-left: 20px;" data-summ="'.$k.'"></div><div class="clear"></div></div><div class="hem20"></div><input type="hidden" id="colrows-'.($key+1).'" value="'.$k.'" name="colrow-'.($key+1).'">';
			}
		}
		else
		{
			?>
			<div><div style="float: left;">Название поля: </div><input name="filt1-1" col="1" type="text"  style="float: left; margin-left: 20px; width: 240px; margin-top: -5px;"><div  style="float: left; margin-left: 40px;">Значения поля: </div><input name="filt2-1-1"  type="text"  style="float: left; margin-left: 20px;  margin-top: -5px; width: 240px;" ><div class="line-add" title="Добавить значение"  data-summ="1"  style="float: left; margin-left: 20px;"></div><div class="clear"></div></div>
	<div class="hem20"></div>
			<?
		}
	?>
	

	</div>
	
	<button class="submit" type="button" id="add-btn" style="margin-right: 1em;">Добавить параметр</button>
	<input class="submit2" type="submit" name="save-btn" value="Сохранить" style="margin-right: 1em;">

	</form>
	

	
	<div class="clear"></div>
	<div class="hem20"></div>
	

</div>
<div class="clear"></div>
