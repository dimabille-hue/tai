$("document").ready(function () {

var sto, formid=$("#formid").val();

function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	function ShowRows()
	{
		$("#rows").html('<div id="wait"><div class="ball"></div><div class="ball1"></div></div><div class="hem20"></div>');
		$.ajax({
				  dataType: 'json',
				  url: 'inc/form-load.php',
				  type: 'POST',
				  data: 'formid='+formid,
				  cache: false,
				  success: function(jsondata){
					
									$("#rows").html("");
									if (jsondata!="")
									{
						$.each(jsondata,function(indx, element){
									$("#rows").append('<div class="line" rowid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot"></div><div class="line-name"><div class="line-name-text">' + element.name + ' <span class="f07 gray">' + element.type+ '</span></div></div><div class="line-del" title="Удалить поле"></div><div class="line-edit" title="Редактировать поле"></div></div></div>');

						}); } else
						{
							$("#rows").html('<div class="f08">В данной форме ещё нет полей</div>');
						}
				  }
				  });
	}
	
	ShowRows();
	
	function PageOptions(pageid)
	{
		$(".wait2").hide(0);
		$("#formpage").html('<option value="0">Выберите страницу</option>');
	$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option-free.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#formpage").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	$("#opt-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			
			var pagecontent;
			CKEDITOR.instances['formcontent'].updateElement();
			pagecontent = CKEDITOR.instances['formcontent'].getData();
			$("#formcontent").html(pagecontent);
			
			CKEDITOR.instances['formresult'].updateElement();
			pagecontent = CKEDITOR.instances['formresult'].getData();
			$("#formresult").html(pagecontent);
			
				var data = $('#form-options').serialize();
				$.ajax({
				url: 'inc/form-options-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$(".wait2").hide(0);
					PagesInfo(data);
					$("#options").hide(0);
				
				}
				});
			
		});
	
	function PartOpt()
	{

		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#delform").hide(0);
		$("#opt-submit").show(0);
		$("#ckeform1").html("");
		$("#ckeform2").html("");
				$("#options").show(0);
		$.ajax({
		  url: 'inc/form-options.php',
		  type: 'POST',
		  data: 'formid='+formid,
		  dataType: 'json',
		  cache: false,
		  success: function(jsondata){
				$("#formname").val(jsondata[0]['name']);
				$("#formidopt").val(formid);
				PageOptions(jsondata[0]['page']);
				$("#formbutton").val(jsondata[0]['button']);
				$("#formnotice").val(jsondata[0]['notice']);
				if (jsondata[0].content==null) { jsondata[0].content=''; }
				if (jsondata[0].result==null) { jsondata[0].result=''; }
				$("#ckeform1").html('<textarea name="formcontent" id="formcontent" rows="10" cols="80">'+jsondata[0].content+'</textarea>');
				var editor;
				editor = CKEDITOR.replace('formcontent',{
					removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
					
				});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				
				$("#ckeform2").html('<textarea name="formresult" id="formresult" rows="10" cols="80">'+jsondata[0].result+'</textarea>');
				var editor2;
				editor2 = CKEDITOR.replace('formresult',{
					removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
					
				});
				CKFinder.setupCKEditor(editor2, "ckfinder/");
			}
		  });
		
	}
	
	function PartDelform()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#delform").show(0);
		$("#delformbut").show(0);
	}
	
	$("#pages-add-submit").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
		
				var data = $('#form-add').serialize();
				$.ajax({
				url: 'inc/form-add-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$(".wait2").hide(0);
					PagesInfo(data);
					$("#pages-add").hide(0);
					ShowRows();
				}
				});
			
		});
	
	function PartAdd()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#delform").hide(0);
		$("#formidadd").val(formid);
		$("#pages-add-submit").show(0);
		$("#form-add-submit").show(0);
		$("#rowname").val("");
		$("#rowcontent").val("");
		$("#rowval").val("");
		$("#rowdop").hide(0);
		$("#rowtype").val("text");
		$("#pages-add").show(0);
	}
	
	$("#rowtype").change(function(){
		if ($(this).val()=='select')
		{
			$("#rowdop").show(0);
		}
		else
		{
			$("#rowdop").hide(0);
		}
	});
	
	$("#rowedittype").change(function(){
		if ($(this).val()=='select')
		{
			$("#roweditdop").show(0);
		}
		else
		{
			$("#roweditdop").hide(0);
		}
	});
	
	$("#page-submit-delrow").click(
		function ()
		{
			$("#page-submit-delrow").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-delrow").attr("del");
			$("#page-submit-delrow").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/form-row-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				ShowRows();
				PagesInfo("Поле успешно удалено");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
		
	function PartDel(rowid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#delform").hide(0);
		$("#options").hide(0);
		$("#delinf2").html("");
		$("#page-submit-delrow").show(0);
		
		$.ajax({
				type: 'POST',
				url: 'inc/form-del-name.php',
				data: 'delid='+rowid,
				dataType: 'json',
				success: function(data){
				if (data.undel==1)
					{
						$("#pages-del").show(0);
						$("#page-submit-delrow").hide(0);
						$("#delname").html(data.name);
						$("#delinf2").html("Данное поле защищено от удаления.");
					}
					else
					{
						$("#pages-del").show(0);
						$("#page-submit-delrow").attr("del",rowid);
						$("#delname").html(data.name);
					}
						
					
				}
				});
				
	}
	
	$("#pages-edit-submit").click(function(){
		$("#pages-edit-submit").hide(0);
		$(".wait2").show(0);
		
		var data = $('#form-edit').serialize();
		$.ajax({
				url: 'inc/form-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".wait2").hide(0);
					ShowRows();
					PagesInfo(data);
					$("#pages-edit").hide(0);	
				}
				});
	});
	
	function PartEdit(rowid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#delform").hide(0);
		$("#options").hide(0);
		$("#roweditid").val(rowid);
		$("#pages-edit-submit").show(0);
		
		$("#roweditname").val("");
		$("#roweditcontent").val("");
		$("#roweditval").val("");
		$("#roweditdop").hide(0);
		$("#rowedittype").val("text");
		$("#roweditsrt").val("0");
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/form-edit.php',
		  data: 'rowid='+rowid,
		  cache: false,
		  success: function(jsondata){
				$("#roweditname").val(jsondata[0].name);
				$("#roweditcontent").val(jsondata[0].content);
				$("#roweditsrt").val(jsondata[0].srt);
				
				$("#rowedittype").val(jsondata[0].type);
				if (jsondata[0].type=='select')
				{
				$("#roweditdop").show(0);
				}
				$("#roweditval").val(jsondata[0].val);
				$("#pages-edit").show(0);
		  }
		  });
				
	}
	
	$("#but-opt").click(function(){
		PartOpt();
	});
	
	$("#but-del").click(function(){
		PartDelform();
	});
	
	$("#but-addrow").click(function(){
		PartAdd();
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PartEdit($(this).parent().parent().attr('rowid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('rowid'));
	});
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});

});