$("document").ready(function () {
	
	$("#add-btn").click(function(){

		var col = parseInt($("#colrows").val())+1;
		$("#colit").append('<div id="colit"><div><div style="float: left;">Название поля: </div><input name="filt1-'+col+'" col="'+col+'" type="text"  style="float: left; margin-left: 20px; width: 240px; margin-top: -5px;"><div  style="float: left; margin-left: 40px;">Значения поля: </div><div id="colit'+col+'" style= "float: left; margin-left:20px;"><input name="filt2-'+col+'-1" type="text"  style="float: left; margin-left: 20px;  margin-bottom: 10px; width: 240px;" ></div><div class="line-add addd" title="Добавить значение" data-summ="2" col="'+col+'"  style="float: left; margin-left: 20px;"></div><div class="clear"></div></div><div class="hem20"></div></div>');
		$("#colrows").val(col);
	});

	$(".line-add").click(function(){
		var newsq=parseInt($(this).attr("data-summ"));
		$(this).attr("data-summ",(newsq+1));
		var coll= parseInt($(this).attr("col"));
		$("#colit"+coll).append('<div class="clear"></div><input name="filt2-'+coll+'-'+newsq+'" type="text"  style="float: left; margin-left: 20px;  margin-bottom: 10px; width: 240px;" >');
		//$("#colrows2").val(col2);
		$("#colrows-"+coll).val(newsq);
								
	});
	$("#colit").on("click",".addd" ,function(){
		var newsq=parseInt($(this).attr("data-summ"));
		$(this).attr("data-summ",(newsq+1));
		var coll= parseInt($(this).attr("col"));
		$("#colit"+coll).append('<div class="clear"></div><input name="filt2-'+coll+'-'+newsq+'" type="text" style="float: left; margin-left: 20px;  margin-bottom: 10px; width: 240px;" >');
		//$("#colrows2").val(col2);
		$("#colrows-"+coll).val(newsq);
	});
});
