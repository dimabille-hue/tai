$("document").ready(function () {
	var sto;	
	function PagesInfo(part,info)
	{
		clearTimeout(sto);
		$("#opt-info"+part).show(300);
		$("#opt-info"+part).html(info);
		sto=setTimeout(function(){
			$("#opt-info"+part).html("");
			$("#opt-info"+part).hide(0);
		}, 5000)
	}
	function optload(part)
	{
		$.ajax({
		  dataType: 'json',
		  url: 'inc/options-load.php',
		  cache: false,
		  success: function(jsondata){
			if (part==1)
			{
				$("#sitename").val(jsondata[1]);
				$("#sitedomains").val(jsondata[2]);
				$("#emailsend").val(jsondata[3]);
				$("#emailsend2").val(jsondata[4]);
				$("#admincontacts").val(jsondata[5]);
				$("#adminafter").val(jsondata[10]);
				$("#adminbefore").val(jsondata[11]);
			}
			if (part==2)
			{
				$("#metatitle").val(jsondata[6]);
				$("#metadescript").val(jsondata[7]);
				$("#siteblock").val(jsondata[8]);
			}
			if (part==3)
			{
				$("#adminold").val("");
				$("#adminpass").val("");
				$("#adminpass2").val("");
			}
		 }
		});
	}
	
	$(".submit").click(function(){
	var part=parseInt($(this).attr("part"));
	$(this).hide(0);
	$("#wait"+part).show(0);
	var data = $('#form-options'+part).serialize();
		$.ajax({
				url: 'inc/options-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".submit[part="+part+"]").show(0);
					$("#wait"+part).hide(0);
					PagesInfo(part,data);
					optload(part);
				}
				});
	});
	
	optload(1);
	optload(2);
	optload(3);
});