<?
	include('../cfg.php');
	include('access.php');
	$arr = array();
	
	$parent=(int)$_POST['delid'];
	$sql=mysql_query("SELECT * FROM notice WHERE id='$parent'");
	$record=mysql_fetch_array($sql);
	$arr['name']=$record['name'];
	$arr['content']=$record['content'];
	$arr['timestamp']=formatdate($record['timestamp']);
	if ($record['partval']>0)
	{
		$arr['part']='<a href="index.php?page=parts&part='.$record['part'].'&id='.$record['partval'].'">Перейти к модулю отправки</a>';
	}
	else
	{
	     $arr['part']='<a href="index.php?page=parts&part='.$record['part'].'">Перейти к модулю отправки</a>';
	}
	header('Content-Type: application/json');
	echo json_encode($arr);
?>