<script type="text/javascript" src="inc/items.js"></script>
<? 
$ID=(int)$_GET['id'];
$sql=mysql_query("SELECT * FROM catalog WHERE id='$ID'");
$record=mysql_fetch_array($sql);
$catid=(int)$record['id'];
echo '<input type=hidden id="catid" value="'.$ID.'">';
if (!$record) die();
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">КАТАЛОГ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=catalog">Каталог</a> » <a href="index.php?page=items&id=<?=$ID?>"><?=$record['name']?></a></div>
<div class="hem20"></div>
<div class="pages-left">
<div class="hem10"></div>
<button class="submit" type="button" id="but-add">Добавить товар</button>
<div class="clear"></div>
<div class="hem10"></div>
<h3>Товары категории</h3>
<div id="blockcatalog">
<div class="f08">Страница: <select class="pager" id="pager1"></select></div>
<div class="hem10"></div>
<div id="showcatalog"></div>
<div class="hem10"></div>
<div class="f08">Страница: <select class="pager" id="pager2"></select></div>
</div>
</div>
<div class="pages-right">
	<div id="wait" class="none">
	<div class="hem30"></div><div class="ball"></div><div class="ball1"></div>
	</div>
	
	<div id="pages-info" class="bigEntrance">
	</div>
	
	<div id="pages-add" class="bigEntrance">
		<div class="fl"><h3 class="m0">Добавление товара</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-page-add">
			<div class="hem10"></div>
			<div class="afteri">Заголовок товара:</div>
			<input id="page-name" name="pagename" type="text" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="page-url" name="pageurl" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="page-url2" name="pageurl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
				
			<input type="hidden" value="<?=$ID?>" id="page-parent" name="pageparent">
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit">Создать товар</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	
	<div id="pages-del" class="bigEntrance">
		<div class="fl"><h3 class="m0">Удаление товара</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form">
			<div class="hem20"></div>
			Вы действительно хотите удалить товар: <b><span id="delname"></span></b> ?
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="pagedel-submit" del="">Удалить товар</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	
	<div id="pages-edit" class="bigEntrance" style="display: none;">
		<div class="fl"><h3 class="m0">Редактирование товара</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form2" id="form-page-edit" enctype="multipart/form-data">
		<input id="page-edit-id" type="hidden" value="0" name="pageid">
		<div class="hem10"></div>
		<div>
			<button class="submit2 op1" type="button" bid="1">Параметры</button>
			<button class="submit2" type="button" bid="3">Содержание</button>
			<button class="submit2" type="button" bid="4">Модули</button>
			<button class="submit2" type="button" bid="5">Мета</button>
			<div class="clear"></div>
		</div>
		<div id="pages-block1" class="pages-block">
		
			<div class="hem10"></div>
			<div class="afteri">Заголовок товара:</div>
			<input id="page-edit-name" type="text" name="pageeditname" placeholder="Введите текст в данное поле" required />
			<div class="form_hint">Заголовок будет отображаться на сайте</div>
			
			<div class="hem10"></div>
			<div class="afteri">URL:</div>
			<input id="page-edit-url" type="text" placeholder="URL сформируется автоматически" required disabled />
			<input id="page-edit-url2" name="pageediturl2" type="hidden" placeholder="URL сформируется автоматически" />
			<div class="form_hint">URL сформируется автоматически, не рекомендуем изменять это поле.
			<br>URL будет виден в адресной строке браузера
			<br><br>URL cодержит в себе латинские буквы или символ "_"<br>Не может содержать в себе пробелов</div>
				
			<div class="hem10"></div>
			<div class="afteri">Изменить URL:</div>
			<input type="checkbox" id="page-edit-newurl" name="pagenewurl"><span class="object_att"> - Внимание, при изменении URL все ссылки на данный товар перестанут работать.</span>
			
			<div class="hem10"></div>
			<div class="afteri">Индекс сортировки:</div>
			<input id="pages-edit-srt" name="pagesrt" type="text" placeholder="0" required />
			<div class="form_hint">Чем больше число в данном поле - тем выше будет товар при сортировке</div>
			
			<div class="hem10"></div>
			<div class="afteri">Стоимость товара:</div>
			<input id="pages-edit-price" name="pageprice" type="text" placeholder="0" required />
			
			<div class="hem10"></div>
			<div class="afteri">Артикул товара:</div>
			<input id="pages-edit-art" name="pageart" type="text" placeholder="" required />
			
			<div class="hem10"></div>
			<div class="afteri">Скрыть товар:</div>
			<input type="checkbox" id="page-edit-hide" name="pagehide"><span class="object_att"> - Товар будет виден только в системе управления</span>
			
			<div class="hem10"></div>
			<div class="afteri">Категория товара:</div>
			<select id="page-edit-parent2" name="pageeditparent2">
			</select>
			
			<input type="hidden" id="page-edit-parent" name="pageeditparent">
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		<div id="pages-block2" class="pages-block none">
		
			<div class="hem15"></div>
			<div id="ckeblock">
				
			</div>
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		<div id="pages-block3" class="pages-block none">
			<?
			$sql=mysql_query("SELECT * FROM items_config ORDER by id");
			$i=0;
			while ($record=mysql_fetch_array($sql))
			{
				$i++;
				echo '<div class="hem10"></div>';
				if ($record['type']==1)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<input id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'" type="text" placeholder="Введите текст в данное поле"  />
					<div class="form_hint">'.$record['val'].'</div>
					';
				}
				elseif ($record['type']==2)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<textarea id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'" placeholder="Введите текст в данное поле"></textarea>
					<div class="form_hint">'.$record['val'].'</div>
					';
				}
				elseif ($record['type']==3)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<div id="dop-'.$record['ident'].'" need="dop-edit-'.$record['ident'].'"></div>
					';
				}
				elseif ($record['type']==4)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<div id="dop-'.$record['ident'].'" need="dop-edit-'.$record['ident'].'"></div>
					';
				}
				elseif ($record['type']==5)
				{
					echo '
					<div class="afteri">'.$record['name'].':</div>
					<select id="dop-'.$record['ident'].'" name="dop-'.$record['ident'].'">
					</select>
					';
				}
				elseif ($record['type']==6)
				{	
					echo '<div class="afteri">'.$record['name'].':</div>';
					echo '<div class="iload">
						<input type="file" id="dop-'.$record['ident'].'" onchange="fileSelectHandler(this,'.$CONFIG['max_upload_images_width'].','.$CONFIG['max_upload_images_height'].','.$CONFIG['max_upload_images_size'].','.$record['val'].','.$CONFIG['resize_images_big'].',\'itemsdop\',\'oldimg-'.$record['ident'].'\')">';
						
						echo '
						<div class="img-info"></div>
						<input type="hidden" class="iloadval" name="dop-'.$record['ident'].'">
					</div>';
					
					echo '
					<div id="oldimg-'.$record['ident'].'" class="oldimghide">
					<div class="hem10"></div>
					<div class="afteri">Текущее изображение:</div>
					<div class="hem10"></div>
					<div class="oldimg"></div>
					<div class="imgdel f08 orange pointer">Удалить</div>
					<input type="hidden" class="imagsold" name="dopold-'.$record['ident'].'">
					</div>';
				}
			}
			
			
			$sql=mysql_query("SELECT * FROM catalog WHERE id='$catid'");
			$record=mysql_fetch_array($sql);
			$mydoparr=array();
			if($record['filt1']!="")
			{
			$mydop=$record['filt1'];
			$mydoparr=explode('~~~',$mydop);
			}
			if($record['filt2']!="")
			{
				$mydop2=$record['filt2'];
				$mydoparr2=explode('###',$mydop2);
			}
			if ($mydoparr && count($mydoparr)>0) 
			{
			foreach ($mydoparr as $key => $md)
				{
					$i++;
					echo '
					<div class="hem10"></div>
					<div class="afteri">'.$md.':</div>
					<select id="filt-'.$key.'" name="filt-'.$key.'"><option value="-1">Не выбрано</option>';
						$mydoparr3=explode('~~~',$mydoparr2[$key]);
						foreach ($mydoparr3 as $key2 => $md2)
							{
								echo'<option value="'.$key2.'">'.$md2.'</option>';
							}
					echo'</select>';
				}
			}
			if (!$i) echo '<div class="hem20"></div>
			<div class="f08">У данного товара нет дополнительных параметров</div>';
			?>
			
			
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</div>
		<div id="pages-block4" class="pages-block none">
			<div class="hem10"></div>
			<p><b>Доступные модули данного товара:</b></p>
			<div class="hem10"></div>
			<div id="modules">
				<div class="f08">У данного товара нет прикреплённых модулей</div>
			</div>
			<div class="hem20"></div>
		</div>
		<div id="pages-block5" class="pages-block none">
			<div class="hem10"></div>
			<div class="afteri">Мета-заголовок товара:</div>
			<input id="metaname" name="metaname" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием страницы</div>
			<div class="hem10"></div>
			<div class="afteri">Заголовок h1:</div>
			<input id="metah1" name="metah1" type="text" placeholder="Введите текст в данное поле"  />
			<div class="form_hint">Если вы не заполните данное поле - оно автоматически будет заполнено названием страницы</div>
			<div class="hem10"></div>
			<div class="afteri">Мета-описание товара:</div>
			<textarea id="metacontent" name="metacontent" placeholder="Введите текст в данное поле"  /></textarea>
			<div class="form_hint">Мета-описания не должны быть короткими, в несколько слов.<br>Должны описывать конкретную страницу сайта, а не сайт в целом.<br><br>Мета-описания должны быть емкими и при этом содержательными. Старайтесь выразить основную суть страницы в нескольких предложениях.</div>
			
			<div class="hem10"></div>
			<div class="afteri">Мета-изображение:</div>
			<div class="iload">
				<input type="file" id="metaloader" onchange="fileSelectHandler(this,<?=$CONFIG['max_upload_images_width']?>,<?=$CONFIG['max_upload_images_height']?>,<?=$CONFIG['max_upload_images_size']?>,<?=$CONFIG['meta_images_width']?>,<?=$CONFIG['meta_images_height']?>,<?=$CONFIG['resize_images_big']?>,'pagesmeta','oldpageimg')">
				<div class="img-info"></div>
				<input type="hidden" class="iloadval" name="metaimages">
			</div>
			<div id="oldpageimg">
			<div class="hem10"></div>
			<div class="afteri">Текущее изображение:</div>
			<div class="hem10"></div>
			<div class="oldimg"></div>
			<div class="imgdel f08 orange pointer">Удалить</div>
			<input type="hidden" class="imagsold" name="metaimagesold">
			</div>
			<div class="hem20"></div>
			<button class="submit page-save" type="button">Сохранить</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		
		</div>
		</form>
	</div>
</div>
<div class="clear"></div>