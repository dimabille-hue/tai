<script type="text/javascript" src="inc/sop.js"></script>
<?

$itemid=(int)$_GET['itemid'];
if ($itemid>0)
{
	echo '<input type=hidden id="var" value="item"><input type=hidden id="val" value="'.$itemid.'">';
	$sql=mysql_query("SELECT name FROM items WHERE id='$itemid'");
	$record=mysql_fetch_array($sql);
}
else
{
	$record=0;
}
?>
<h1 class="margin0" unselectable="on" onselectstart="return false;">Cопутствующие товары</h1>
<div class="hem10"></div>
<div class="pages-left">
	<h3>Товары «<?=$record['name']?>»</h3><div class="hem10"></div>
	<button class="submit" type="button" id="add-btn" style="margin-right: 1em;">Подобрать товары</button>
	<div class="clear"></div>
	<div class="hem20"></div>
	<div id="imgs"><div class="ball"></div><div class="ball1"></div>
	</div>
</div>
<div class="pages-right">
	<div id="pages-info" class="bigEntrance">
	</div>
	<div id="pages-add" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Добавление товаров</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
		<form class="object_form" name="object_form" id="form-add">
			<input type=hidden name="galvar" id="galvar">
			<input type=hidden name="galval" id="galval">
			<div class="hem10"></div>
			<div class="afteri">Выберите товар:</div>
			<div class="iload">
				<select name="resitem" id="resitem">
				</select>
			</div>
		
			
			<div class="hem20"></div>
			<button class="submit" type="button" id="page-submit-add">Добавить</button>
			<div class="wait2 none" id="waitadd">
				<div class="mball"></div>
			</div>
		</form>
	</div>
	
	<div id="pages-del" class="bigEntrance" style="display: none;">
	<div class="fl"><h3 class="m0">Удаление товара</h3></div><div class="fr"><div class="close"></div></div><div class="clear"></div>
	<form class="object_form" name="object_form" id="form-del">
			<div class="hem20"></div>
			Вы действительно хотите удалить товар?<br><br>
			<div class="hem20"></div>
			<div class="f09 orange bold" id="delinf"></div>
			<button class="submit" type="button" id="page-submit-del" del="" var="<?=$varn?>">Удалить товар</button>
			<div class="wait2 none">
				<div class="mball"></div>
			</div>
		</form>
</div>
</div>
</div>
<div class="clear"></div>
