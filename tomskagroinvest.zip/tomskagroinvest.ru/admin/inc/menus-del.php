<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
    mysql_query("DELETE FROM menus WHERE id='$delid'");
	
?>