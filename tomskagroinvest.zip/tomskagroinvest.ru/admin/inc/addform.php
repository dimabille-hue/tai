<h1 class="margin0" unselectable="on" onselectstart="return false;">ДОБАВИТЬ ФОРМУ</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=addform">Добавить форму</a></div>
<div class="hem10"></div>
<div class="pages-left">
<form class="object_form" name="object_form1" id="form-part" method="POST" action="index.php?page=parts">
	<div class="hem10"></div>
	<div class="afteri">Название формы:</div>
	<input id="formname" name="formname" type="text" placeholder="Введите текст в данное поле" required>
	<div class="form_hint">Название будет видно только в системе управления</div>

	<div class="hem20"></div>
	<button class="submit" type="submit">Добавить форму</button>
</form>
</div>
<div class="clear"></div>