<script type="text/javascript" src="inc/watermark.js"></script>
<h1 class="margin0" unselectable="on" onselectstart="return false;">ВОДЯНОЙ ЗНАК</h1>
<div class="bread" unselectable="on" onselectstart="return false;"><a href="index.php">Главная</a> » <a href="index.php?page=parts">Модули</a> » <a href="index.php?page=parts&part=watermark">Водяной знак</a></div>
<div class="hem10"></div>
<div class="pages-left">
<? 
$sql=mysql_query("SELECT * FROM parts_watermark");
while ($record=mysql_fetch_array($sql))
{
	$ar[$record['ident']]=$record['content'];
}
?>
<form class="object_form" name="object_form1" id="form-part">
	<h3>Настройки модуля</h3>
	<p class="f08">Водяной знак - полупрозрачное изображение, которое отображается на увеличенных фотографиях с целью защиты от копирования.</p>
	<div class="hem10"></div>
	<p class="f08">Предварительно подготовьте изображение (обычно в качестве водяного знака устанавливают логотип компании), сделайте его полупрозрачным. Максимальные размеры 1000px*1000px, максимальный вес 1 Мб.</p>
	
	<div class="hem10"></div>
	<div class="afteri">Состояние модуля:</div>
	<select name="wmpower" id="wmpower"><option value="0">Включен</option><option value="1" <? if ($ar['power']==1) echo 'selected '; ?>>Выключен</option></select>
	
	<div class="hem10"></div>
	<div class="afteri">Расположение водяного знака на картинке:</div>
	<select name="wmpos" id="wmpos"><option value="0">По центру</option><option value="1" <? if ($ar['pos']==1) echo 'selected '; ?>>Справа сверху</option><option value="2" <? if ($ar['pos']==2) echo 'selected '; ?>>Справа снизу</option><option value="3" <? if ($ar['pos']==3) echo 'selected '; ?>>Слева снизу</option><option value="4" <? if ($ar['pos']==4) echo 'selected '; ?>>Слева сверху</option></select>
	
	<div class="hem10"></div>
	<div class="afteri">Размер водяного знака по отношению к размеру картинки:</div>
	<select name="wmsize" id="wmsize"><option value="0">50%</option><option value="1" <? if ($ar['size']==1) echo 'selected '; ?>>30%</option><option value="2" <? if ($ar['size']==2) echo 'selected '; ?>>15%</option><option value="3" <? if ($ar['size']==3) echo 'selected '; ?>>75%</option></select>
	
	<div class="hem10"></div>
	<div class="afteri">Загрузить изображение:</div>
	<div class="iload">
		<input type="file" id="newimg" onchange="fileClearLoad(this)">
		<div class="img-info"></div>
		<input class="iloadval" name="src" type="hidden">
	</div>
	
	<div class="hem20"></div>
	<button class="submit" id="send" type="button">Сохранить</button>
	<div class="wait2 none" id="wait">
		<div class="mball"></div>
	</div>
</form>
<div id="info" class="options bigEntrance">
</div>
</div>
<div class="pages-right">
<h3>Текущий водяной знак</h3>
<div class="hem10"></div>
<div id="current"></div>
				
</div>
<div class="clear"></div>