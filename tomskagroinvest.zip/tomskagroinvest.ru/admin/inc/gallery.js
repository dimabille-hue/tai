$("document").ready(function () {
	var sto;
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	function  PartUp(parent)
	{
		var galvar=$("#var").val();
		var galval=$("#val").val();
		$.ajax({
				type: 'POST',
				url: 'inc/gallery-up.php',
				data: 'parent='+parent+'&galvar='+galvar+'&galval='+galval,
				success: function(data){
					Showimgs();
				}
				});
	}	
	function  PartDown(parent)
	{
		var galvar=$("#var").val();
		var galval=$("#val").val();
		$.ajax({
				type: 'POST',
				url: 'inc/gallery-down.php',
				data: 'parent='+parent+'&galvar='+galvar+'&galval='+galval,
				success: function(data){
					Showimgs();
				}
				});
	}	
	function Showimgs()
	{
		$("#imgs").html('<div class="ball"></div><div class="ball1"></div>');
		var blockw, blockh, galval, galvar, neww, newh;
		blockw=parseInt($("#blockw").val());
		blockh=parseInt($("#blockh").val());
		if (blockw>200)
		{
			var koef=blockw/200;
			neww=200;
			newh=Math.floor(blockh/koef);
		}
		else
		{
			neww=blockw;
			newh=blockh;
		}
		
		galval=$("#val").val();
		galvar=$("#var").val();
		
		$.ajax({
				dataType: 'json',
				url: 'inc/gallery-load.php',
				type: 'POST',
				data : 'galvar='+galvar+'&galval='+galval,
				cache: false,
				success: function(jsondata){
							  
				$("#imgs").html("");
				var jcol=0;
				$.each(jsondata,function(indx, element){
					$("#imgs").append('<div class="galleryel" imgid="'+element.id+'" style="width: '+(neww)+'px; height: '+(newh+30)+'px;"><div class="galleryimg" style="background: url(\'../img/upload/th/'+element.img+'\') center center no-repeat; background-size: cover; width: '+(neww)+'px; height: '+(newh)+'px;"></div><div class="gallerybtn"><div class="line-del" title="Удалить изображение"></div><div class="line-edit" title="Редактировать изображение"></div><div class="line-down" title="Опустить вниз"></div><div class="line-up" title="Поднять вверх"></div><div class="clear"></div></div></div>');
					jcol++;
				});
				if (jcol>0) { $("#imgs").append('<div class="clear"></div>'); } else { $("#imgs").html("В данной галерее нет изображений"); }
				}
				
			});
	}
	
	$("#page-submit-add").click(
		function ()
		{
			$(this).hide(0);
			$(".wait2").show(0);
			
				var data = $('#form-add').serialize();
				$.ajax({
				url: 'inc/gallery-add-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$(".wait2").hide(0);
					PagesInfo(data);
					$("#pages-add").hide(0);
					Showimgs();
				}
				});
			
		});
		
	Showimgs();
		
	function PartAdd()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#page-submit-add").show(0);
		$("#waitadd").hide(0);
		
		$("#galvar").val($("#var").val());
		$("#galval").val($("#val").val());
		
		$("#metaloader").parent().find(".img-info").html("Добавьте изображение");
		$("#metaloader").prop('value', null);
		$("#metaloader").parent().find(".iloadval").val("");
		
		$("#galname").val("");
		$("#galalt").val("");
		$("#galtitle").val("");
					
		$("#pages-add").show(0);
	}
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			var delvar=$("#page-submit-del").attr("var");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/gallery-del.php',
				data: 'delid='+delid+'&delvar='+delvar,
				success: function(data){
				$(".wait2").hide(0);
				Showimgs();
				PagesInfo("Изображение успешно удалено");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function PartDel(imgid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#page-submit-del").show(0);
		
		$("#page-submit-del").attr("del",imgid);
		$("#pages-del").show(0);
	}
	
	$("#page-submit-edit").click(function(){
		$("#page-submit-edit").hide(0);
		$(".wait2").show(0);
		
		var data = $('#form-edit').serialize();
		$.ajax({
				url: 'inc/gallery-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".wait2").hide(0);
					Showimgs();
					PagesInfo(data);
					$("#pages-edit").hide(0);	
				}
				});
	});
	
	function PartEdit(imgid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#page-submit-edit").show(0);
		
		$("#galeditname").val("");
		$("#galeditalt").val("");
		$("#galedittitle").val("");
		$("#galeditsrt").val("0");
		
		
		$("#galeditvar").val($("#var").val());
		$("#galeditval").val(imgid);
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/gallery-edit.php',
		  data: 'imgid='+imgid+'&imgvar='+($("#var").val()),
		  cache: false,
		  success: function(jsondata){
		  
				$("#galeditname").val(jsondata[0].name);
				$("#galeditalt").val(jsondata[0].alt);
				$("#galedittitle").val(jsondata[0].title);
				
				$("#galeditsrt").val(jsondata[0].srt);
				$("#pages-edit").show(0);
		  }
		  });
		
	}
	
	$("#add-btn").click(function(){
		PartAdd();
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PartEdit($(this).parent().parent().attr('imgid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('imgid'));
	});
	$(".pages-left").on("click",".line-up",function(){
		  PartUp($(this).parent().parent().attr('imgid'));
	});
	$(".pages-left").on("click",".line-down",function(){
		  PartDown($(this).parent().parent().attr('imgid'));
	});
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
});