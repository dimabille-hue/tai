$("document").ready(function () {
	var sto;
	var pagelist=1;
	function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
	var showhide=0;
	
	function ShowFaq()
	{
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/faq-options.php',
		  cache: false,
		  success: function(jsondata){
				showhide=jsondata[0]['afteranswer'];
			}
		  });
	
		$("#blockfaq").html("");
		$.ajax({
				  url: 'inc/faq-col.php',
				  cache: false,
				  success: function(data){
					var pagecol=Math.ceil(data/20);
					if (pagecol>0)
					{
						if (pagelist>pagecol) { pagelist=pagecol; }
						if (pagelist<=0) { pagelist=1; }
						$("#pager1").html("");
						$("#pager2").html("");
						$("#blockfaq").html('<div class="f08">Страница: <select class="pager" id="pager1"></select></div><div class="hem10"></div><div id="showfaq"><div id="wait"><div class="hem30"></div><div class="ball"></div><div class="ball1"></div></div></div><div class="hem10"></div><div class="f08">Страница: <select class="pager" id="pager2"></select></div>')
						for (var i=1;i<=pagecol;i++)
						{
							var inj1="";
							if (i==pagelist) { inj1="selected"; }
							$("#pager1").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
							$("#pager2").append('<option value="'+i+'" '+inj1+'>'+i+'</option>');
						}
							
							$.ajax({
							  dataType: 'json',
							  url: 'inc/faq-load.php',
							  type: 'POST',
							  data : 'pagelist='+pagelist,
							  cache: false,
							  success: function(jsondata){
							  
								$("#showfaq").html("");
								$.each(jsondata,function(indx, element){
									if (showhide==0)
									{
										var inj4='<div class="line-show" title="Вопрос виден на сайте"></div>';
									}
									else
									{
										if (element.hide==0)
										{
											var inj4='<div class="line-show" title="Вопрос виден на сайте"></div>';
										}
										else
										{
											var inj4='';
										}
									}
									$("#showfaq").append('<div class="line" faqid="'+element.id+'"><div class="line-inside"><div class="line-open line-dot"></div><div class="line-name2"><div class="line-name-text">' + element.name + ' <span class="f07 gray">' + element.timestamp+ '</span></div></div><div class="line-del" title="Удалить вопрос"></div><div class="line-edit" title="Редактировать вопрос"></div>'+inj4+'</div></div>');
				
									
								});
							  }});
							
						
					}
					else
					{
						$("#blockfaq").html('<div class="f08">Не нашлось ни одного вопроса</div>');
					}
				 }
				});
		
	}
	
	$(".pages-left").on("change","#pager1",function(){
		  pagelist=$(this).val();
		ShowFaq();
	});
	
	$(".pages-left").on("change","#pager2",function(){
		  pagelist=$(this).val();
		ShowFaq();
	});
	
	ShowFaq();
	
	$("#page-submit").click(
		function ()
		{
			$(this).hide(0);
			$("#waitopt").show(0);
			
				var data = $('#form-options').serialize();
				$.ajax({
				url: 'inc/faq-options-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$("#waitopt").hide(0);
					PagesInfo(data);
					$("#options").hide(0);
					ShowFaq();
				
				}
				});
			
		});
		
	$("#page-submit-add").click(
		function ()
		{
			$(this).hide(0);
			$("#waitadd").show(0);
			var pagecontent;
			CKEDITOR.instances['faqaddeditor'].updateElement();
			pagecontent = CKEDITOR.instances['faqaddeditor'].getData();
			$("#faqaddeditor").html(pagecontent);
		
				var data = $('#form-add').serialize();
				$.ajax({
				url: 'inc/faq-add-save.php',
				type: 'POST',
				cache:false,
				data : data,
				success: function(data){
				
					$("#waitadd").hide(0);
					PagesInfo(data);
					$("#pages-add").hide(0);
					ShowFaq();

				}
				});
			
		});
		
	function PartAdd()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-add").show(0);
		$("#waitadd").hide(0);
		
		$("#faqaddname").val("");
		$("#faqaddcontent").val("");
		$("#faqaddtimestamp").val("");
		$("#ckeblock").html("");
		$("#ckeblock").html('<textarea name="faqaddeditor" id="faqaddeditor" rows="10" cols="80"></textarea>');
		
		var editor;
		editor = CKEDITOR.replace('faqaddeditor',{
			removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
			
		});
		CKFinder.setupCKEditor(editor, "ckfinder/");
		$("#faqaddtimestamp").datetimepicker( $.datepicker.regional[ "ru" ] );
		$("#pages-add").show(0);
	}
	
	$("#page-submit-edit").click(function(){
		$("#page-submit-edit").hide(0);
		$(".wait2").show(0);
		var pagecontent;
		CKEDITOR.instances['faqediteditor'].updateElement();
		pagecontent = CKEDITOR.instances['faqediteditor'].getData();
		$("#faqediteditor").html(pagecontent);
		var data = $('#form-edit').serialize();
		$.ajax({
				url: 'inc/faq-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
					$(".wait2").hide(0);
					ShowFaq();
					PagesInfo(data);
					$("#pages-edit").hide(0);	
				}
				});
	});
	
	function PartEdit(faqid)
	{
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-edit").show(0);
		$("#waitedit").hide(0);
		
		$("#faqeditname").val("");
		$("#faqeditcontent").val("");
		$("#faqedittimestamp").val("");
		$("#ckeblockedit").html("");
		$("#faqeditemail").val("");
		$("#faqid").val(faqid);
		$("#faqedithide").val(0);
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/faq-edit.php',
		  data: 'faqid='+faqid,
		  cache: false,
		  success: function(jsondata){
				if (jsondata[0].answer==null) { jsondata[0].answer=''; }
				$("#faqeditname").val(jsondata[0].name);
				$("#faqeditcontent").val(jsondata[0].content);
				$("#faqedittimestamp").val(jsondata[0].timestamp);
				$("#faqedittimestamp").datetimepicker( $.datepicker.regional[ "ru" ] );
				$("#ckeblockedit").html('<textarea name="faqediteditor" id="faqediteditor" rows="10" cols="80">'+jsondata[0].answer+'</textarea>');
				var editor;
				editor = CKEDITOR.replace('faqediteditor',{
					removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
					
				});
				CKFinder.setupCKEditor(editor, "ckfinder/");
				$("#faqeditemail").val(jsondata[0].email);
				$("#faqedithide").val(jsondata[0].hide);
				$("#pages-edit").show(0);
		  }
		  });
		
	}
	
	$("#page-submit-del").click(
		function ()
		{
			$("#page-submit-del").hide(0);
			$(".wait2").show(0);
			var delid=$("#page-submit-del").attr("del");
			$("#page-submit-del").attr("del","");
			
			if ((delid!="") && (delid!="0") && (delid!=0))
			{
				$.ajax({
				type: 'POST',
				url: 'inc/faq-del.php',
				data: 'delid='+delid,
				success: function(data){
				$(".wait2").hide(0);
				ShowFaq();
				PagesInfo("Вопрос успешо удалён");
				$("#pages-del").hide(0);
				}
				});
			}
		});
		
	function PartDel(faqid)
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit-del").show(0);
		$("#waitdel").hide(0);
		
		$.ajax({
				type: 'POST',
				url: 'inc/faq-del-name.php',
				data: 'delid='+faqid,
				dataType: 'json',
				success: function(data){
						$("#pages-del").show(0);
						$("#page-submit-del").attr("del",faqid);
						$("#delname").html(data.name);
					
				}
				});
				
	}
	
	function PageOptions(pageid)
	{
		$(".wait2").hide(0);
		$("#faqpage").html('<option value="0">Выберите страницу</option>');
	$.ajax({
				  dataType: 'json',
				  url: 'inc/pages-option-free.php',
				  cache: false,
				  success: function(jsondata){
					$.each(jsondata,function(indx, element){
					var inj1="", inj2="";
					if (pageid==element.id) { inj2=" selected ";} 
					if (element.level=="1") { inj1="&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="2") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
					if (element.level=="3") { inj1="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; }
						 $("#faqpage").append('<option value="' + element.id + '" ' + inj2 + '>'+ inj1 + element.name + '</option>');
					});
				 }
				});
	}
	
	function PartOpt()
	{
		$(".wait2").hide(0);
		$("#pages-add").hide(0);
		$("#pages-del").hide(0);
		$("#pages-edit").hide(0);
		$("#pages-info").hide(0);
		$("#options").hide(0);
		$("#page-submit").show(0);
		$("#waitopt").hide(0);
		
		
		$.ajax({
		  dataType: 'json',
		  type: 'POST',
		  url: 'inc/faq-options.php',
		  cache: false,
		  success: function(jsondata){
				$("#faqpower").val(jsondata[0]['power']);
				PageOptions(jsondata[0]['page']);
				$("#faqallowadd").val(jsondata[0]['allowadd']);
				$("#faqafteranswer").val(jsondata[0]['afteranswer']);
				$("#faqnotice").val(jsondata[0]['notice']);
				$("#options").show(0);
			}
		  });
		
	}
	
	$("#but-opt").click(function(){
		PartOpt();
	});
	
	$("#but-add").click(function(){
		PartAdd();
	});
	
	$(".pages-left").on("click",".line-edit",function(){
		  PartEdit($(this).parent().parent().attr('faqid'));
	});
	
	$(".pages-left").on("click",".line-del",function(){
		  PartDel($(this).parent().parent().attr('faqid'));
	});
	
	$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});
});