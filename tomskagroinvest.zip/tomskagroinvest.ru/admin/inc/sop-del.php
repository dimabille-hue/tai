<?
	include('../cfg.php');
	include('access.php');
	$delid=(int)$_POST['delid'];
	if ($delid)
	{
		$sql=mysql_query("SELECT * FROM sop WHERE id='$delid'");
		$record=mysql_fetch_Array($sql);
		$cat=$record['item'];
		$stat=$record['stat'];
	     mysql_query("DELETE FROM sop WHERE item='$cat' and stat='$stat'");
	}
	
	
?>