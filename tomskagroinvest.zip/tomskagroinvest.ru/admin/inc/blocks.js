$("document").ready(function () {

	var sto;
function PagesInfo(info)
	{
		clearTimeout(sto);
		$("#pages-info").show(300);
		$("#pages-info").html(info);
		sto=setTimeout(function(){
			$("#pages-info").html("");
			$("#pages-info").hide(0);
		}, 5000)
	}
	
$(".blocks-save").click(function(){
	$(".blocks-save").hide(0);
	$(".wait2").show(0);
	var blockid;
	blockid=$("#blocks-edit-id").val();
	$("[need]").map(function(indx, element){
			var iname = $(this).attr('need');
			CKEDITOR.instances[iname].updateElement();
			var j = CKEDITOR.instances[iname].getData();
			$("#"+iname).html(j);
		});
	var data = $('#form-blocks-edit').serialize();
	if (blockid!="" && blockid>0)
	{
		$.ajax({
				url: 'inc/blocks-edit-save.php',
				type: 'POST',
				data : data,
				cache:false,
				processData: false,
				success: function(data){
				$(".wait2").hide(0);
				PagesInfo("Блок успешно обновлён");
				$("#blocks-edit").hide(0);
				}
				});
	}
	else
	{
		PagesInfo("Блок не сохранен, произошла ошибка");
		$("#blocks-edit").hide(0);
		$(".wait2").hide(0);
	}
});



function BlockEdit(parent)
	{
		$("#blocks-edit").hide(0);
		$(".blocks-save").show(0);
		$("#block-place").html("");
		$("#pages-info").hide(0);
		$("#block-name").html("");
		$(".wait2").hide(0);
		$("#blocks-edit-id").val(parent);
		$("body").scrollTop(0);
		$.ajax({
			  dataType: 'json',
			  type: 'POST',
			  url: 'inc/blocks-edit.php',
			  data: 'blockid='+parent,
			  cache: false,
			  success: function(jsondata){
				$("#block-name").html(jsondata[0].name);
				if (jsondata[0].content==null) { jsondata[0].content=''; }
				if (jsondata[0].type==1)
				{
				$("#block-place").html('<div class="afteri">Содержание блока:</div><input id="blocktype1" type="text" name="blocktype1" placeholder="Введите текст в данное поле" value="'+jsondata[0].content+'" required /><div class="form_hint">'+jsondata[0].val+'</div>');
				}
				if (jsondata[0].type==2)
				{
				$("#block-place").html('<div class="afteri">Содержание блока:</div><textarea id="blocktype2" name="blocktype2" placeholder="Введите текст в данное поле" required>' + jsondata[0].content + '</textarea><div class="form_hint">'+jsondata[0].val+'</div>');
				}
				if (jsondata[0].type==3)
				{
					$("#block-place").html('<div class="afteri">Содержание блока:</div><div id="blocktype3" need="blocktype3-editor"></div>');
					$("#blocktype3").html('<textarea name="blocktype3" id="blocktype3-editor" rows="10" cols="80">' + jsondata[0].content + '</textarea>');
					var dopeditor;
					dopeditor = CKEDITOR.replace('blocktype3-editor',{
						removeButtons : 'Save,Templates,NewPage,Print,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About,Font,Smiley,Language,BidiLtr,BidiRtl,Scayt,SelectAll'
					});
					CKFinder.setupCKEditor(dopeditor, "ckfinder/");
				}
				if (jsondata[0].type==4)
				{
					$("#block-place").html('<div class="afteri">Содержание блока:</div><div id="blocktype4" need="blocktype4-editor"></div>');
					$("#blocktype4").html('<textarea name="blocktype4" id="blocktype4-editor" rows="10" cols="80">' + jsondata[0].content + '</textarea>');
					var dopeditor;
					dopeditor = CKEDITOR.replace('blocktype4-editor',{
						removeButtons : 'Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Image,Flash,HorizontalRule,Smiley,SpecialChar,PageBreak,Language,BidiRtl,BidiLtr,Font,About,Table,Indent,Outdent,Redo,Undo,Blockquote,CreateDiv,Superscript,Subscript'
					});
					CKFinder.setupCKEditor(dopeditor, "ckfinder/");
				}
				if (jsondata[0].type==5)
				{
					var conf1, conf2, conf3, conf4;
					conf1=$("#conf1").val();
					conf2=$("#conf2").val();
					conf3=$("#conf3").val();
					conf4=$("#conf4").val();
					$("#block-place").html('<div class="afteri">Содержание блока:</div><div class="iload"><input type="file" id="blocktype5" onchange="fileSelectHandler(this,'+conf1+','+conf2+','+conf3+','+jsondata[0].val+','+conf4+',\'blocks\',\'blockoldimg\')"><div class="img-info"></div><input type="hidden" class="iloadval" name="blocktype5new"></div><div id="blockoldimg" class="oldimghide"><div class="hem10"></div><div class="afteri">Текущее изображение:</div><div class="hem10"></div><div class="oldimg"></div><div class="imgdel f08 orange pointer">Удалить</div><input type="hidden" class="imagsold" name="blocktype5old"></div>');
					if (jsondata[0].content!='')
					{
						$("#blocktype5").parent().find(".img-info").html("Добавьте изображение");
						$("#blocktype5").prop('value', null);
						$("#blocktype5").parent().find(".iloadval").val("");
						$("#blockoldimg").find(".imagsold").val(jsondata[0].content);
						$("#blockoldimg").find(".oldimg").css({'background':'url(../img/upload/th/'+jsondata[0].content+') center center no-repeat', 'background-size':'cover'});
						$("#blockoldimg").show(0);
					}
					else
					{
						$("#blocktype5").parent().find(".img-info").html("Добавьте изображение");
						$("#blocktype5").prop('value', null);
						$("#blocktype5").parent().find(".iloadval").val("");
						$("#blockoldimg").hide(0);
					}
				}
				$("#blocks-edit").show(300);
			  }
			  });
	}

function BlocksPrint()
	{
		$("#blocks-tree").html('<div class="hem30"></div><div class="ball"></div><div class="ball1"></div>');
		$.ajax({
		  dataType: 'json',
		  url: 'inc/blocks-tree.php',
		  cache: false,
		  success: function(jsondata){
			$("#blocks-tree").html('');
			$.each(jsondata,function(indx, element){
				 $("#blocks-tree").append('<div class="line" blockid="' + element.id + '"><div class="line-inside line-level0"><div class="line-open line-dot"></div><div class="line-name"><div class="line-name-text">' + element.name + '</div></div><div class="line-edit" title="Редактировать блок"></div></div></div>');
			});
		 }
		});
			
	}
	
	BlocksPrint();
	
$("#blocks-tree").on("click",".line-edit",function(){
		  BlockEdit($(this).parent().parent().attr('blockid'));
	});
	
$("#blocks-edit").on("click",".imgdel",function(){
		$(this).parent().hide(0);
		$(this).parent().find(".imagsold").val("");
	});


$(".close").click(function(){
		  $(this).parent().parent().hide(0);
				$(".wait2").hide(0);
	});	
	
});