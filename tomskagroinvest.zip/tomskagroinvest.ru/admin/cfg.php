<?
ini_set('display_errors','Off');
$DATABASE['host'] ="localhost";
$DATABASE['name']="u2818473_agroinvest";
$DATABASE['user']= "u2818473_agroinv";
$DATABASE['pass']= "iI1hG7zU7zbT3yJ9";
$DATA = mysql_connect($DATABASE['host'], $DATABASE['user'], $DATABASE['pass']);
//if (!$DATA) echo 'Нет доступа к базе данных номер';
mysql_select_db($DATABASE['name'], $DATA);
mysql_query('SET NAMES utf8');
?>