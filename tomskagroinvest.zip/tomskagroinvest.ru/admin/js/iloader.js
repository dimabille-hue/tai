$("document").ready(function () {
$("#iloader-close").click(function()
	{
					var elems=$(this).attr("rel");
					$("#iloader2").fadeOut(300);
					$("#"+elems).parent().find(".img-info").html("Загрузка отменена");
					$("#"+elems).prop('value', null);
					$('.error').html("");
									jcrop_api.destroy();
									$("#preview").attr("src","");
									$("#preview").attr("style","");
	});

	$("#iloader-submit").click(function()
	{
		
		var elems=$(this).attr("rel");
		$('.waitload').show(0);
		$(this).hide(0);
		var fd = new FormData();
		fd.append("loadimg", $("#"+elems)[0].files[0]);
		fd.append("fmaxw", fmaxw);
		fd.append("fmaxh", fmaxh);
		fd.append("fmaxs", fmaxs);
		fd.append("fcurw", fcurw);
		fd.append("fcurh", fcurh);
		
		if ($('#ignore').prop('checked'))
		{
		fd.append("ignore", 1);
		}
		else
		{
		fd.append("ignore", 0);
		}
		fd.append("quality", $("#quality").val());
		fd.append("fcurw2", fcurw2);
		fd.append("fx", Math.ceil(fx*koef));
		fd.append("fy", Math.ceil(fy*koef));
		fd.append("fx2", Math.ceil(fx2*koef));
		fd.append("fy2", Math.ceil(fy2*koef));
		fd.append("fw", Math.ceil(fw*koef));
		fd.append("fh", Math.ceil(fh*koef));
		fd.append("fpart", fpart);
		$.ajax({
			url: 'inc/iloader.php',
			type: "POST",
			data: fd,
			dataType: 'json',
			processData: false,
			contentType: false,
			cache: false,
			success: function(res){
			$('.waitload').hide(0);
			$("#iloader2").fadeOut(300);
			$("#"+elems).parent().find(".img-info").html(res.result);
			$("#"+elems).parent().find(".iloadval").val(res.name);
			$("#"+fold).hide(0);
			$('.error').html("");
			jcrop_api.destroy();
			$("#preview").attr("src","");
			$("#preview").attr("style","");
			}
		});
	});
});

var jcrop_api;
 var elem;
var koef = 0;
var fmaxw, fmaxh, fmaxs, fcurw, fcurh, fcurw2, fx, fy, fx2, fy2, fw, fh, fpart, fold; 
 
// обновление
function updateInfo(e) {
	var finstr=e.x + ":" + e.y + ":" + e.x2 + ":" + e.y2 + ":" + e.w + ":" + e.h;
	fx=e.x; fy=e.y; fx2=e.x2; fy2=e.y2; fw=e.w; fh=e.h;
	$("#iloader-submit").show(300);
};
 
// очистка инфы об обрезке
function clearInfo() {
	$("#iloader-submit").hide(300);
};

	


 
function fileSelectHandler(elid, maxw, maxh, maxs, curw, curh, curw2, part ,old) {
	fmaxw=maxw; fmaxh=maxh; fmaxs=maxs; fcurw=curw; fcurh=curh; fcurw2=curw2; fpart=part; fold=old;
	
	$('.waitload').hide(0);
	elem=elid.id;
	$("#iloader-submit").hide(0);
	$("#iloader2").fadeIn(300);
	$("#iloader-close").attr("rel",elem);
	$("#iloader-submit").attr("rel",elem);
	$("#quality").val(75);
    // добавить выбранный файл
    var oFile = $('#'+elem)[0].files[0];
 
    // ошибочка
    $('.error').hide();
 
    // проверка расширения файла
    var rFilter = /^(image\/jpeg|image\/png)$/i;
    if (! rFilter.test(oFile.type)) {
        $('.error').html('Ваш файл имеет недопустимый формат. Допустимые форматы: .jpg, .png, .jpeg').show();
        return;
    }
 
    // проверка веса файла
    if (oFile.size > parseInt(maxs) * 1024 * 1024) {
        $('.error').html('Ваш файл слишком много весит. Максимальный вес: ' + maxs + ' Мб.').show();
        return;
    }
	

	

    // просмотр
    var oImage = document.getElementById('preview');
 
    // HTML5 FileReader
    var oReader = new FileReader();
        oReader.onload = function(e) {
 
        // e.target.result contains the DataURL
        oImage.src = e.target.result;
        oImage.onload = function () { // onload event handler
		
			// проверка размера файла
			if ((oImage.naturalWidth<parseInt(curw)) || (oImage.naturalHeight<parseInt(curh))) {
				$('.error').html('Изображение слишком маленькое. Минимальные размеры: '+curw+'x'+curh+'px.').show();
				return;
			}
			
			// проверка размера файла
			if ((oImage.naturalWidth>parseInt(maxw)) || (oImage.naturalHeight>parseInt(maxh))) {
				$('.error').html('Изображение слишком большое. Максимальные размеры: '+maxw+'x'+maxh+'px.').show();
				return;
			}
			
			
			if (oImage.naturalWidth > oImage.naturalHeight)
			{
				$("#preview").attr("width","400");
				$("#preview").attr("height","");
				koef = oImage.naturalWidth / 400;
			}
			else
			{
				$("#preview").attr("height","400");
				$("#preview").attr("width","");
				koef = oImage.naturalHeight / 400;
			}
 
            // показать
            $('.step2').fadeIn(500);

 
            // переменные для размера изображения
            var boundx, boundy;
 
            // давай до свидания Jcrop
            if (typeof jcrop_api != 'undefined')
                jcrop_api.destroy();
 
            // инициировать Jcrop
            $('#preview').Jcrop({
                minSize: [(Math.ceil(curw/koef)), (Math.ceil(curh/koef))], // min crop size
                aspectRatio: curw / curh, // keep aspect ratio 1:1
                bgFade: true, // use fade effect
                bgOpacity: .3, // fade opacity
                onChange: updateInfo,
                onSelect: updateInfo,
                onRelease: clearInfo
            }, function(){
 
                // спросить у API реальный размер изображения
                var bounds = this.getBounds();
                boundx = bounds[0];
                boundy = bounds[1];
 
                // подружить Jcrop API с переменными jcrop_api
                jcrop_api = this;
            });
			
			
        };
    };
 
    // чтение выбранного файла как DataURL
    oReader.readAsDataURL(oFile);
}