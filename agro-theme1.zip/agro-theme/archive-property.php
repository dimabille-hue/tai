<?php get_header(); ?>

<section class="bg-[#106042] text-white py-20">

    <div class="max-w-7xl mx-auto px-6">

        <div class="max-w-3xl">

            <div class="uppercase tracking-widest text-[#F2D8A7] text-sm mb-4">
                ТомскАгроИнвест
            </div>

            <h1 class="text-5xl font-bold mb-6">
                Аренда помещений и объектов
            </h1>

            <p class="text-xl text-white/80">
                Предлагаем торговые площади, складские помещения,
                офисы и объекты инфраструктуры на территории
                Кулагинского рынка.
            </p>

        </div>

    </div>

</section>


<section class="py-20 bg-gray-50">

    <div class="max-w-7xl mx-auto px-6">

        <?php if (have_posts()) : ?>

            <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

                <?php while (have_posts()) : the_post();

                    $gallery = carbon_get_post_meta(
                        get_the_ID(),
                        'crb_property_gallery'
                    );

                    $image = (
                        is_array($gallery)
                        && !empty($gallery)
                    )
                        ? wp_get_attachment_url($gallery[0])
                        : agro_get_first_attachment_url(get_the_ID());

                ?>

                    <article class="agro-card bg-white">

                        <?php if ($image) : ?>

                            <a href="<?php the_permalink(); ?>">

                                <img
                                    src="<?php echo esc_url($image); ?>"
                                    alt="<?php the_title_attribute(); ?>"
                                    class="w-full h-64 object-cover"
                                >

                            </a>

                        <?php else : ?>

                            <div class="h-64 bg-gray-200 flex items-center justify-center text-gray-500">
                                Фото объекта
                            </div>

                        <?php endif; ?>

                        <div class="p-6">

                            <h2 class="text-2xl font-bold mb-3 text-[#106042]">

                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>

                            </h2>

                            <div class="text-gray-600 mb-6">

                                <?php
                                echo wp_trim_words(
                                    wp_strip_all_tags(get_the_content()),
                                    20
                                );
                                ?>

                            </div>

                            <a
                                href="<?php the_permalink(); ?>"
                                class="inline-flex items-center text-[#008136] font-semibold hover:underline"
                            >
                                Подробнее →
                            </a>

                        </div>

                    </article>

                <?php endwhile; ?>

            </div>

            <div class="mt-16">

                <?php
                the_posts_pagination([
                    'mid_size' => 2,
                    'prev_text' => '← Назад',
                    'next_text' => 'Вперёд →',
                ]);
                ?>

            </div>

        <?php else : ?>

            <div class="text-center py-20">

                <h2 class="text-3xl font-bold mb-4">
                    Объекты пока не добавлены
                </h2>

                <p class="text-gray-600">
                    Информация появится позже.
                </p>

            </div>

        <?php endif; ?>

    </div>

</section>

<?php get_footer(); ?>
