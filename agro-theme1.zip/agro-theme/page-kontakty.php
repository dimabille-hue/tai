<?php get_header(); ?>
<div class="max-w-7xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold text-gray-800 mb-8">Контакты</h1>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <h2 class="text-2xl font-bold mb-4">Свяжитесь с нами</h2>
            <ul class="space-y-4 text-gray-700">
                <li><span class="font-medium">Телефон:</span> +7 (3822) 24-43-10</li>
                <li><span class="font-medium">Email:</span> info@tomskagroinvest.ru</li>
                <li><span class="font-medium">Адрес:</span> Томск, пр. Фрунзе, 119/5</li>
                <li><span class="font-medium">Режим работы:</span> Пн-Пт 8:00–17:00</li>
            </ul>
            <div class="mt-6">
                <h3 class="font-bold text-lg mb-2">Отдел аренды</h3>
                <p>📞 +7 (3822) 24-43-10 доб. 601</p>
                <p>✉️ arenda@tomskagroinvest.ru</p>
            </div>
        </div>
        <div>
            <h2 class="text-2xl font-bold mb-4">Напишите нам</h2>
            <?php echo do_shortcode('[contact-form-7 id="123" title="Контактная форма"]'); ?>
            <!-- Замените ID на реальный ID формы -->
        </div>
    </div>
</div>
<?php get_footer(); ?>