<?php get_header(); ?>

<?php while (have_posts()) : the_post();

    $gallery = carbon_get_post_meta(
        get_the_ID(),
        'crb_property_gallery'
    );

?>

<!-- HERO -->

<section class="bg-[#106042] text-white py-20">

    <div class="max-w-7xl mx-auto px-6">

        <div class="max-w-4xl">

            <div class="uppercase tracking-widest text-[#F2D8A7] text-sm mb-4">
                Объект недвижимости
            </div>

            <h1 class="text-5xl font-bold mb-6">
                <?php the_title(); ?>
            </h1>

        </div>

    </div>

</section>


<!-- ГАЛЕРЕЯ -->

<?php if (!empty($gallery)) : ?>

<section class="py-12 bg-white">

    <div class="max-w-7xl mx-auto px-6">

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-4">

            <?php foreach ($gallery as $image_id) : ?>

                <img
                    src="<?php echo esc_url(
                        wp_get_attachment_url($image_id)
                    ); ?>"
                    alt=""
                    class="w-full h-64 object-cover rounded-2xl"
                >

            <?php endforeach; ?>

        </div>

    </div>

</section>

<?php endif; ?>


<!-- ОПИСАНИЕ -->

<section class="py-16 bg-gray-50">

    <div class="max-w-7xl mx-auto px-6">

        <div class="grid lg:grid-cols-3 gap-10">

            <div class="lg:col-span-2">

                <div class="bg-white rounded-3xl p-8 shadow-sm">

                    <h2 class="text-3xl font-bold mb-6">
                        Описание объекта
                    </h2>

                    <div class="prose max-w-none">

                        <?php the_content(); ?>

                    </div>

                </div>

            </div>

            <div>

                <div class="bg-white rounded-3xl p-8 shadow-sm sticky top-28">

                    <h3 class="text-2xl font-bold mb-6 text-[#106042]">
                        Информация
                    </h3>

                    <ul class="space-y-4 text-gray-600">

                        <li>
                            ✔ Объект доступен для аренды
                        </li>

                        <li>
                            ✔ Индивидуальные условия
                        </li>

                        <li>
                            ✔ Удобное расположение
                        </li>

                    </ul>

                    <a
                        href="/kontakty"
                        class="btn-primary mt-8 w-full justify-center"
                    >
                        Оставить заявку
                    </a>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ПОМЕЩЕНИЯ -->

<section class="py-20 bg-white">

    <div class="max-w-7xl mx-auto px-6">

        <div class="mb-12">

            <h2 class="text-4xl font-bold text-[#106042] mb-3">
                Помещения в данном объекте
            </h2>

            <p class="text-gray-600">
                Выберите подходящее помещение для аренды.
            </p>

        </div>

        <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-8">

            <?php

            $units = get_posts([

                'post_type' => 'unit',

                'meta_key' => 'crb_unit_parent_property',

                'meta_value' => get_the_ID(),

                'numberposts' => -1,

            ]);

            foreach ($units as $unit) :

                $price = carbon_get_post_meta(
                    $unit->ID,
                    'crb_unit_price'
                );

                $area = carbon_get_post_meta(
                    $unit->ID,
                    'crb_unit_area'
                );

                $short_desc = carbon_get_post_meta(
                    $unit->ID,
                    'crb_unit_short_desc'
                );

            ?>

                <article class="agro-card p-6">

                    <h3 class="text-2xl font-bold mb-3">

                        <?php echo esc_html(
                            $unit->post_title
                        ); ?>

                    </h3>

                    <?php if ($area) : ?>

                        <div class="mb-2 text-gray-600">
                            Площадь:
                            <strong>
                                <?php echo esc_html($area); ?> м²
                            </strong>
                        </div>

                    <?php endif; ?>

                    <?php if ($price) : ?>

                        <div class="mb-4 text-[#008136] font-bold text-xl">
                            <?php echo esc_html($price); ?>
                            ₽ / м²
                        </div>

                    <?php endif; ?>

                    <?php if ($short_desc) : ?>

                        <div class="text-gray-600 mb-6">

                            <?php
                            echo wp_trim_words(
                                wp_strip_all_tags($short_desc),
                                20
                            );
                            ?>

                        </div>

                    <?php endif; ?>

                    <a
                        href="<?php echo get_permalink($unit); ?>"
                        class="text-[#008136] font-semibold hover:underline"
                    >
                        Подробнее →
                    </a>

                </article>

            <?php endforeach; ?>

        </div>

    </div>

</section>

<?php endwhile; ?>

<?php get_footer(); ?>
