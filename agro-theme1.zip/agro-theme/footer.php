    </main>

    <footer class="relative bg-[#106042] text-white overflow-hidden">

        <!-- Декоративные дуги -->
        <div class="absolute -right-32 -bottom-32 w-96 h-96 rounded-full border-[40px] border-[#48A842]/20"></div>
        <div class="absolute -right-20 -bottom-20 w-72 h-72 rounded-full border-[30px] border-[#A6CE39]/20"></div>

        <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

                <!-- О компании -->
                <div>

                    <h3 class="text-xl font-semibold mb-5">
                        АО «ТомскАгроИнвест»
                    </h3>

                    <p class="text-sm leading-relaxed text-green-50/80">
                        Управляющая компания Томского областного рынка.
                        Создаем условия для развития сельского хозяйства,
                        торговли и поддержки региональных производителей.
                    </p>

                </div>

                <!-- Меню -->
                <div>

                    <h3 class="text-xl font-semibold mb-5">
                        Навигация
                    </h3>

                    <?php
                    wp_nav_menu([
                        'theme_location' => 'footer',
                        'container'      => false,
                        'menu_class'     => 'space-y-3 text-sm',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    ]);
                    ?>

                </div>

                <!-- Документы -->
                <div>

                    <h3 class="text-xl font-semibold mb-5">
                        Полезная информация
                    </h3>

                    <ul class="space-y-3 text-sm">

                        <li>
                            <a href="/dokumenty"
                               class="hover:text-[#F2D8A7] transition">
                                Документы
                            </a>
                        </li>

                        <li>
                            <a href="/novosti"
                               class="hover:text-[#F2D8A7] transition">
                                Новости
                            </a>
                        </li>

                        <li>
                            <a href="/arenda"
                               class="hover:text-[#F2D8A7] transition">
                                Аренда помещений
                            </a>
                        </li>

                    </ul>

                </div>

                <!-- Контакты -->
                <div>

                    <h3 class="text-xl font-semibold mb-5">
                        Контакты
                    </h3>

                    <ul class="space-y-3 text-sm">

                        <li>
                            <a href="tel:+73822244310"
                               class="hover:text-[#F2D8A7] transition">
                                +7 (3822) 24-43-10
                            </a>
                        </li>

                        <li>
                            Томск, пр. Фрунзе, 119/5
                        </li>

                        <li>
                            <a href="mailto:info@tomskagroinvest.ru"
                               class="hover:text-[#F2D8A7] transition">
                                info@tomskagroinvest.ru
                            </a>
                        </li>

                    </ul>

                </div>

            </div>

            <div class="border-t border-white/15 mt-12 pt-6">

                <div class="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-green-50/70">

                    <div>
                        © <?php echo date('Y'); ?> АО «ТомскАгроИнвест»
                    </div>

                    <div>
                        Все права защищены
                    </div>

                </div>

            </div>

        </div>

    </footer>

    <?php wp_footer(); ?>

</body>
</html>
