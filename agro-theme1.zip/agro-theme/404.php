<?php get_header(); ?>
<div class="max-w-4xl mx-auto px-4 py-20 text-center">
    <h1 class="text-6xl font-bold text-gray-300">404</h1>
    <h2 class="text-2xl font-bold text-gray-700 mt-4">Страница не найдена</h2>
    <p class="text-gray-500 mt-2">Извините, но страница, которую вы ищете, не существует.</p>
    <a href="/" class="mt-6 inline-block bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition">Вернуться на главную</a>
</div>
<?php get_footer(); ?>