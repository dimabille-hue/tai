<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<div class="min-h-screen flex flex-col">

    <!-- Top Bar -->
    <div class="bg-[#106042] text-white text-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-2">

                <div class="hidden md:block">
                    Развитие агропромышленной инфраструктуры Томской области
                </div>

                <div class="flex items-center gap-6">

                    <a href="tel:+73822244310"
                       class="hover:text-[#F2D8A7] transition">
                        +7 (3822) 24-43-10
                    </a>

                    <a href="mailto:info@tomskagroinvest.ru"
                       class="hidden md:block hover:text-[#F2D8A7] transition">
                        info@tomskagroinvest.ru
                    </a>

                </div>

            </div>
        </div>
    </div>

    <!-- Header -->
    <header class="bg-white sticky top-0 z-50 border-b border-gray-100">

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <div class="flex items-center justify-between h-24">

                <!-- Logo -->
                <div class="flex-shrink-0">

                    <?php if (has_custom_logo()) : ?>

                        <?php the_custom_logo(); ?>

                    <?php else : ?>

                        <a href="<?php echo esc_url(home_url('/')); ?>"
                           class="text-2xl font-bold text-[#106042]">

                            ТомскАгроИнвест

                        </a>

                    <?php endif; ?>

                </div>

                <!-- Desktop Menu -->
                <nav class="hidden lg:flex items-center">

                    <?php
                    wp_nav_menu([
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_class'     => 'flex items-center gap-8 text-sm font-medium text-gray-700',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    ]);
                    ?>

                </nav>

                <!-- Right Side -->
                <div class="hidden lg:flex items-center gap-4">

                    <a href="/dokumenty"
                       class="text-sm text-[#106042] hover:text-[#008136] transition">
                        Документы
                    </a>

                    <a href="/kontakty"
                       class="inline-flex items-center px-5 py-3 rounded-xl bg-[#106042] text-white text-sm font-medium hover:bg-[#008136] transition">

                        Обратная связь

                    </a>

                </div>

                <!-- Mobile Button -->
                <button id="mobile-menu-button"
                        class="lg:hidden text-[#106042]">

                    <svg class="w-8 h-8"
                         fill="none"
                         stroke="currentColor"
                         viewBox="0 0 24 24">

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16">
                        </path>

                    </svg>

                </button>

            </div>

        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu"
             class="hidden lg:hidden bg-white border-t border-gray-100">

            <div class="px-4 py-6">

                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'container'      => false,
                    'menu_class'     => 'flex flex-col gap-4',
                    'fallback_cb'    => false,
                    'depth'          => 1,
                ]);
                ?>

                <div class="mt-6">

                    <a href="/kontakty"
                       class="block text-center bg-[#106042] text-white py-3 rounded-xl">

                        Обратная связь

                    </a>

                </div>

            </div>

        </div>

    </header>

    <main class="flex-grow">
