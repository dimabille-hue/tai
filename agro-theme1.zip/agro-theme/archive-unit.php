<?php get_header(); ?>
<div class="max-w-7xl mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold text-gray-800 mb-2">Помещения в аренду</h1>
    <p class="text-gray-500 mb-8">Найдите идеальное помещение для вашего бизнеса</p>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while (have_posts()) : the_post(); 
            $price = carbon_get_post_meta(get_the_ID(), 'crb_unit_price');
            $area = carbon_get_post_meta(get_the_ID(), 'crb_unit_area');
            $short_desc = carbon_get_post_meta(get_the_ID(), 'crb_unit_short_desc');
            $gallery = carbon_get_post_meta(get_the_ID(), 'crb_unit_gallery');
            $image = (is_array($gallery) && !empty($gallery)) ? wp_get_attachment_url($gallery[0]) : agro_get_first_attachment_url(get_the_ID());
            if (empty($image)) $image = 'https://placehold.co/600x400/e2e8f0/475569?text=Нет+фото';
        ?>
            <div class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition overflow-hidden border border-gray-100">
                <img src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" class="w-full h-56 object-cover">
                <div class="p-5">
                    <h3 class="font-bold text-xl"><a href="<?php the_permalink(); ?>" class="hover:text-green-600"><?php the_title(); ?></a></h3>
                    <div class="flex items-center gap-4 text-sm text-gray-600 mt-2">
                        <?php if ($area) : ?>
                            <span>📐 <?php echo esc_html($area); ?> м²</span>
                        <?php endif; ?>
                        <?php if ($price) : ?>
                            <span class="font-bold text-green-600"><?php echo esc_html($price); ?> ₽/м²</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($short_desc) : ?>
                        <p class="text-sm text-gray-600 mt-2"><?php echo wp_trim_words($short_desc, 15); ?></p>
                    <?php endif; ?>
                    <a href="<?php the_permalink(); ?>" class="mt-4 inline-block bg-green-50 text-green-700 px-5 py-2 rounded-lg hover:bg-green-600 hover:text-white transition">Подробнее</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php the_posts_pagination(); ?>
</div>
<?php get_footer(); ?>