<?php get_header(); ?>
<div class="max-w-4xl mx-auto px-4 py-12">
    <?php while (have_posts()) : the_post(); ?>
        <h1 class="text-4xl font-bold text-gray-800 mb-6"><?php the_title(); ?></h1>
        <div class="prose max-w-none"><?php the_content(); ?></div>
    <?php endwhile; ?>
</div>
<?php get_footer(); ?>