
<?php get_header(); ?>

<?php while (have_posts()) : the_post();

    $price = carbon_get_post_meta(get_the_ID(), 'crb_unit_price');
    $area = carbon_get_post_meta(get_the_ID(), 'crb_unit_area');
    $type = carbon_get_post_meta(get_the_ID(), 'crb_unit_type');
    $floor = carbon_get_post_meta(get_the_ID(), 'crb_unit_floor');
    $status = carbon_get_post_meta(get_the_ID(), 'crb_unit_status');
    $short_desc = carbon_get_post_meta(get_the_ID(), 'crb_unit_short_desc');
    $gallery = carbon_get_post_meta(get_the_ID(), 'crb_unit_gallery');

    $property = carbon_get_post_meta(
        get_the_ID(),
        'crb_unit_parent_property'
    );

?>

<section class="bg-[#106042] text-white py-20">

    <div class="max-w-7xl mx-auto px-6">

        <div class="uppercase tracking-widest text-[#F2D8A7] text-sm mb-4">
            Помещение
        </div>

        <h1 class="text-5xl font-bold mb-6">
            <?php the_title(); ?>
        </h1>

        <?php if ($short_desc) : ?>

            <div class="text-xl text-white/80 max-w-3xl">
                <?php echo wp_strip_all_tags($short_desc); ?>
            </div>

        <?php endif; ?>

    </div>

</section>


<?php if (!empty($gallery)) : ?>

<section class="py-12 bg-white">

    <div class="max-w-7xl mx-auto px-6">

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-4">

            <?php foreach ($gallery as $image_id) : ?>

                <img
                    src="<?php echo esc_url(wp_get_attachment_url($image_id)); ?>"
                    alt=""
                    class="w-full h-64 object-cover rounded-2xl"
                >

            <?php endforeach; ?>

        </div>

    </div>

</section>

<?php endif; ?>


<section class="py-16 bg-gray-50">

    <div class="max-w-7xl mx-auto px-6">

        <div class="grid lg:grid-cols-3 gap-10">

            <div class="lg:col-span-2">

                <div class="bg-white rounded-3xl p-8 shadow-sm">

                    <h2 class="text-3xl font-bold mb-6">
                        Описание помещения
                    </h2>

                    <div class="prose max-w-none">

                        <?php the_content(); ?>

                    </div>

                </div>

            </div>

            <div>

                <div class="bg-white rounded-3xl p-8 shadow-sm sticky top-28">

                    <h3 class="text-2xl font-bold mb-6 text-[#106042]">
                        Характеристики
                    </h3>

                    <div class="space-y-4">

                        <?php if ($price) : ?>
                            <div>
                                <div class="text-sm text-gray-500">
                                    Цена аренды
                                </div>
                                <div class="font-bold text-2xl text-[#008136]">
                                    <?php echo esc_html($price); ?> ₽/м²
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($area) : ?>
                            <div>
                                <div class="text-sm text-gray-500">
                                    Площадь
                                </div>
                                <div class="font-semibold">
                                    <?php echo esc_html($area); ?> м²
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($floor) : ?>
                            <div>
                                <div class="text-sm text-gray-500">
                                    Этаж
                                </div>
                                <div class="font-semibold">
                                    <?php echo esc_html($floor); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($type) : ?>
                            <div>
                                <div class="text-sm text-gray-500">
                                    Тип помещения
                                </div>
                                <div class="font-semibold">
                                    <?php echo esc_html($type); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($status) : ?>

                            <div>

                                <div class="text-sm text-gray-500">
                                    Статус
                                </div>

                                <div class="font-semibold">

                                    <?php
                                    $statuses = [
                                        'free' => '🟢 Свободно',
                                        'reserved' => '🟡 Забронировано',
                                        'occupied' => '🔴 Сдано',
                                    ];

                                    echo $statuses[$status] ?? '';
                                    ?>

                                </div>

                            </div>

                        <?php endif; ?>

                        <?php
                        if (
                            !empty($property)
                            && isset($property[0]['id'])
                        ) :
                        ?>

                            <div>

                                <div class="text-sm text-gray-500">
                                    Строение
                                </div>

                                <a
                                    href="<?php echo get_permalink($property[0]['id']); ?>"
                                    class="font-semibold text-[#008136] hover:underline"
                                >
                                    <?php echo get_the_title($property[0]['id']); ?>
                                </a>

                            </div>

                        <?php endif; ?>

                    </div>

                    <a
                        href="/kontakty"
                        class="btn-primary mt-8 w-full justify-center"
                    >
                        Оставить заявку
                    </a>

                </div>

            </div>

        </div>

    </div>

</section>

<?php endwhile; ?>

<?php get_footer(); ?>
