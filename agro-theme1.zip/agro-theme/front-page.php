<?php get_header(); ?>

<!-- HERO -->
<section class="relative overflow-hidden bg-gradient-to-br from-[#106042] to-[#008136] text-white">

    <div class="absolute -right-32 -top-32 w-96 h-96 rounded-full border-[40px] border-white/10"></div>
    <div class="absolute -right-10 top-10 w-72 h-72 rounded-full border-[30px] border-[#A6CE39]/20"></div>

    <div class="max-w-7xl mx-auto px-6 py-24 lg:py-36">

        <div class="grid lg:grid-cols-2 gap-12 items-center">

            <div>

                <div class="uppercase tracking-widest text-[#F2D8A7] text-sm mb-4">
                    ТомскАгроИнвест
                </div>

                <h1 class="text-5xl lg:text-6xl font-bold leading-tight mb-6">
                    Развитие агропромышленной инфраструктуры Томской области
                </h1>

                <p class="text-xl text-white/90 mb-10 max-w-xl">
                    Создаем условия для эффективной торговли,
                    поддержки сельхозпроизводителей и развития
                    регионального агропромышленного комплекса.
                </p>

                <div class="flex flex-wrap gap-4">

                    <a href="/o-kompanii"
                       class="bg-white text-[#106042] px-8 py-4 rounded-xl font-semibold hover:scale-105 transition">

                        О компании

                    </a>

                    <a href="/arenda"
                       class="border border-white px-8 py-4 rounded-xl hover:bg-white hover:text-[#106042] transition">

                        Аренда помещений

                    </a>

                </div>

            </div>

            <div>

               <!-- <img
                <!--    src="<?php echo get_template_directory_uri(); ?>/assets/img/hero-market.jpg"
                <!--    alt="Кулагинский рынок"
                <!--    class="rounded-3xl shadow-2xl w-full object-cover"
                <!-->
                
                <div class="hero-image h-[500px] bg-white/10 rounded-3xl flex items-center justify-center">

    <div class="text-center px-10">

        <div class="text-7xl mb-6">
            🌾
        </div>

        <div class="text-2xl font-semibold">
            Кулагинский рынок
        </div>

        <div class="mt-3 text-white/70">
            Фотография будет добавлена позже
        </div>

    </div>

</div>

            </div>

        </div>

    </div>

</section>

<!-- НАПРАВЛЕНИЯ ДЕЯТЕЛЬНОСТИ -->
<section class="py-24 bg-white">

    <div class="max-w-7xl mx-auto px-6">

        <div class="text-center mb-16">

            <h2 class="text-4xl font-bold text-[#106042] mb-4">
                Направления деятельности
            </h2>

            <p class="text-gray-600 max-w-3xl mx-auto">
                Ключевые направления работы АО ТомскАгроИнвест
            </p>

        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">

            <div class="bg-gray-50 rounded-3xl p-8">
                <h3 class="font-bold text-xl mb-3">Кулагинский рынок</h3>
                <p class="text-gray-600">Организация торговой деятельности и поддержка производителей.</p>
            </div>

            <div class="bg-gray-50 rounded-3xl p-8">
                <h3 class="font-bold text-xl mb-3">Аренда помещений</h3>
                <p class="text-gray-600">Торговые площади, склады и объекты инфраструктуры.</p>
            </div>

            <div class="bg-gray-50 rounded-3xl p-8">
                <h3 class="font-bold text-xl mb-3">Инвестиционные проекты</h3>
                <p class="text-gray-600">Развитие агропромышленной инфраструктуры региона.</p>
            </div>

            <div class="bg-gray-50 rounded-3xl p-8">
                <h3 class="font-bold text-xl mb-3">Поддержка фермеров</h3>
                <p class="text-gray-600">Создание условий для реализации продукции местных производителей.</p>
            </div>

        </div>

    </div>

</section>

<!-- О КОМПАНИИ -->
<section class="py-24 bg-[#106042] text-white">

    <div class="max-w-7xl mx-auto px-6">

        <div class="grid lg:grid-cols-2 gap-16 items-center">

            <div>

                <h2 class="text-4xl font-bold mb-6">
                    О компании
                </h2>

                <p class="text-lg text-white/80 leading-relaxed">
                    АО ТомскАгроИнвест выполняет важную роль
                    в развитии агропромышленного комплекса региона,
                    обеспечивая эффективную работу Томского областного рынка
                    и поддержку сельхозтоваропроизводителей.
                </p>

            </div>

            <div class="grid grid-cols-2 gap-6">

                <div class="bg-white/10 rounded-3xl p-8 text-center">
                    <div class="text-5xl font-bold mb-2">20+</div>
                    <div>лет работы</div>
                </div>

                <div class="bg-white/10 rounded-3xl p-8 text-center">
                    <div class="text-5xl font-bold mb-2">500+</div>
                    <div>арендаторов</div>
                </div>

                <div class="bg-white/10 rounded-3xl p-8 text-center">
                    <div class="text-5xl font-bold mb-2">10 000+</div>
                    <div>посетителей</div>
                </div>

                <div class="bg-white/10 rounded-3xl p-8 text-center">
                    <div class="text-5xl font-bold mb-2">100+</div>
                    <div>мероприятий</div>
                </div>

            </div>

        </div>

    </div>

</section>

<?php get_footer(); ?>
