<?php get_header(); ?>

<div class="max-w-7xl mx-auto px-4 py-12">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <h1 class="text-4xl font-bold text-gray-800 mb-4"><?php the_title(); ?></h1>
        <div class="prose max-w-none"><?php the_content(); ?></div>
    <?php endwhile; endif; ?>
</div>

<?php get_footer(); ?>