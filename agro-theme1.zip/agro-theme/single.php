<?php get_header(); ?>
<div class="max-w-4xl mx-auto px-4 py-12">
    <?php while (have_posts()) : the_post(); ?>
        <h1 class="text-4xl font-bold text-gray-800 mb-2"><?php the_title(); ?></h1>
        <p class="text-gray-500 mb-6"><?php echo get_the_date('d.m.Y'); ?></p>
        <?php if (has_post_thumbnail()) : ?>
            <img src="<?php the_post_thumbnail_url('large'); ?>" alt="" class="w-full h-96 object-cover rounded-xl mb-6">
        <?php endif; ?>
        <div class="prose max-w-none"><?php the_content(); ?></div>
    <?php endwhile; ?>
</div>
<?php get_footer(); ?>