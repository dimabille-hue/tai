<?php
// functions.php для темы agro-theme (с использованием Carbon Fields как плагина)

// 1. Регистрация типов записей Строение и Помещение
function agro_register_cpt() {
    // Строение
    register_post_type('property', [
        'labels' => [
            'name'               => 'Строения',
            'singular_name'      => 'Строение',
            'add_new'            => 'Добавить новое',
            'add_new_item'       => 'Добавить новое строение',
            'edit_item'          => 'Редактировать строение',
            'new_item'           => 'Новое строение',
            'view_item'          => 'Просмотр строения',
            'search_items'       => 'Искать строения',
            'not_found'          => 'Строений не найдено',
            'not_found_in_trash' => 'Строений в корзине нет',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'properties'],
        'supports' => ['title', 'editor', 'thumbnail'],
        'menu_icon' => 'dashicons-building',
        'menu_position' => 5,
    ]);

    // Помещение
    register_post_type('unit', [
        'labels' => [
            'name'               => 'Помещения',
            'singular_name'      => 'Помещение',
            'add_new'            => 'Добавить новое',
            'add_new_item'       => 'Добавить новое помещение',
            'edit_item'          => 'Редактировать помещение',
            'new_item'           => 'Новое помещение',
            'view_item'          => 'Просмотр помещения',
            'search_items'       => 'Искать помещения',
            'not_found'          => 'Помещений не найдено',
            'not_found_in_trash' => 'Помещений в корзине нет',
        ],
        'public' => true,
        'has_archive' => true,
        'rewrite' => ['slug' => 'catalog'],
        'supports' => ['title', 'editor', 'thumbnail'],
        'menu_icon' => 'dashicons-location-alt',
        'menu_position' => 6,
    ]);
}
add_action('init', 'agro_register_cpt');

// 2. Подключение Tailwind CSS и Alpine.js (без сборки)
function agro_enqueue_assets() {
    // Tailwind CSS
    wp_enqueue_style('tailwind', 'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css');
    // Alpine.js
    wp_enqueue_script('alpine', 'https://cdn.jsdelivr.net/npm/alpinejs@3.13.3/dist/cdn.min.js', [], null, true);
    // Кастомные стили
    wp_add_inline_style('tailwind', '
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .transition-smooth { transition: all 0.3s ease; }
    ');
}
add_action('wp_enqueue_scripts', 'agro_enqueue_assets');

// 3. Регистрация полей через Carbon Fields (плагин должен быть активен!)
add_action('carbon_fields_register_fields', 'agro_register_carbon_fields');
function agro_register_carbon_fields() {
    // Поля для строений
    \Carbon_Fields\Container::make('post_meta', 'Дополнительные поля строения')
        ->where('post_type', '=', 'property')
        ->add_fields([
            \Carbon_Fields\Field::make('media_gallery', 'crb_property_gallery', 'Галерея строения')
                ->set_type('image')
                ->set_help_text('Загрузите фотографии строения'),
        ]);


// Поля для помещений
\Carbon_Fields\Container::make('post_meta', 'Дополнительные поля помещения')
    ->where('post_type', '=', 'unit')
    ->add_fields([

        \Carbon_Fields\Field::make(
            'text',
            'crb_unit_price',
            'Цена аренды (₽/м²)'
        )
        ->set_help_text('Стоимость аренды за квадратный метр'),

        \Carbon_Fields\Field::make(
            'text',
            'crb_unit_area',
            'Площадь (м²)'
        )
        ->set_help_text('Общая площадь помещения'),

        \Carbon_Fields\Field::make(
            'text',
            'crb_unit_floor',
            'Этаж'
        )
        ->set_help_text('Например: 1, 2, Цоколь'),

        \Carbon_Fields\Field::make(
            'text',
            'crb_unit_type',
            'Тип помещения'
        )
        ->set_help_text('Склад, Торговое место, Павильон, Офис и т.д.'),

        \Carbon_Fields\Field::make(
            'select',
            'crb_unit_status',
            'Статус помещения'
        )
        ->add_options([
            'free'      => 'Свободно',
            'reserved'  => 'Забронировано',
            'occupied'  => 'Сдано',
        ])
        ->set_default_value('free'),

        \Carbon_Fields\Field::make(
            'association',
            'crb_unit_parent_property',
            'Строение'
        )
        ->set_types([
            [
                'type'      => 'post',
                'post_type' => 'property',
            ]
        ])
        ->set_max(1)
        ->set_help_text(
            'Выберите строение, к которому относится помещение'
        ),

        \Carbon_Fields\Field::make(
            'rich_text',
            'crb_unit_short_desc',
            'Краткое описание'
        )
        ->set_help_text(
            'Описание для карточки помещения'
        ),

        \Carbon_Fields\Field::make(
            'media_gallery',
            'crb_unit_gallery',
            'Галерея помещения'
        )
        ->set_type('image')
        ->set_help_text(
            'Загрузите фотографии помещения'
        ),

    ]);
}

// 4. Вспомогательная функция для получения первого изображения из галереи (если миниатюра не установлена)
function agro_get_first_attachment_url($post_id) {
    $images = get_attached_media('image', $post_id);
    if ($images) {
        $first = reset($images);
        return wp_get_attachment_url($first->ID);
    }
    return '';
}

// 5. Настройка меню (создание областей меню)
function agro_register_menus() {
    register_nav_menus([
        'primary' => 'Основное меню (шапка)',
        'footer'  => 'Меню в подвале',
    ]);
}
add_action('after_setup_theme', 'agro_register_menus');

// 6. Добавляем поддержку миниатюр
add_theme_support('post-thumbnails');

/**
 * --------------------------------------------------
 * CPT: Направления деятельности
 * --------------------------------------------------
 */

function agro_register_activity_cpt() {

    register_post_type('activity', [

        'labels' => [
            'name' => 'Направления деятельности',
            'singular_name' => 'Направление',
        ],

        'public' => true,
        'menu_icon' => 'dashicons-chart-line',
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'activity'],
    ]);
}

add_action('init', 'agro_register_activity_cpt');


/**
 * --------------------------------------------------
 * CPT: Документы
 * --------------------------------------------------
 */

function agro_register_document_cpt() {

    register_post_type('document', [

        'labels' => [
            'name' => 'Документы',
            'singular_name' => 'Документ',
        ],

        'public' => true,
        'menu_icon' => 'dashicons-media-document',
        'supports' => ['title'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'documents'],
    ]);
}

add_action('init', 'agro_register_document_cpt');


/**
 * --------------------------------------------------
 * Настройки темы
 * --------------------------------------------------
 */

add_action('carbon_fields_register_fields', function () {

    \Carbon_Fields\Container::make('theme_options', 'Настройки сайта')

        ->add_fields([

            \Carbon_Fields\Field::make(
                'text',
                'agro_phone',
                'Телефон'
            ),

            \Carbon_Fields\Field::make(
                'text',
                'agro_email',
                'Email'
            ),

            \Carbon_Fields\Field::make(
                'text',
                'agro_address',
                'Адрес'
            ),

            \Carbon_Fields\Field::make(
                'text',
                'agro_stat_years',
                'Лет работы'
            )->set_default_value('20+'),

            \Carbon_Fields\Field::make(
                'text',
                'agro_stat_renters',
                'Количество арендаторов'
            )->set_default_value('500+'),

            \Carbon_Fields\Field::make(
                'text',
                'agro_stat_visitors',
                'Посетителей'
            )->set_default_value('10000+'),

            \Carbon_Fields\Field::make(
                'text',
                'agro_stat_events',
                'Мероприятий'
            )->set_default_value('100+'),

        ]);
});


/**
 * --------------------------------------------------
 * Подключение theme.css
 * --------------------------------------------------
 */

function agro_theme_custom_styles() {

    wp_enqueue_style(
        'agro-theme',
        get_template_directory_uri() . '/assets/css/theme.css',
        [],
        filemtime(
            get_template_directory() . '/assets/css/theme.css'
        )
    );
}

add_action(
    'wp_enqueue_scripts',
    'agro_theme_custom_styles'
);
